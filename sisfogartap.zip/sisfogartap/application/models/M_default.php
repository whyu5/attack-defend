<?php

class M_default extends CI_Model
{


    // Authentification
    function cek_login($table, $where)
    {
        return $this->db->get_where($table, $where);
    }



    // Crud Modelling
    function input($data, $table)
    {
        $this->db->insert($table, $data);
    }

    function hapus($where, $table)
    {
        $this->db->where($where);
        $this->db->delete($table);
    }

    function edit($where, $table)
    {
        return $this->db->get_where($table, $where);
    }

    function update($where, $data, $table)
    {
        $this->db->where($where);
        $this->db->update($table, $data);
    }



    function getall($tabel)
    {
        return $this->db->get($tabel);
    }

    function tampil_user()
    {
        return $this->db->get('user');
    }

    function tampil_pokok()
    {
        return $this->db->get('pokok');
    }

    function tampil_jabatan()
    {
        return $this->db->get('jabatan');
    }

    function tampil_pangkat()
    {
        return $this->db->get('pangkat');
    }

    function tampil_berita()
    {
        return $this->db->get('berita');
    }

    function tampil_pesan()
    {
        return $this->db->get('komentar');
    }

    function tampil_pimpinan()
    {
        return $this->db->get('pimpinan');
    }

    function tampil_surel()
    {
        return $this->db->get('surel');
    }

    function tampil_database()
    {
        return $this->db->get('data_base');
    }

    function tampil_kendaraan()
    {
        return $this->db->get('kendaraan');
    }

    function tampil_pertanyaan()
    {
        return $this->db->get('pertanyaan');
    }

    function tampil_survey()
    {
        return $this->db->get('survey');
    }

    function tampil_pemakaman()
    {
        return $this->db->get('kematian');
    }

    function get_pdf($where, $table)
    {
        return $this->db->get_where($table, $where);
    }

    function get_order($choice, $form)
    {
        $this->db->select('*');
        $this->db->from('berita');
        $this->db->order_by($choice, $form);
        return $this->db->get();
    }

    function berita_limit($limit)
    {
        $this->db->select('*');
        $this->db->from('berita');
        $this->db->limit($limit);
        return $this->db->get();
    }
}
