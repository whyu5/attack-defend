<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/userguide3/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'home';
$route['404_override'] = 'Not';
$route['translate_uri_dashes'] = FALSE;



// Authentification
$route['auth'] = 'Auth';
$route['verification'] = 'Auth/verification';
$route['logout'] = 'Auth/logout';




// Frontend
$route['home'] = 'Home/index';
$route['contact'] = 'Home/contact';
$route['pesan-masuk'] = 'Home/pesan_masuk';
$route['berita-news'] = 'Home/berita';
$route['profile'] = 'Home/profil';
$route['struktur'] = 'Home/struktur';
$route['survey-kepuasan'] = 'Home/survey_kepuasan';
$route['survey-masuk'] = 'Home/survey_masuk';
$route['single-page/(:num)'] = 'Home/single_page/$1';








// Administrator
$route['dashboard'] = 'Admin/index';
$route['change-password'] = 'Admin/change_password';

$route['users'] = 'Admin/users';
$route['add-users'] = 'Admin/add_user';
$route['delete-users/(:num)'] = 'Admin/delete_user/$1';
$route['update-users'] = 'Admin/update_user';

$route['surat-elektronik'] = 'Admin/surat_elektronik';
$route['add-surel'] = 'Admin/add_surel';
$route['delete-surel/(:num)'] = 'Admin/delete_surel/$1';
$route['update-surel'] = 'Admin/update_surel';

$route['dosir'] = 'Admin/dosir_elektronik';
$route['view-dosir/(:num)'] = 'Admin/view_dosir/$1';
$route['full-dosir/(:num)'] = 'Admin/full_dosir/$1';
$route['delete-dosir/(:num)/(:any)'] = 'Admin/delete_dosir';
$route['upload-dosir'] = 'Admin/upload_dosir';
$route['dosir-upload'] = 'Admin/dosir_upload';
$route['blanko/(:num)'] = 'Admin/blanko_dosir/$1';

$route['jabatan'] = 'Admin/jabatan';
$route['update-jabatan'] = 'Admin/update_jabatan';
$route['delete-jabatan/(:num)'] = 'Admin/delete_jabatan/$1';
$route['add-jabatan'] = 'Admin/add_jabatan';
$route['pdf-pengawakan'] = 'Admin/pengawakan_pdf';
$route['excel-pengawakan'] = 'Admin/pengawakan_excel';


$route['personil'] = 'Admin/personel';
$route['add-personel'] = 'Admin/add_pers';
$route['add-personil'] = 'Admin/add_personil';
$route['delete-personel/(:num)/(:any)'] = 'Admin/delete_personel';

$route['riwayat-hidup'] = 'Admin/riwayat_hidup';
$route['view-riwayat/(:num)'] = 'Admin/view_riwayat/$1';
$route['data-pokok'] = 'Admin/update_pokok';
$route['data-keturunan'] = 'Admin/update_anak';
$route['delete-keturunan/(:num)/(:num)'] = 'Admin/delete_anak';
$route['data-pendidikan'] = 'Admin/update_pendidikan';
$route['delete-pendidikan/(:num)/(:num)'] = 'Admin/delete_pendidikan';
$route['data-bahasa'] = 'Admin/update_bahasa';
$route['delete-bahasa/(:num)/(:num)'] = 'Admin/delete_bahasa';
$route['data-jasa'] = 'Admin/update_jasa';
$route['delete-jasa/(:num)/(:num)'] = 'Admin/delete_jasa';
$route['data-operasi'] = 'Admin/update_operasi';
$route['delete-operasi/(:num)/(:num)'] = 'Admin/delete_operasi';
$route['data-penugasan'] = 'Admin/update_penugasan';
$route['delete-penugasan/(:num)/(:num)'] = 'Admin/delete_penugasan';
$route['data-kepangkatan'] = 'Admin/update_kepangkatan';
$route['delete-kepangkatan/(:num)/(:num)'] = 'Admin/delete_kepangkatan';
$route['data-jabatan'] = 'Admin/update_jabatan_r';
$route['delete-jabatan/(:num)/(:num)'] = 'Admin/delete_jabatan_r';
$route['data-foto'] = 'Admin/update_foto';
$route['print-riwayat/(:any)'] = 'Admin/print_riwayat/$1';

$route['comment'] = 'Admin/pesan';
$route['pimpinan'] = 'Admin/leader';
$route['add-pimpinan'] = 'Admin/add_pimpinan';
$route['delete-pimpinan/(:num)/(:any)'] = 'Admin/delete_pimpinan';
$route['update-pimpinan'] = 'Admin/update_pimpinan';
$route['update-foto-pimp'] = 'Admin/update_foto_pimp';

$route['news'] = 'Admin/berita';
$route['add-news'] = 'Admin/add_berita';
$route['news-add'] = 'Admin/berita_add';
$route['edit-news/(:num)'] = 'Admin/edit_berita/$1';
$route['update-news'] = 'Admin/update_berita';
$route['update-foto-news'] = 'Admin/update_foto_berita';
$route['delete-news/(:num)/(:any)'] = 'Admin/delete_berita';

$route['surat-menyurat'] = 'Admin/surat_menyurat';
$route['add-file'] = 'Admin/add_file';
$route['update-file'] = 'Admin/update_file';
$route['delete-file/(:num)/(:any)'] = 'Admin/delete_file';
$route['download-file/(:num)'] = 'Admin/download_file';

$route['denpom'] = 'Admin/denpomgar';
$route['update-kendaraan'] = 'Admin/update_kendaraan';
$route['delete-kendaraan/(:num)'] = 'Admin/delete_kendaraan/$1';
$route['add-kendaraan'] = 'Admin/add_kendaraan';

$route['pemakaman'] = 'Admin/pemakaman';
$route['berita-kematian'] = 'Admin/berita_kematian';
$route['add-berita-kematian'] = 'Admin/add_berita_kematian';
$route['update-berita-kematian'] = 'Admin/update_berita_kematian';
$route['delete-berita-kematian/(:num)'] = 'Admin/delete_berita_kematian/$1';
$route['ajukan-watzah/(:num)'] = 'Admin/ajukan_watzah/$1';
$route['pengajuan-watzah'] = 'Admin/pengajuan_watzah';
$route['selesaikan-watzah/(:num)'] = 'Admin/selesaikan_watzah/$1';
$route['selesai-watzah'] = 'Admin/selesai_watzah';

$route['view-data-kematian/(:num)'] = 'Admin/view_data_kematian/$1';
$route['berkas-upload'] = 'Admin/berkas_upload';
$route['delete-berkas-watzah/(:num)/(:any)'] = 'Admin/delete_berkas_watzah';
$route['full-berkas/(:num)'] = 'Admin/full_berkas/$1';

$route['feed-survey'] = 'Admin/feed_survey';

// Public
$route['auth-m'] = 'AuthPublic';
$route['verification-m'] = 'AuthPublic/verification';
$route['logout-m'] = 'AuthPublic/logout';

$route['dashboard-m'] = 'Anggota/index';
$route['riwayat-m'] = 'Anggota/view_riwayat';
$route['pokok-m'] = 'Anggota/update_pokok';
$route['keturunan-m'] = 'Anggota/update_anak';
$route['keturunan-mdelete/(:num)'] = 'Anggota/delete_anak';
$route['pendidikan-m'] = 'Anggota/update_pendidikan';
$route['pendidikan-mdelete/(:num)'] = 'Anggota/delete_pendidikan';
$route['bahasa-m'] = 'Anggota/update_bahasa';
$route['bahasa-mdelete/(:num)'] = 'Anggota/delete_bahasa';
$route['jasa-m'] = 'Anggota/update_jasa';
$route['jasa-mdelete/(:num)'] = 'Anggota/delete_jasa';
$route['operasi-m'] = 'Anggota/update_operasi';
$route['operasi-mdelete/(:num)'] = 'Anggota/delete_operasi';
$route['penugasan-m'] = 'Anggota/update_penugasan';
$route['penugasan-mdelete/(:num)'] = 'Anggota/delete_penugasan';
$route['kepangkatan-m'] = 'Anggota/update_kepangkatan';
$route['kepangkatan-mdelete/(:num)'] = 'Anggota/delete_kepangkatan';
$route['jabatan-m'] = 'Anggota/update_jabatan_r';
$route['jabatan-mdelete/(:num)'] = 'Anggota/delete_jabatan_r';
$route['foto-m'] = 'Anggota/update_foto';
$route['riwayat-mprint/(:any)'] = 'Anggota/print_riwayat/$1';


$route['dosir-m'] = 'Anggota/view_dosir';
$route['preview-m/(:num)'] = 'Anggota/full_dosir/$1';
$route['dosir-mdelete/(:num)/(:any)'] = 'Anggota/delete_dosir';
$route['upload-mdosir'] = 'Anggota/upload_dosir';
$route['dosir-mupload'] = 'Anggota/dosir_upload';


// Penerangan
$route['dashboard-p'] = 'Penerangan/index';
$route['buletin'] = 'Penerangan/buletin';
$route['add-buletin'] = 'Penerangan/add_buletin';
$route['buletin-add'] = 'Penerangan/buletin_add';
$route['edit-buletin/(:num)'] = 'Penerangan/edit_buletin/$1';
$route['update-buletin'] = 'Penerangan/update_buletin';
$route['delete-buletin/(:num)/(:any)'] = 'Penerangan/delete_buletin';
$route['update-foto-buletin'] = 'Penerangan/update_foto_buletin';

$route['profil-pim'] = 'Penerangan/pimpinan';
$route['add-propim'] = 'Penerangan/add_pimpinan';
$route['delete-propim/(:num)/(:any)'] = 'Penerangan/delete_pimpinan';
$route['update-propim'] = 'Penerangan/update_pimpinan';
$route['foto-propim'] = 'Penerangan/update_foto_pimp';

// Sekretariat
$route['dashboard-s'] = 'Sekretariat/index';
$route['surat-kelola'] = 'Sekretariat/surat_menyurat';
$route['add-sur'] = 'Sekretariat/add_file';
$route['update-sur'] = 'Sekretariat/update_file';
$route['delete-sur/(:num)/(:any)'] = 'Sekretariat/delete_file';
$route['download-sur/(:num)'] = 'Sekretariat/download_file';

$route['surat-el'] = 'Sekretariat/surat_elektronik';
$route['add-el'] = 'Sekretariat/add_surel';
$route['delete-el/(:num)'] = 'Sekretariat/delete_surel/$1';
$route['update-el'] = 'Sekretariat/update_surel';


// Denpom
$route['dashboard-d'] = 'Denpom/index';
$route['ran-dinas'] = 'Denpom/denpomgar';
$route['update-ran'] = 'Denpom/update_kendaraan';
$route['delete-ran/(:num)'] = 'Denpom/delete_kendaraan/$1';
$route['add-ran'] = 'Denpom/add_kendaraan';


// Test
$route['stoke'] = 'Admin/test_pdf';
$route['qr-code'] = 'Admin/qr';

// Personel
$route['dashboard-ps'] = 'Personel/index';
$route['pers-gar'] = 'Personel/personel';
$route['add-pers'] = 'Personel/add_pers';
$route['add-perss'] = 'Personel/add_personil';
$route['delete-pers/(:num)/(:any)'] = 'Personel/delete_personel';
$route['rh-pers'] = 'Personel/riwayat_hidup';
$route['view-rhpers/(:num)'] = 'Personel/view_riwayat/$1';

$route['cuti-ijin'] = 'Personel/cutiijin';
$route['add-sij'] = 'Personel/add_sij';
$route['cetak-sij/(:num)'] = 'Personel/cetak_sij/$1';

// Personel RH
$route['profil-pokok'] = 'Personel/update_pokok';
$route['profil-keturunan'] = 'Personel/update_anak';
$route['profil-keturunandelete/(:num)/(:num)'] = 'Personel/delete_anak';
$route['profil-pendidikan'] = 'Personel/update_pendidikan';
$route['profil-pendidikandelete/(:num)/(:num)'] = 'Personel/delete_pendidikan';
$route['profil-bahasa'] = 'Personel/update_bahasa';
$route['profil-bahasadelete/(:num)/(:num)'] = 'Personel/delete_bahasa';
$route['profil-jasa'] = 'Personel/update_jasa';
$route['profil-jasadelete/(:num)/(:num)'] = 'Personel/delete_jasa';
$route['profil-operasi'] = 'Personel/update_operasi';
$route['profil-operasidelete/(:num)/(:num)'] = 'Personel/delete_operasi';
$route['profil-penugasan'] = 'Personel/update_penugasan';
$route['profil-penugasandelete/(:num)/(:num)'] = 'Personel/delete_penugasan';
$route['profil-kepangkatan'] = 'Personel/update_kepangkatan';
$route['profil-kepangkatandelete/(:num)/(:num)'] = 'Personel/delete_kepangkatan';
$route['profil-jabatan'] = 'Personel/update_jabatan_r';
$route['profil-jabatandelete/(:num)/(:num)'] = 'Personel/delete_jabatan_r';
$route['profil-foto'] = 'Personel/update_foto';
$route['profil-printr/(:any)'] = 'Personel/print_riwayat/$1';

// Personel Dosir
$route['pers-dosir'] = 'Personel/dosir_elektronik';
$route['view-persdosir/(:num)'] = 'Personel/view_dosir/$1';
$route['full-persdosir/(:num)'] = 'Personel/full_dosir/$1';
$route['delete-persdosir/(:num)/(:any)'] = 'Personel/delete_dosir';
$route['upload-persdosir'] = 'Personel/upload_dosir';
$route['dosir-persupload'] = 'Personel/dosir_upload';
$route['persblanko/(:num)'] = 'Personel/blanko_dosir/$1';

$route['dsp-gartap'] = 'Personel/jabatan';
$route['update-dspg'] = 'Personel/update_jabatan';
$route['delete-dspg/(:num)'] = 'Personel/delete_jabatan/$1';
$route['add-dspg'] = 'Personel/add_jabatan';
$route['pdf-dspg'] = 'Personel/pengawakan_pdf';
$route['excel-dspg'] = 'Personel/pengawakan_excel';



// Pemakaman
$route['dashboard-pm'] = 'Pemakaman/index';
$route['dash-pm'] = 'Pemakaman/berita_kematian';
$route['add-pm'] = 'Pemakaman/add_berita_kematian';
$route['update-pm'] = 'Pemakaman/update_berita_kematian';
$route['delete-pm/(:num)/(:num)'] = 'Pemakaman/delete_berita_kematian/$1/$2';
$route['ajukan-watzahpm/(:num)'] = 'Pemakaman/ajukan_watzah/$1';
$route['pengajuan-watzahpm'] = 'Pemakaman/pengajuan_watzah';
$route['selesaikan-watzahpm/(:num)'] = 'Pemakaman/selesaikan_watzah/$1';
$route['watzah-selesai'] = 'Pemakaman/selesai_watzah';
$route['manual-pm'] = 'Pemakaman/pemakaman';
$route['view-pm/(:num)'] = 'Pemakaman/view_data_kematian/$1';
$route['berkas-uploadpm'] = 'Pemakaman/berkas_upload';
$route['delete-berkas-pm/(:num)/(:any)'] = 'Pemakaman/delete_berkas_watzah';
$route['full-berkaspm/(:num)'] = 'Pemakaman/full_berkas/$1';
$route['laporan-pm'] = 'Pemakaman/laporsen';


# Disable Controller access without routing
$route['(.*)'] = "error404";
