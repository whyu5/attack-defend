<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Sekretariat extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper(array('url', 'download'));

        if ($this->session->userdata('status') != "Sekretariat") {
            redirect(base_url("auth"));
        } else {

            $this->load->model('M_default');
            $this->load->helper('url');
        }
    }

    function index()
    {
        $data['title'] = 'Dashboard';
        $data['user'] = $this->M_default->tampil_pesan()->result();
        $this->load->view('backend/sekretariat/templates/sidebar', $data);
        $this->load->view('backend/sekretariat/dashboard', $data);
        $this->load->view('backend/sekretariat/templates/footer');
    }

    function surat_menyurat()
    {
        $data['title'] = 'Data File';
        $data['user'] = $this->M_default->tampil_database()->result();
        $this->load->view('backend/sekretariat/templates/sidebar', $data);
        $this->load->view('backend/sekretariat/surat-menyurat', $data);
        $this->load->view('backend/sekretariat/templates/footer');
    }

    function add_file()
    {
        $pdf = $_FILES['pdf'];
        $config['upload_path']          = './public/uploads/database';
        $config['allowed_types']        = 'PDF|pdf';
        $config['max_size']             = '3000';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('pdf')) {
            $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
        } else {
            date_default_timezone_set('Asia/Jakarta');
            $waktu = date('Y-m-d H:i:s');
            $nama = $this->input->post('nama');
            $oleh = $this->input->post('oleh');
            $pic = $this->upload->data('file_name');

            $data = array(
                'nama' => $nama,
                'oleh' => $oleh,
                'tgl_masuk' => $waktu,
                'pdf' => $pic
            );

            $this->M_default->input($data, 'data_base');
            $this->session->set_flashdata('message', 'data telah diperbarui dari dalam sistem, terima kasih !');
            redirect('surat-kelola');
        }
        $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
        redirect('surat-kelola');
    }

    function update_file()
    {
        $id = $this->input->post('id');
        $pdf = $_FILES['pdf']['name'];
        $nama = $this->input->post('nama');
        $oleh = $this->input->post('oleh');
        date_default_timezone_set('Asia/Jakarta');
        $waktu = date('Y-m-d H:i:s');

        if ($pdf != '') {

            $config['upload_path']          = './public/uploads/database';
            $config['allowed_types']        = 'PDF|pdf';
            $config['max_size']             = '5000';
            $this->load->library('upload', $config);


            if (!$this->upload->do_upload('pdf')) {
                $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
            } else {
                $old_pdf = $this->input->post('old_pdf');
                if ($old_pdf != '') {
                    unlink(FCPATH . 'public/uploads/database/' . $old_pdf);
                }
                $pic = $this->upload->data('file_name');
                $data = array(
                    'nama' => $nama,
                    'oleh' => $oleh,
                    'tgl_masuk' => $waktu,
                    'pdf' => $pic
                );

                $where = array(
                    'id' => $id
                );

                $this->M_default->update($where, $data, 'data_base');
                $this->session->set_flashdata('message', 'data telah diperbarui dari dalam sistem, terima kasih !');
                redirect('surat-kelola');
            }
            $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
            redirect('surat-kelola');
        } else {
            $data = array(
                'nama' => $nama,
                'oleh' => $oleh,
                'tgl_masuk' => $waktu
            );

            $where = array(
                'id' => $id
            );

            $this->M_default->update($where, $data, 'data_base');
            $this->session->set_flashdata('message', 'data telah diperbarui dari dalam sistem, terima kasih !');
            redirect('surat-kelola');
        }
    }

    function delete_file()
    {
        $id = $this->uri->segment(2);
        $where = array('id' => $id);
        $file = $this->uri->segment(3);
        $this->M_default->hapus($where, 'data_base');
        unlink(FCPATH . 'public/uploads/database/' . $file);
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('surat-kelola');
    }

    function download_file()
    {
        $id = $this->uri->segment(2);
        $get = $this->db->query("SELECT * FROM data_base where id='$id' ");
        foreach ($get->result_array() as $file) {
            $files = $file['pdf'];
        }
        force_download('./public/uploads/database/' . $files, NULL);
    }

    function surat_elektronik()
    {
        $data['title'] = 'Surat Elektronik';
        $data['user'] = $this->M_default->tampil_surel()->result();
        $this->load->view('backend/sekretariat/templates/sidebar', $data);
        $this->load->view('backend/sekretariat/surat-elektronik', $data);
        $this->load->view('backend/sekretariat/templates/footer');
    }

    function add_surel()
    {
        $kategori = htmlspecialchars($this->input->post('kategori'));
        $nomor = htmlspecialchars($this->input->post('nomor'));
        $dari = htmlspecialchars($this->input->post('dari'));
        $tujuan = htmlspecialchars($this->input->post('tujuan'));
        $perihal = htmlspecialchars($this->input->post('perihal'));
        $penerima = htmlspecialchars($this->input->post('penerima'));
        $ket = htmlspecialchars($this->input->post('ket'));
        date_default_timezone_set('Asia/Jakarta');
        $waktu = date('d-m-Y H:i:s');

        $data = array(
            'penerima' => $penerima,
            'perihal' => $perihal,
            'tujuan' => $tujuan,
            'dari' => $dari,
            'nomor' => $nomor,
            'waktu' => $waktu,
            'ket' => $ket,
            'kategori' => $kategori

        );

        $this->M_default->input($data, 'surel');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('surat-el');
    }

    function delete_surel($id)
    {
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'surel');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('surat-el');
    }

    function update_surel()
    {
        $id = $this->input->post('id');
        $kategori = htmlspecialchars($this->input->post('kategori'));
        $nomor = htmlspecialchars($this->input->post('nomor'));
        $dari = htmlspecialchars($this->input->post('dari'));
        $tujuan = htmlspecialchars($this->input->post('tujuan'));
        $perihal = htmlspecialchars($this->input->post('perihal'));
        $penerima = htmlspecialchars($this->input->post('penerima'));
        $kets = htmlspecialchars($this->input->post('ket'));
        date_default_timezone_set('Asia/Jakarta');
        $waktu = date('d-m-Y H:i:s');

        $data = array(
            'penerima' => $penerima,
            'perihal' => $perihal,
            'tujuan' => $tujuan,
            'dari' => $dari,
            'nomor' => $nomor,
            'ket' => $kets,
            'kategori' => $kategori,
            'waktu' => $waktu

        );

        $where = array(
            'id' => $id
        );

        $this->M_default->update($where, $data, 'surel');
        $this->session->set_flashdata('message', 'data telah diperbarui dari dalam sistem, terima kasih !');
        redirect('surat-el');
    }
}
