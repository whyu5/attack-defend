<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper(array('url', 'download'));

        if ($this->session->userdata('status') != "Administrator") {
            redirect(base_url("auth"));
        } else {

            $this->load->model('M_default');
            $this->load->helper('url');
        }
    }

    function index()
    {
        $data['title'] = 'Dashboard';
        $data['user'] = $this->M_default->tampil_pesan()->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/dashboard', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function change_password()
    {
        $id = $this->input->post('id');
        $pw_lama = $this->input->post('pw_lama');
        $pw_baru = $this->input->post('pw_baru');
        $pw_baru2 = $this->input->post('pw_baru2');


        $username = $this->session->userdata('nama');

        $where2 = array(
            'id' => $id
        );

        $get_pw = $this->db->get_where('user', ['username' => $username])->row_array();
        $pw = $get_pw['password'];
        if (password_verify($pw_lama, $pw)) {
            if ($pw_baru == $pw_baru2) {
                $data = array(
                    'password' => password_hash($this->input->post('pw_baru'), PASSWORD_DEFAULT),
                );
                $this->M_default->update($where2, $data, 'user');
                $this->session->set_flashdata('message', 'data telah diperbarui kedalam sistem, terima kasih !');
                redirect('dashboard');
            } else {
                $this->session->set_flashdata('message', 'data tidak sesuai, cek kembali password anda');
                redirect('dashboard');
            }
        } else {
            $this->session->set_flashdata('message', 'data tidak sesuai, cek kembali password anda');
            redirect('dashboard');
        }
    }

    function users()
    {
        $data['title'] = 'Users';
        $data['user'] = $this->M_default->tampil_user()->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/akun', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function add_user()
    {
        $username = htmlspecialchars($this->input->post('username'));
        $password = htmlspecialchars($this->input->post('password'));
        $nama = htmlspecialchars($this->input->post('nama'));
        $level = htmlspecialchars($this->input->post('level'));

        $data = array(
            'username' => $username,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'nama' => $nama,
            'level' => $level

        );

        $this->M_default->input($data, 'user');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('users');
    }

    function delete_user($id)
    {
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'user');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('users');
    }

    function update_user()
    {
        $id = $this->input->post('id');
        $username = htmlspecialchars($this->input->post('username'));
        $nama = htmlspecialchars($this->input->post('nama'));
        $level = htmlspecialchars($this->input->post('level'));

        $data = array(
            'username' => $username,
            'level' => $level,
            'nama' => $nama
        );

        $where = array(
            'id' => $id
        );

        $this->M_default->update($where, $data, 'user');
        $this->session->set_flashdata('message', 'data telah diperbarui dari dalam sistem, terima kasih !');
        redirect('users');
    }

    function surat_elektronik()
    {
        $data['title'] = 'Surat Elektronik';
        $data['user'] = $this->M_default->tampil_surel()->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/surat-elektronik', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function add_surel()
    {
        $kategori = htmlspecialchars($this->input->post('kategori'));
        $nomor = htmlspecialchars($this->input->post('nomor'));
        $dari = htmlspecialchars($this->input->post('dari'));
        $tujuan = htmlspecialchars($this->input->post('tujuan'));
        $perihal = htmlspecialchars($this->input->post('perihal'));
        $penerima = htmlspecialchars($this->input->post('penerima'));
        $ket = htmlspecialchars($this->input->post('ket'));
        date_default_timezone_set('Asia/Jakarta');
        $waktu = date('d-m-Y H:i:s');

        $data = array(
            'penerima' => $penerima,
            'perihal' => $perihal,
            'tujuan' => $tujuan,
            'dari' => $dari,
            'nomor' => $nomor,
            'waktu' => $waktu,
            'ket' => $ket,
            'kategori' => $kategori

        );

        $this->M_default->input($data, 'surel');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('surat-elektronik');
    }

    function delete_surel($id)
    {
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'surel');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('surat-elektronik');
    }

    function update_surel()
    {
        $id = $this->input->post('id');
        $kategori = htmlspecialchars($this->input->post('kategori'));
        $nomor = htmlspecialchars($this->input->post('nomor'));
        $dari = htmlspecialchars($this->input->post('dari'));
        $tujuan = htmlspecialchars($this->input->post('tujuan'));
        $perihal = htmlspecialchars($this->input->post('perihal'));
        $penerima = htmlspecialchars($this->input->post('penerima'));
        $kets = htmlspecialchars($this->input->post('ket'));
        date_default_timezone_set('Asia/Jakarta');
        $waktu = date('d-m-Y H:i:s');

        $data = array(
            'penerima' => $penerima,
            'perihal' => $perihal,
            'tujuan' => $tujuan,
            'dari' => $dari,
            'nomor' => $nomor,
            'ket' => $kets,
            'kategori' => $kategori,
            'waktu' => $waktu

        );

        $where = array(
            'id' => $id
        );

        $this->M_default->update($where, $data, 'surel');
        $this->session->set_flashdata('message', 'data telah diperbarui dari dalam sistem, terima kasih !');
        redirect('surat-elektronik');
    }

    function dosir_elektronik()
    {
        $data['title'] = 'Dosir Elektronik';
        $data['user'] = $this->M_default->tampil_pokok()->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/dosir-elektronik', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function view_dosir($id)
    {
        $data['title'] = 'Dosir Elektronik';
        $where = array('id' => $id);
        $data['user'] = $this->M_default->edit($where, 'pokok')->result();

        $get = $this->db->query("SELECT * FROM pokok WHERE id = '$id' ");
        foreach ($get->result_array() as $nrp) {
            $nrp = $nrp['nrp'];
        }

        $where2 = array('nrp' => $nrp);
        $data['dosir'] = $this->M_default->edit($where2, 'dosir')->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/dosir-view', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function delete_dosir()
    {
        $id = $this->uri->segment(2);
        $where = array('id' => $id);
        $tni = $this->uri->segment(3);

        $get = $this->db->query("SELECT * FROM dosir join pokok on dosir.nrp = pokok.nrp where dosir.id='$id' ");
        foreach ($get->result_array() as $nrp) {
            $nrp = $nrp['id'];
        }
        $this->M_default->hapus($where, 'dosir');
        unlink(FCPATH . 'public/uploads/pdf/' . $tni);
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('view-dosir/' . $nrp);
    }

    function upload_dosir()
    {
        $pdf = $_FILES['pdf'];
        $id = $this->input->post('id');
        $nrp = $this->input->post('nrp');
        $idnya = $this->input->post('idnya');

        $config['upload_path']          = './public/uploads/pdf';
        $config['allowed_types']        = 'PDF|pdf';
        $config['max_size']             = '5000';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('pdf')) {
            $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
        } else {
            $old_pdf = $this->input->post('old_pdf');
            if ($old_pdf != '') {
                unlink(FCPATH . 'public/uploads/pdf/' . $old_pdf);
            }
            $pic = $this->upload->data('file_name');
            $data = array(
                'pdf' => $pic,
                'status' => 'T'
            );

            $where = array(
                'id' => $idnya
            );

            $this->M_default->update($where, $data, 'dosir');
            $this->session->set_flashdata('message', 'data telah diperbarui dari dalam sistem, terima kasih !');
            redirect('view-dosir/' . $id);
        }
        $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
        redirect('view-dosir/' . $id);
    }

    function dosir_upload()
    {
        $pdf = $_FILES['pdf'];
        $id = $this->input->post('id');
        $nrp = $this->input->post('nrp');
        $caption = $this->input->post('caption');


        $config['upload_path']          = './public/uploads/pdf';
        $config['allowed_types']        = 'PDF|pdf';
        $config['max_size']             = '5000';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('pdf')) {
            $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
        } else {
            $pic = $this->upload->data('file_name');
            $data = array(
                'nrp' => $nrp,
                'caption' => $caption,
                'status' => 'T',
                'pdf' => $pic
            );

            $this->M_default->input($data, 'dosir');
            $this->session->set_flashdata('message', 'ditambah');
            redirect('view-dosir/' . $id);
        }
        $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
        redirect('view-dosir/' . $id);
    }

    function full_dosir($id)
    {
        $data['title'] = 'Dosir Elektronik';
        $where = array('id' => $id);
        $data['user'] = $this->M_default->edit($where, 'dosir')->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/dosir-full', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function blanko_dosir($nrp)
    {
        $where = array('nrp' => $nrp, 'status' => 'T');
        $user = $this->db->get_where('pokok', ['nrp' => $nrp],)->row_array();
        $data['nip'] = $user['nrp'];
        $data['nama'] = $user['nama'];
        $data['dosir'] = $this->M_default->edit($where, 'dosir')->result();
        $this->load->library('pdf');
        $this->pdf->setPaper('Legal', 'potrait');
        $this->pdf->filename = "Daftar Isi Dosir " . $nrp . ".pdf";
        $this->pdf->load_view('backend/output/blanko', $data);
    }

    function stiker_dosir($nrp)
    {
        $where = array('nrp' => $nrp);
        $user = $this->db->get_where('pokok', ['nrp' => $nrp])->row_array();
        $data['nip'] = $user['nrp'];
        $data['nama'] = $user['nama'];
        $data['dosir'] = $this->M_default->edit($where, 'dosir')->result();
        $this->load->library('pdf');
        $this->pdf->setPaper('Legal', 'landscape');
        $this->pdf->filename = "Stiker.pdf";
        $this->pdf->load_view('backend/output/sticker', $data);
    }

    function jabatan()
    {
        $data['title'] = 'Data Jabatan';
        $data['user'] = $this->db->query('SELECT *, jabatan.id as idnya from jabatan join satker on jabatan.kode_satker = satker.kode_satker order by jabatan.kode_jab ASC')->result();

        $char = 'KG2-';
        $datag = $this->db->query('SELECT max(kode_jab) as kodeh from jabatan')->result();
        foreach ($datag as $saha) {
            if (!isset($saha->kodeh)) {
                $data['kodeh'] = $char . '0001';
            } else {
                $asd = (int)substr($saha->kodeh, 4, 4);
                $asd++;
                $data['kodeh'] = $char . sprintf("%04s", $asd);
            };
        };
        $data['satker'] = $this->M_default->getall('satker')->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/jabatan', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function update_jabatan()
    {
        $id = $this->input->post('id');
        $nama = htmlspecialchars($this->input->post('nama'));
        $kode_jab = htmlspecialchars($this->input->post('kode_jab'));
        $kode_satker = htmlspecialchars($this->input->post('kode_satker'));
        $data = array(
            'kode_satker' => $kode_satker,
            'kode_jab' => $kode_jab,
            'nama' => $nama
        );

        $where = array(
            'id' => $id
        );

        $this->M_default->update($where, $data, 'jabatan');
        $this->session->set_flashdata('message', 'data telah diperbarui dari dalam sistem, terima kasih !');
        redirect('jabatan');
    }

    function delete_jabatan($id)
    {
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'jabatan');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('jabatan');
    }

    function add_jabatan()
    {
        $nama = htmlspecialchars($this->input->post('nama'));
        $kode_jab = htmlspecialchars($this->input->post('kode_jab'));
        $kode_satker = htmlspecialchars($this->input->post('kode_satker'));
        $data = array(
            'kode_satker' => $kode_satker,
            'kode_jab' => $kode_jab,
            'nama' => $nama
        );

        $this->M_default->input($data, 'jabatan');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('jabatan');
    }

    function pengawakan_pdf()
    {
        $data['user'] = $this->db->query('SELECT * from jabatan join satker on jabatan.kode_satker = satker.kode_satker order by jabatan.kode_jab ASC')->result();
        $this->load->library('pdf');
        $this->pdf->setPaper('Legal', 'landscape');
        $this->pdf->filename = "Pengawakan Personel.pdf";
        $this->pdf->load_view('backend/output/pengawakan-pdf', $data);
    }

    function pengawakan_excel()
    {
        $data['user'] = $this->M_default->tampil_jabatan()->result();
        $this->load->view('backend/output/pengawakan-excel', $data);
    }

    function personel()
    {
        $data['title'] = 'Data Personil';
        $data['user'] = $this->M_default->tampil_pokok()->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/personel', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function add_pers()
    {
        $data['title'] = 'Data Personil';
        $data['user'] = $this->M_default->tampil_jabatan()->result();
        $data['pangkat'] = $this->M_default->tampil_pangkat()->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/personel-add', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function add_personil()
    {
        $nrp = htmlspecialchars($this->input->post('nrp'));
        $pangkat = htmlspecialchars($this->input->post('pangkat'));
        $nama = htmlspecialchars($this->input->post('nama'));
        $kesatuan = htmlspecialchars($this->input->post('kesatuan'));
        $jabatan = htmlspecialchars($this->input->post('jabatan'));
        $tmt_jab = htmlspecialchars($this->input->post('tmt_jab'));
        $tgl_lahir = htmlspecialchars($this->input->post('tgl_lahir'));

        $data = array(
            'nrp' => $nrp,
            'pangkat' => $pangkat,
            'nama' => $nama,
            'kesatuan' => $kesatuan,
            'jabatan' => $jabatan,
            'tmt_jab' => $tmt_jab,
            'tgl_lahir' => $tgl_lahir,
            'foto' => 'image.png'

        );

        $kk = array(
            'nrp' => $nrp,
            'caption' => 'KARTU KELUARGA',
            'status' => 'F'
        );
        $ktp = array(
            'nrp' => $nrp,
            'caption' => 'KARTU TANDA PENDUDUK',
            'status' => 'F'
        );
        $sk_tni = array(
            'nrp' => $nrp,
            'caption' => 'KEP PENGANGKATAN PERTAMA',
            'status' => 'F'
        );

        $asabri = array(
            'nrp' => $nrp,
            'caption' => 'ASABRI',
            'status' => 'F'
        );

        $this->M_default->input($kk, 'dosir');
        $this->M_default->input($ktp, 'dosir');
        $this->M_default->input($sk_tni, 'dosir');
        $this->M_default->input($asabri, 'dosir');

        $this->M_default->input($data, 'pokok');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('personil');
    }

    function delete_personel()
    {
        $id = $this->uri->segment(2);
        $vodka = $this->uri->segment(3);
        $where = array('id' => $id);
        $user = $this->db->get_where('dosir', ['id' => $id],)->row_array();
        $nrp = $user['nrp'];
        unlink(FCPATH . 'public/uploads/pdf/' . $nrp);

        if ($vodka != 'image.png') {
            unlink(FCPATH . 'uploads/img/' . $vodka);
        }

        $this->M_default->hapus($where, 'pokok');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('personil');
    }

    function riwayat_hidup()
    {
        $data['title'] = 'Riwayat Hidup';
        $data['user'] = $this->M_default->tampil_pokok()->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/riwayat-hidup', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function view_riwayat($id)
    {
        $data['title'] = 'Riwayat Hidup';
        $where = array('id' => $id);

        $data['user'] = $this->M_default->edit($where, 'pokok')->result();
        $get = $this->db->query("SELECT * FROM pokok WHERE id = '$id' ");
        foreach ($get->result_array() as $nrp) {
            $nrp = $nrp['nrp'];
        }

        $where_pend_umum = array('kategori' => 'Umum', 'nrp' => $nrp);
        $where_bangum = array('kategori' => 'BANGUM', 'nrp' => $nrp);
        $where_bangspes = array('kategori' => 'BANGSPES', 'nrp' => $nrp);
        $where_penugasan = array('nrp' => $nrp);
        $where_riwayat = array('nrp' => $nrp);
        $where_operasi = array('nrp' => $nrp);
        $where_jasa = array('nrp' => $nrp);
        $where_kepang = array('nrp' => $nrp);
        $where_bahasa = array('nrp' => $nrp);
        $where_anak = array('nrp' => $nrp);

        $data['pendidikan1'] = $this->M_default->edit($where_pend_umum, 'pendidikan')->result();
        $data['pendidikan2'] = $this->M_default->edit($where_bangum, 'pendidikan')->result();
        $data['pendidikan3'] = $this->M_default->edit($where_bangspes, 'pendidikan')->result();
        $data['penugasan'] = $this->M_default->edit($where_penugasan, 'penugasan')->result();
        $data['riwayat_jabatan'] = $this->M_default->edit($where_riwayat, 'riwayat_jabatan')->result();
        $data['operasi'] = $this->M_default->edit($where_operasi, 'operasi')->result();
        $data['jasa'] = $this->M_default->edit($where_jasa, 'jasa')->result();
        $data['kepangkatan'] = $this->M_default->edit($where_kepang, 'kepangkatan')->result();
        $data['bahasa'] = $this->M_default->edit($where_bahasa, 'bahasa')->result();
        $data['anak'] = $this->M_default->edit($where_anak, 'anak')->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/view-riwayat', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function update_pokok()
    {
        $id = $this->input->post('id');
        $tmt_jab = htmlspecialchars($this->input->post('tmt_jab'));
        $tgl_lahir = htmlspecialchars($this->input->post('tgl_lahir'));
        $tpt_lahir = htmlspecialchars($this->input->post('tpt_lahir'));
        $kategori = htmlspecialchars($this->input->post('kategori'));
        $sumber = htmlspecialchars($this->input->post('sumber'));
        $tpt_lahir_istri = htmlspecialchars($this->input->post('tpt_lahir_istri'));
        $pekerjaan = htmlspecialchars($this->input->post('pekerjaan'));
        $istri = htmlspecialchars($this->input->post('istri'));
        $ibu = htmlspecialchars($this->input->post('ibu'));
        $ayah = htmlspecialchars($this->input->post('ayah'));
        $berat = htmlspecialchars($this->input->post('berat'));
        $tinggi = htmlspecialchars($this->input->post('tinggi'));
        $goldar = htmlspecialchars($this->input->post('goldar'));
        $status_kawin = htmlspecialchars($this->input->post('status_kawin'));
        $agama = htmlspecialchars($this->input->post('agama'));
        $suku = htmlspecialchars($this->input->post('suku'));
        $tmt_tni = htmlspecialchars($this->input->post('tmt_tni'));
        $tmt_kat = htmlspecialchars($this->input->post('tmt_kat'));
        $tgl_lahir_istri = htmlspecialchars($this->input->post('tgl_lahir_istri'));
        $baju = htmlspecialchars($this->input->post('baju'));
        $celana = htmlspecialchars($this->input->post('celana'));
        $sepatu = htmlspecialchars($this->input->post('sepatu'));
        $topi = htmlspecialchars($this->input->post('topi'));
        $matra = htmlspecialchars($this->input->post('matra'));
        $alamat = htmlspecialchars($this->input->post('alamat'));


        $data = array(
            'tmt_jab' => $tmt_jab,
            'tgl_lahir' => $tgl_lahir,
            'tpt_lahir' => $tpt_lahir,
            'kategori' => $kategori,
            'sumber' => $sumber,
            'tmt_tni' => $tmt_tni,
            'tmt_kat' => $tmt_kat,
            'suku' => $suku,
            'agama' => $agama,
            'status_kawin' => $status_kawin,
            'goldar' => $goldar,
            'tinggi' => $tinggi,
            'berat' => $berat,
            'ayah' => $ayah,
            'ibu' => $ibu,
            'matra' => $matra,
            'istri' => $istri,
            'pekerjaan' => $pekerjaan,
            'tpt_lahir_istri' => $tpt_lahir_istri,
            'tgl_lahir_istri' => $tgl_lahir_istri,
            'baju' => $baju,
            'celana' => $celana,
            'sepatu' => $sepatu,
            'topi' => $topi,
            'alamat' => $alamat

        );

        $where = array(
            'id' => $id
        );

        $this->M_default->update($where, $data, 'pokok');
        $this->session->set_flashdata('message', 'data telah diperbarui dari dalam sistem, terima kasih !');
        redirect('view-riwayat/' . $id);
    }

    function update_anak()
    {

        $id = htmlspecialchars($this->input->post('id-keturunan'));
        $nrp = htmlspecialchars($this->input->post('nrp-keturunan'));
        $nama = htmlspecialchars($this->input->post('nama'));
        $tpt_lahir = htmlspecialchars($this->input->post('tpt_lahir'));
        $tgl_lahir = htmlspecialchars($this->input->post('tgl_lahir'));

        $data = array(
            'nama' => $nama,
            'nrp' => $nrp,
            'tpt_lahir' => $tpt_lahir,
            'tgl_lahir' => $tgl_lahir

        );

        $this->M_default->input($data, 'anak');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('view-riwayat/' . $id);
    }

    function delete_anak()
    {
        $id = $this->uri->segment(2);
        $iden = $this->uri->segment(3);
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'anak');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('view-riwayat/' . $iden);
    }

    function update_pendidikan()
    {
        $id = htmlspecialchars($this->input->post('id'));
        $nrp = htmlspecialchars($this->input->post('nrp'));
        $kategori = htmlspecialchars($this->input->post('kategori'));
        $thun_lulus = htmlspecialchars($this->input->post('thun_lulus'));
        $nama = htmlspecialchars($this->input->post('nama'));
        $data = array(
            'nrp' => $nrp,
            'kategori' => $kategori,
            'thun_lulus' => $thun_lulus,
            'nama' => $nama
        );
        $this->M_default->input($data, 'pendidikan');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('view-riwayat/' . $id);
    }

    function delete_pendidikan()
    {
        $id = $this->uri->segment(2);
        $iden = $this->uri->segment(3);
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'pendidikan');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('view-riwayat/' . $iden);
    }

    function update_bahasa()
    {
        $id = htmlspecialchars($this->input->post('id'));
        $nrp = htmlspecialchars($this->input->post('nrp'));
        $bahasa = htmlspecialchars($this->input->post('bahasa'));
        $ket = htmlspecialchars($this->input->post('ket'));
        $jenis = htmlspecialchars($this->input->post('jenis'));

        $data = array(
            'bahasa' => $bahasa,
            'nrp' => $nrp,
            'jenis' => $jenis,
            'ket' => $ket

        );

        $this->M_default->input($data, 'bahasa');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('view-riwayat/' . $id);
    }

    function delete_bahasa()
    {
        $id = $this->uri->segment(2);
        $iden = $this->uri->segment(3);
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'bahasa');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('view-riwayat/' . $iden);
    }

    function update_jasa()
    {
        $id = htmlspecialchars($this->input->post('id'));
        $nrp = htmlspecialchars($this->input->post('nrp'));
        $nama = htmlspecialchars($this->input->post('nama'));
        $tahun = htmlspecialchars($this->input->post('tahun'));

        $data = array(
            'nama' => $nama,
            'nrp' => $nrp,
            'tahun' => $tahun

        );

        $this->M_default->input($data, 'jasa');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('view-riwayat/' . $id);
    }

    function delete_jasa()
    {
        $id = $this->uri->segment(2);
        $iden = $this->uri->segment(3);
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'jasa');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('view-riwayat/' . $iden);
    }

    function update_operasi()
    {
        $id = htmlspecialchars($this->input->post('id'));
        $nrp = htmlspecialchars($this->input->post('nrp'));
        $nama = htmlspecialchars($this->input->post('nama'));
        $tahun = htmlspecialchars($this->input->post('tahun'));
        $data = array(
            'nama' => $nama,
            'nrp' => $nrp,
            'tahun' => $tahun
        );
        $this->M_default->input($data, 'operasi');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('view-riwayat/' . $id);
    }

    function delete_operasi()
    {
        $id = $this->uri->segment(2);
        $iden = $this->uri->segment(3);
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'operasi');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('view-riwayat/' . $iden);
    }

    function update_penugasan()
    {
        $id = htmlspecialchars($this->input->post('id'));
        $nrp = htmlspecialchars($this->input->post('nrp'));
        $nama = htmlspecialchars($this->input->post('nama'));
        $tahun = htmlspecialchars($this->input->post('tahun'));
        $negara = htmlspecialchars($this->input->post('negara'));
        $data = array(
            'nama' => $nama,
            'nrp' => $nrp,
            'tahun' => $tahun,
            'negara' => $negara
        );
        $this->M_default->input($data, 'penugasan');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('view-riwayat/' . $id);
    }

    function delete_penugasan()
    {
        $id = $this->uri->segment(2);
        $iden = $this->uri->segment(3);
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'penugasan');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('view-riwayat/' . $iden);
    }

    function update_kepangkatan()
    {
        $id = htmlspecialchars($this->input->post('id'));
        $nrp = htmlspecialchars($this->input->post('nrp'));
        $pangkat = htmlspecialchars($this->input->post('pangkat'));
        $tmt = htmlspecialchars($this->input->post('tmt'));
        $skep = htmlspecialchars($this->input->post('skep'));

        $data = array(
            'pangkat' => $pangkat,
            'nrp' => $nrp,
            'tmt' => $tmt,
            'skep' => $skep

        );

        $this->M_default->input($data, 'kepangkatan');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('view-riwayat/' . $id);
    }

    function delete_kepangkatan()
    {
        $id = $this->uri->segment(2);
        $iden = $this->uri->segment(3);
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'kepangkatan');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('view-riwayat/' . $iden);
    }

    function update_jabatan_r()
    {
        $id = htmlspecialchars($this->input->post('id'));
        $nrp = htmlspecialchars($this->input->post('nrp'));
        $nama = htmlspecialchars($this->input->post('nama'));
        $tmt = htmlspecialchars($this->input->post('tmt'));
        $skep = htmlspecialchars($this->input->post('skep'));
        $data = array(
            'nama' => $nama,
            'nrp' => $nrp,
            'tmt' => $tmt,
            'skep' => $skep
        );
        $this->M_default->input($data, 'riwayat_jabatan');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('view-riwayat/' . $id);
    }

    function delete_jabatan_r()
    {
        $id = $this->uri->segment(2);
        $iden = $this->uri->segment(3);
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'riwayat_jabatan');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('view-riwayat/' . $iden);
    }

    function update_foto()
    {
        $foto = $_FILES['foto'];
        $id = $this->input->post('id');

        $config['upload_path']          = './public/uploads/img';
        $config['allowed_types']        = 'jpg|png|jpeg';
        $config['max_size']             = '1024';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('foto')) {
            $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .jpg .png .jpeg dengan ukuran maksimal 1 Mb');
        } else {
            $old_foto = $this->input->post('old_foto');
            if ($old_foto != 'image.png') {
                unlink(FCPATH . 'public/uploads/img/' . $old_foto);
            }
            $pic = $this->upload->data('file_name');
            $data = array(
                'foto' => $pic
            );
            $where = array(
                'id' => $id
            );

            $this->M_default->update($where, $data, 'pokok');
            $this->session->set_flashdata('message', 'foto telah diupload kedalam sistem, terima kasih !');
            redirect('view-riwayat/' . $id);
        }
        $this->session->set_flashdata('pesan', 'file yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .jpg .png .jpeg dengan ukuran maksimal 1 Mb');
        redirect('view-riwayat/' . $id);
    }

    function print_riwayat($id)
    {
        $get = $this->db->query("SELECT * FROM pokok where id='$id' ");
        foreach ($get->result_array() as $nrp) {
            $nrp = $nrp['nrp'];
        }
        $where = array('nrp' => $nrp);
        $where_pend_umum = array('nrp' => $nrp, 'kategori' => 'Umum');
        $where_bangum = array('nrp' => $nrp, 'kategori' => 'BANGUM');
        $where_bangspes = array('nrp' => $nrp, 'kategori' => 'BANGSPES');
        $where_bahasa1 = array('nrp' => $nrp, 'jenis' => 'ASING');
        $where_bahasa2 = array('nrp' => $nrp, 'jenis' => 'DAERAH');
        $data['title'] = 'Riwayat Hidup Singkat';
        $data['pokok'] = $this->M_default->edit($where, 'pokok')->result();
        $data['anak'] = $this->M_default->edit($where, 'anak')->result();
        $data['pendidikan1'] = $this->M_default->edit($where_pend_umum, 'pendidikan')->result();
        $data['pendidikan2'] = $this->M_default->edit($where_bangum, 'pendidikan')->result();
        $data['pendidikan3'] = $this->M_default->edit($where_bangspes, 'pendidikan')->result();
        $data['penugasan'] = $this->M_default->edit($where, 'penugasan')->result();
        $data['operasi'] = $this->M_default->edit($where, 'operasi')->result();
        $data['jasa'] = $this->M_default->edit($where, 'jasa')->result();
        $data['kepangkatan'] = $this->M_default->edit($where, 'kepangkatan')->result();
        $data['bahasa1'] = $this->M_default->edit($where_bahasa1, 'bahasa')->result();
        $data['bahasa2'] = $this->M_default->edit($where_bahasa2, 'bahasa')->result();

        $data['riwayat_jabatan'] = $this->M_default->edit($where, 'riwayat_jabatan')->result();

        $this->load->library('pdf');
        $this->pdf->setPaper('A4', 'potrait');
        $this->pdf->filename = "Riwayat hidup.pdf";
        $this->pdf->load_view('backend/output/riwayat-hidup', $data);
    }

    function pesan()
    {
        $data['title'] = 'Data Pesan';
        $data['user'] = $this->M_default->tampil_pesan()->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/comment', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function leader()
    {
        $data['title'] = 'Data Pimpinan';
        $data['user'] = $this->M_default->tampil_pimpinan()->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/pimpinan', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function add_pimpinan()
    {
        $nama = htmlspecialchars($this->input->post('nama'));
        $jabatan = htmlspecialchars($this->input->post('jabatan'));
        $ig = htmlspecialchars($this->input->post('ig'));
        $yt = htmlspecialchars($this->input->post('yt'));
        $fb = htmlspecialchars($this->input->post('fb'));

        $data = array(
            'jabatan' => $jabatan,
            'nama' => $nama,
            'ig' => $ig,
            'yt' => $yt,
            'fb' => $fb,
            'gambar' => 'image.png'

        );

        $this->M_default->input($data, 'pimpinan');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('pimpinan');
    }

    function delete_pimpinan()
    {
        $id = $this->uri->segment(2);
        $gambar = $this->uri->segment(3);
        $where = array('id' => $id);
        if ($gambar != 'image.png') {
            unlink(FCPATH . 'public/uploads/homepage/pimpinan/' . $gambar);
        }
        $this->M_default->hapus($where, 'pimpinan');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('pimpinan');
    }

    function update_pimpinan()
    {
        $id = $this->input->post('id');
        $nama = htmlspecialchars($this->input->post('nama'));
        $jabatan = htmlspecialchars($this->input->post('jabatan'));
        $ig = htmlspecialchars($this->input->post('ig'));
        $yt = htmlspecialchars($this->input->post('yt'));
        $fb = htmlspecialchars($this->input->post('fb'));

        $data = array(
            'jabatan' => $jabatan,
            'nama' => $nama,
            'ig' => $ig,
            'yt' => $yt,
            'fb' => $fb
        );
        $where = array(
            'id' => $id
        );

        $this->M_default->update($where, $data, 'pimpinan');
        $this->session->set_flashdata('message', 'data telah diperbarui kedalam sistem, terima kasih !');
        redirect('pimpinan');
    }

    function update_foto_pimp()
    {
        $gambar = $_FILES['gambar'];
        $id = $this->input->post('id');

        $config['upload_path']          = './public/uploads/homepage/pimpinan';
        $config['allowed_types']        = 'jpg|png|jpeg';
        $config['max_size']             = '1024';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('gambar')) {
            $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .jpg .png .jpeg dengan ukuran maksimal 1 Mb');
        } else {
            $old_gambar = $this->input->post('old_gambar');
            if ($old_gambar != 'image.png') {
                unlink(FCPATH . 'public/uploads/homepage/pimpinan/' . $old_gambar);
            }
            $pic = $this->upload->data('file_name');
            $data = array(
                'gambar' => $pic
            );
            $where = array(
                'id' => $id
            );

            $this->M_default->update($where, $data, 'pimpinan');
            $this->session->set_flashdata('message', 'diperbarui');
            redirect('pimpinan');
        }
        $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .jpg .png .jpeg dengan ukuran maksimal 1 Mb');
        redirect('pimpinan');
    }

    function berita()
    {
        $data['title'] = 'Data Berita';
        $data['user'] = $this->M_default->tampil_berita()->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/berita', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function add_berita()
    {
        $data['title'] = 'Data Berita';
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/berita-add', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function berita_add()
    {
        $judul = htmlspecialchars($this->input->post('judul'));
        $quotes = htmlspecialchars($this->input->post('quotes'));
        $kategori = htmlspecialchars($this->input->post('kategori'));
        $isi = $this->input->post('isi');
        date_default_timezone_set('Asia/Jakarta');
        $waktu = date('d-m-Y H:i:s');

        $data = array(
            'quotes' => $quotes,
            'judul' => $judul,
            'kategori' => $kategori,
            'isi' => $isi,
            'waktu' => $waktu,
            'gambar' => 'image.png'

        );

        $this->M_default->input($data, 'berita');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('news');
    }

    function edit_berita($id)
    {
        $data['title'] = 'Data Berita';
        $where = array('id' => $id);
        $data['user'] = $this->M_default->edit($where, 'berita')->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/berita-edit', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function update_berita()
    {
        $id = $this->input->post('id');
        $judul = htmlspecialchars($this->input->post('judul'));
        $quotes = htmlspecialchars($this->input->post('quotes'));
        $kategori = htmlspecialchars($this->input->post('kategori'));
        $isi = $this->input->post('isi');
        date_default_timezone_set('Asia/Jakarta');
        $waktu = date('d-m-Y H:i:s');
        $data = array(
            'quotes' => $quotes,
            'judul' => $judul,
            'kategori' => $kategori,
            'isi' => $isi,
            'waktu' => $waktu
        );
        $where = array(
            'id' => $id
        );

        $this->M_default->update($where, $data, 'berita');
        $this->session->set_flashdata('message', 'data telah diperbarui kedalam sistem, terima kasih !');
        redirect('news');
    }

    function update_foto_berita()
    {
        $gambar = $_FILES['gambar'];
        $id = $this->input->post('id');

        $config['upload_path']          = './public/uploads/homepage/berita';
        $config['allowed_types']        = 'jpg|png|jpeg';
        $config['max_size']             = '1024';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('gambar')) {
            $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .jpg .png .jpeg dengan ukuran maksimal 1 Mb');
        } else {
            $old_gambar = $this->input->post('old_gambar');
            if ($old_gambar != 'image.png') {
                unlink(FCPATH . 'public/uploads/homepage/berita/' . $old_gambar);
            }
            $pic = $this->upload->data('file_name');
            $data = array(
                'gambar' => $pic
            );
            $where = array(
                'id' => $id
            );

            $this->M_default->update($where, $data, 'berita');
            $this->session->set_flashdata('message', 'data telah diperbarui kedalam sistem, terima kasih !');
            redirect('news');
        }
        $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .jpg .png .jpeg dengan ukuran maksimal 1 Mb');
        redirect('news');
    }

    function delete_berita()
    {
        $id = $this->uri->segment(2);
        $gambar = $this->uri->segment(3);
        $where = array('id' => $id);
        if ($gambar != 'image.png') {
            unlink(FCPATH . 'public/uploads/homepage/berita/' . $gambar);
        }
        $this->M_default->hapus($where, 'berita');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('news');
    }

    function surat_menyurat()
    {
        $data['title'] = 'Database File';
        $data['user'] = $this->M_default->tampil_database()->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/surat-menyurat', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function add_file()
    {
        $pdf = $_FILES['pdf'];
        $config['upload_path']          = './public/uploads/database';
        $config['allowed_types']        = 'PDF|pdf';
        $config['max_size']             = '3000';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('pdf')) {
            $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
        } else {
            date_default_timezone_set('Asia/Jakarta');
            $waktu = date('Y-m-d H:i:s');
            $nama = $this->input->post('nama');
            $oleh = $this->input->post('oleh');
            $pic = $this->upload->data('file_name');

            $data = array(
                'nama' => $nama,
                'oleh' => $oleh,
                'tgl_masuk' => $waktu,
                'pdf' => $pic
            );

            $this->M_default->input($data, 'data_base');
            $this->session->set_flashdata('message', 'data telah diperbarui dari dalam sistem, terima kasih !');
            redirect('surat-menyurat');
        }
        $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
        redirect('surat-menyurat');
    }

    function update_file()
    {
        $id = $this->input->post('id');
        $pdf = $_FILES['pdf']['name'];
        $nama = $this->input->post('nama');
        $oleh = $this->input->post('oleh');
        date_default_timezone_set('Asia/Jakarta');
        $waktu = date('Y-m-d H:i:s');

        if ($pdf != '') {

            $config['upload_path']          = './public/uploads/database';
            $config['allowed_types']        = 'PDF|pdf';
            $config['max_size']             = '5000';
            $this->load->library('upload', $config);


            if (!$this->upload->do_upload('pdf')) {
                $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
            } else {
                $old_pdf = $this->input->post('old_pdf');
                if ($old_pdf != '') {
                    unlink(FCPATH . 'public/uploads/database/' . $old_pdf);
                }
                $pic = $this->upload->data('file_name');
                $data = array(
                    'nama' => $nama,
                    'oleh' => $oleh,
                    'tgl_masuk' => $waktu,
                    'pdf' => $pic
                );

                $where = array(
                    'id' => $id
                );

                $this->M_default->update($where, $data, 'data_base');
                $this->session->set_flashdata('message', 'data telah diperbarui dari dalam sistem, terima kasih !');
                redirect('surat-menyurat');
            }
            $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
            redirect('surat-menyurat');
        } else {
            $data = array(
                'nama' => $nama,
                'oleh' => $oleh,
                'tgl_masuk' => $waktu
            );

            $where = array(
                'id' => $id
            );

            $this->M_default->update($where, $data, 'data_base');
            $this->session->set_flashdata('message', 'data telah diperbarui dari dalam sistem, terima kasih !');
            redirect('surat-menyurat');
        }
    }

    function delete_file()
    {
        $id = $this->uri->segment(2);
        $where = array('id' => $id);
        $file = $this->uri->segment(3);
        $this->M_default->hapus($where, 'data_base');
        unlink(FCPATH . 'public/uploads/database/' . $file);
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('surat-menyurat');
    }

    function download_file()
    {
        $id = $this->uri->segment(2);
        $get = $this->db->query("SELECT * FROM data_base where id='$id' ");
        foreach ($get->result_array() as $file) {
            $files = $file['pdf'];
        }
        force_download('./public/uploads/database/' . $files, NULL);
    }

    function denpomgar()
    {
        $data['title'] = 'Detasemen POM';
        $data['user'] = $this->M_default->tampil_kendaraan()->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/denpomgar', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function add_kendaraan()
    {
        $name = htmlspecialchars($this->input->post('name'));
        $jenis = htmlspecialchars($this->input->post('jenis'));
        $kondisi = htmlspecialchars($this->input->post('kondisi'));
        $nomor = $this->input->post('nomor');
        date_default_timezone_set('Asia/Jakarta');
        $updated_at = date('Y-m-d H:i:s');
        $expired = htmlspecialchars($this->input->post('expired'));
        $pemilik = htmlspecialchars($this->input->post('pemilik'));
        $rangka = htmlspecialchars($this->input->post('rangka'));
        $tahun_buat = htmlspecialchars($this->input->post('tahun_buat'));
        $register = htmlspecialchars($this->input->post('register'));
        $warna = htmlspecialchars($this->input->post('warna'));
        $cc = htmlspecialchars($this->input->post('cc'));
        $alamat_pj = htmlspecialchars($this->input->post('alamat_pj'));
        $petugas = htmlspecialchars($this->input->post('petugas'));
        $nohp_pj = htmlspecialchars($this->input->post('nohp_pj'));
        $data = array(
            'jenis' => $jenis,
            'name' => $name,
            'kondisi' => $kondisi,
            'nomor' => $nomor,
            'created_at' => $updated_at,
            'updated_at' => $updated_at,
            'expired' => $expired,
            'pemilik' => $pemilik,
            'rangka' => $rangka,
            'tahun_buat' => $tahun_buat,
            'register' => $register,
            'warna' => $warna,
            'cc' => $cc,
            'alamat_pj' => $alamat_pj,
            'nohp_pj' => $nohp_pj,
            'petugas' => $petugas

        );

        $this->M_default->input($data, 'kendaraan');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('denpom');
    }

    function update_kendaraan()
    {
        $id = $this->input->post('id');
        $name = htmlspecialchars($this->input->post('name'));
        $jenis = htmlspecialchars($this->input->post('jenis'));
        $kondisi = htmlspecialchars($this->input->post('kondisi'));
        $nomor = $this->input->post('nomor');
        date_default_timezone_set('Asia/Jakarta');
        $updated_at = date('Y-m-d H:i:s');
        $expired = htmlspecialchars($this->input->post('expired'));
        $pemilik = htmlspecialchars($this->input->post('pemilik'));
        $rangka = htmlspecialchars($this->input->post('rangka'));
        $tahun_buat = htmlspecialchars($this->input->post('tahun_buat'));
        $register = htmlspecialchars($this->input->post('register'));
        $warna = htmlspecialchars($this->input->post('warna'));
        $cc = htmlspecialchars($this->input->post('cc'));
        $alamat_pj = htmlspecialchars($this->input->post('alamat_pj'));
        $petugas = htmlspecialchars($this->input->post('petugas'));
        $nohp_pj = htmlspecialchars($this->input->post('nohp_pj'));
        $data = array(
            'jenis' => $jenis,
            'name' => $name,
            'kondisi' => $kondisi,
            'nomor' => $nomor,
            'updated_at' => $updated_at,
            'expired' => $expired,
            'pemilik' => $pemilik,
            'rangka' => $rangka,
            'tahun_buat' => $tahun_buat,
            'register' => $register,
            'warna' => $warna,
            'cc' => $cc,
            'alamat_pj' => $alamat_pj,
            'nohp_pj' => $nohp_pj,
            'petugas' => $petugas

        );
        $where = array(
            'id' => $id
        );

        $this->M_default->update($where, $data, 'kendaraan');
        $this->session->set_flashdata('message', 'data telah diperbarui kedalam sistem, terima kasih !');
        redirect('denpom');
    }

    function delete_kendaraan($id)
    {
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'kendaraan');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('denpom');
    }

    function pemakaman()
    {
        $data['title'] = 'Pemakaman';
        $data['user'] = $this->M_default->tampil_pemakaman()->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/pemakaman', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function berita_kematian()
    {
        $data['title'] = 'Pemakaman';
        $where = array('status' => 'Melapor');
        $data['user'] = $this->M_default->edit($where, 'kematian')->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/berita-kematian', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function add_berita_kematian()
    {
        $pelapor = htmlspecialchars($this->input->post('pelapor'));
        $nohp_pelapor = htmlspecialchars($this->input->post('nohp_pelapor'));
        $email_pelapor = htmlspecialchars($this->input->post('email_pelapor'));
        $nama = $this->input->post('nama');
        $nrp = $this->input->post('nrp');
        date_default_timezone_set('Asia/Jakarta');
        $waktu_buat = date('Y-m-d H:i:s');
        $pangkat = htmlspecialchars($this->input->post('pangkat'));
        $jabatan = htmlspecialchars($this->input->post('jabatan'));
        $kesatuan = htmlspecialchars($this->input->post('kesatuan'));
        $agama = htmlspecialchars($this->input->post('agama'));
        $tpt_lahir = htmlspecialchars($this->input->post('tpt_lahir'));
        $tgl_lahir = htmlspecialchars($this->input->post('tgl_lahir'));
        $alamat = htmlspecialchars($this->input->post('alamat'));

        $anak_ke = htmlspecialchars($this->input->post('anak_ke'));
        $bapak = htmlspecialchars($this->input->post('bapak'));
        $ibu = htmlspecialchars($this->input->post('ibu'));
        $meninggalkan = htmlspecialchars($this->input->post('meninggalkan'));
        $tgl_meninggal = htmlspecialchars($this->input->post('tgl_meninggal'));
        $pukul = htmlspecialchars($this->input->post('pukul'));
        $dimana = htmlspecialchars($this->input->post('dimana'));
        $penyebab = htmlspecialchars($this->input->post('penyebab'));
        $upacara = htmlspecialchars($this->input->post('upacara'));

        $data = array(
            'nohp_pelapor' => $nohp_pelapor,
            'pelapor' => $pelapor,
            'email_pelapor' => $email_pelapor,
            'nama' => $nama,
            'nrp' => $nrp,
            'waktu_buat' => $waktu_buat,
            'pangkat' => $pangkat,
            'jabatan' => $jabatan,
            'kesatuan' => $kesatuan,
            'agama' => $agama,
            'tpt_lahir' => $tpt_lahir,
            'tgl_lahir' => $tgl_lahir,
            'alamat' => $alamat,
            'anak_ke' => $anak_ke,
            'bapak' => $bapak,
            'ibu' => $ibu,
            'meninggalkan' => $meninggalkan,
            'tgl_meninggal' => $tgl_meninggal,
            'pukul' => $pukul,
            'dimana' => $dimana,
            'penyebab' => $penyebab,
            'upacara' => $upacara,
            'status' => 'Melapor'

        );



        $this->M_default->input($data, 'kematian');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('berita-kematian');
    }

    function update_berita_kematian()
    {
        $id = $this->input->post('id');
        $pelapor = htmlspecialchars($this->input->post('pelapor'));
        $nohp_pelapor = htmlspecialchars($this->input->post('nohp_pelapor'));
        $email_pelapor = htmlspecialchars($this->input->post('email_pelapor'));
        $nama = $this->input->post('nama');
        $nrp = $this->input->post('nrp');
        date_default_timezone_set('Asia/Jakarta');
        $waktu_buat = date('Y-m-d H:i:s');
        $pangkat = htmlspecialchars($this->input->post('pangkat'));
        $jabatan = htmlspecialchars($this->input->post('jabatan'));
        $kesatuan = htmlspecialchars($this->input->post('kesatuan'));
        $agama = htmlspecialchars($this->input->post('agama'));
        $tpt_lahir = htmlspecialchars($this->input->post('tpt_lahir'));
        $tgl_lahir = htmlspecialchars($this->input->post('tgl_lahir'));
        $alamat = htmlspecialchars($this->input->post('alamat'));

        $anak_ke = htmlspecialchars($this->input->post('anak_ke'));
        $bapak = htmlspecialchars($this->input->post('bapak'));
        $ibu = htmlspecialchars($this->input->post('ibu'));
        $meninggalkan = htmlspecialchars($this->input->post('meninggalkan'));
        $tgl_meninggal = htmlspecialchars($this->input->post('tgl_meninggal'));
        $pukul = htmlspecialchars($this->input->post('pukul'));
        $dimana = htmlspecialchars($this->input->post('dimana'));
        $penyebab = htmlspecialchars($this->input->post('penyebab'));
        $keterangan = htmlspecialchars($this->input->post('keterangan'));
        $upacara = htmlspecialchars($this->input->post('upacara'));
        $rencana_dimakamkan = htmlspecialchars($this->input->post('rencana_dimakamkan'));

        $data = array(
            'nohp_pelapor' => $nohp_pelapor,
            'pelapor' => $pelapor,
            'email_pelapor' => $email_pelapor,
            'nama' => $nama,
            'nrp' => $nrp,
            'waktu_buat' => $waktu_buat,
            'pangkat' => $pangkat,
            'jabatan' => $jabatan,
            'kesatuan' => $kesatuan,
            'agama' => $agama,
            'tpt_lahir' => $tpt_lahir,
            'tgl_lahir' => $tgl_lahir,
            'alamat' => $alamat,
            'anak_ke' => $anak_ke,
            'bapak' => $bapak,
            'ibu' => $ibu,
            'rencana_dimakamkan' => $rencana_dimakamkan,
            'keterangan' => $keterangan,
            'meninggalkan' => $meninggalkan,
            'tgl_meninggal' => $tgl_meninggal,
            'pukul' => $pukul,
            'dimana' => $dimana,
            'upacara' => $upacara,
            'penyebab' => $penyebab

        );
        $where = array(
            'id' => $id
        );

        $this->M_default->update($where, $data, 'kematian');
        $this->session->set_flashdata('message', 'data telah diperbarui kedalam sistem, terima kasih !');
        redirect('berita-kematian');
    }

    function delete_berita_kematian($id)
    {
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'kematian');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('berita-kematian');
    }

    function ajukan_watzah($id)
    {
        $id = $this->uri->segment(2);
        $status = 'Diajukan';

        $data = array(
            'status' => $status
        );
        $where = array(
            'id' => $id
        );

        $this->M_default->update($where, $data, 'kematian');
        $this->session->set_flashdata('message', 'data telah diajukan kedalam sistem, terima kasih !');
        redirect('berita-kematian');
    }

    function pengajuan_watzah()
    {
        $data['title'] = 'Pemakaman';
        $where = array('status' => 'Diajukan');
        $data['user'] = $this->M_default->edit($where, 'kematian')->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/pengajuan-watzah', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function selesaikan_watzah($id)
    {
        $id = $this->uri->segment(2);
        $status = 'Selesai';

        $data = array(
            'status' => $status
        );
        $where = array(
            'id' => $id
        );

        $this->M_default->update($where, $data, 'kematian');
        $this->session->set_flashdata('message', 'data telah diajukan kedalam sistem, terima kasih !');
        redirect('pengajuan-watzah');
    }

    function selesai_watzah()
    {
        $data['title'] = 'Pemakaman';
        $where = array('status' => 'Selesai');
        $data['user'] = $this->M_default->edit($where, 'kematian')->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/selesai-watzah', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function view_data_kematian($id)
    {
        $data['title'] = 'Pemakaman';
        $where = array('id' => $id);
        $data['user'] = $this->M_default->edit($where, 'kematian')->result();
        $get = $this->db->query("SELECT * FROM kematian WHERE id = '$id' ");
        foreach ($get->result_array() as $nrp) {
            $nrp = $nrp['nrp'];
        }
        $where2 = array('nrp' => $nrp);
        $data['berkas'] = $this->M_default->edit($where2, 'berkas_watzah')->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/berkas-watzah', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function berkas_upload()
    {
        $pdf = $_FILES['pdf'];
        $id = $this->input->post('id');
        $nrp = $this->input->post('nrp');
        $caption = $this->input->post('caption');


        $config['upload_path']          = './public/uploads/homepage/berkas';
        $config['allowed_types']        = 'PDF|pdf';
        $config['max_size']             = '3000';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('pdf')) {
            $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
        } else {
            $pic = $this->upload->data('file_name');
            $data = array(
                'nrp' => $nrp,
                'caption' => $caption,
                'status' => 'T',
                'pdf' => $pic
            );

            $this->M_default->input($data, 'berkas_watzah');
            $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
            redirect('view-data-kematian/' . $id);
        }
        $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
        redirect('view-data-kematian/' . $id);
    }

    function delete_berkas_watzah()
    {
        $id = $this->uri->segment(2);
        $where = array('id' => $id);
        $tni = $this->uri->segment(3);

        $get = $this->db->query("SELECT * FROM berkas_watzah join kematian on berkas_watzah.nrp = kematian.nrp where berkas_watzah.id='$id' ");
        foreach ($get->result_array() as $nrp) {
            $nrp = $nrp['id'];
        }
        $this->M_default->hapus($where, 'berkas_watzah');
        unlink(FCPATH . 'public/uploads/homepage/berkas/' . $tni);
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('view-data-kematian/' . $nrp);
    }

    function full_berkas($id)
    {
        $data['title'] = 'Pemakaman';
        $where = array('id' => $id);
        $data['user'] = $this->M_default->edit($where, 'berkas_watzah')->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/berkas-full', $data);
        $this->load->view('backend/admin/templates/footer');
    }

    function feed_survey()
    {
        $data['title'] = 'Survey';
        $data['user'] = $this->M_default->tampil_survey()->result();
        $this->load->view('backend/admin/templates/sidebar', $data);
        $this->load->view('backend/admin/feed-survey', $data);
        $this->load->view('backend/admin/templates/footer');
    }
}
