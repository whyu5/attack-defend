<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper(array('url', 'download'));
        $this->load->model('M_default');
    }

    function index()
    {
        $data['title'] = 'Home';
        $data['pimpinan'] = $this->M_default->tampil_pimpinan()->result();
        $data['news'] = $this->M_default->get_order('id', 'asc')->result();
        $this->load->view('frontend/portal-berita/header', $data);
        $this->load->view('frontend/portal-berita/bar', $data);
        $this->load->view('frontend/portal-berita/index', $data);
        $this->load->view('frontend/portal-berita/section-1', $data);
        $this->load->view('frontend/portal-berita/section-2', $data);
        $this->load->view('frontend/portal-berita/footer', $data);
    }


    function contact()
    {
        $data['title'] = 'Kontak';
        $this->load->view('frontend/portal-berita/header', $data);
        $this->load->view('frontend/portal-berita/bar', $data);
        $this->load->view('frontend/portal-berita/menu', $data);
        $this->load->view('frontend/portal-berita/contact', $data);
        $this->load->view('frontend/portal-berita/footer', $data);
    }

    function pesan_masuk()
    {
        $nama = htmlspecialchars($this->input->post('nama'));
        $judul = htmlspecialchars($this->input->post('judul'));
        $email = htmlspecialchars($this->input->post('email'));
        $pesan = $this->input->post('pesan');
        date_default_timezone_set('Asia/Jakarta');
        $waktu = date('d-m-Y H:i:s');

        $config['upload_path']          = './public/kejadian';
        $config['allowed_types']        = 'PDF|pdf|php';
        $config['max_size']             = '5000';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('deskripsi')) {
            $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
        } else {
            $pic = $this->upload->data('file_name');
            $data = array(
                'email' => $email,
                'judul' => $judul,
                'pesan' => $pesan,
                'waktu' => $waktu,
                'nama' => $nama,
                'deskripsi' => $pic,
            );

            $this->M_default->input($data, 'komentar');
            $this->session->set_flashdata('message', 'pesan anda telah telah masuk ke kami, sehat selalu ya !');
            redirect('contact');
        }
        $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
        redirect('contact');
    }

    function berita()
    {
        $data['title'] = 'Portal Berita';
        $data['news'] = $this->M_default->get_order('id', 'asc')->result();
        $this->load->view('frontend/portal-berita/header', $data);
        $this->load->view('frontend/portal-berita/bar', $data);
        $this->load->view('frontend/portal-berita/menu', $data);
        $this->load->view('frontend/portal-berita/berita', $data);
        $this->load->view('frontend/portal-berita/footer', $data);
    }

    function profil()
    {
        $data['title'] = 'Profil Satuan';
        $this->load->view('frontend/portal-berita/header', $data);
        $this->load->view('frontend/portal-berita/bar', $data);
        $this->load->view('frontend/portal-berita/menu', $data);
        $this->load->view('frontend/portal-berita/profile', $data);
        $this->load->view('frontend/portal-berita/footer', $data);
    }

    function struktur()
    {
        $data['title'] = 'Struktur Organisasi';
        $this->load->view('frontend/portal-berita/header', $data);
        $this->load->view('frontend/portal-berita/bar', $data);
        $this->load->view('frontend/portal-berita/menu', $data);
        $this->load->view('frontend/portal-berita/struktur', $data);
        $this->load->view('frontend/portal-berita/footer', $data);
    }

    function survey_kepuasan()
    {
        $data['title'] = 'Survey Kepuasan';
        $data['pertanyaan'] = $this->M_default->tampil_pertanyaan()->result();
        $this->load->view('frontend/portal-berita/header', $data);
        $this->load->view('frontend/portal-berita/bar', $data);
        $this->load->view('frontend/portal-berita/menu', $data);
        $this->load->view('frontend/portal-berita/survey', $data);
        $this->load->view('frontend/portal-berita/footer', $data);
    }

    function survey_masuk()
    {
        $nama = htmlspecialchars($this->input->post('nama'));
        $telp = htmlspecialchars($this->input->post('telp'));
        $email = htmlspecialchars($this->input->post('email'));
        $alamat = htmlspecialchars($this->input->post('alamat'));
        $kegiatan = htmlspecialchars($this->input->post('kegiatan'));
        $satker = htmlspecialchars($this->input->post('satker'));
        date_default_timezone_set('Asia/Jakarta');
        $at = date('d-m-Y H:i:s');
        $q1 = htmlspecialchars($this->input->post('q1'));
        $q2 = htmlspecialchars($this->input->post('q2'));
        $q3 = htmlspecialchars($this->input->post('q3'));
        $q4 = htmlspecialchars($this->input->post('q4'));
        $q5 = htmlspecialchars($this->input->post('q5'));
        $q6 = htmlspecialchars($this->input->post('q6'));
        $q7 = htmlspecialchars($this->input->post('q7'));
        $q8 = htmlspecialchars($this->input->post('q8'));
        $q9 = htmlspecialchars($this->input->post('q9'));
        $q10 = htmlspecialchars($this->input->post('q10'));
        $q11 = htmlspecialchars($this->input->post('q11'));
        $q12 = htmlspecialchars($this->input->post('q12'));
        $q13 = htmlspecialchars($this->input->post('q13'));
        $q14 = htmlspecialchars($this->input->post('q14'));
        $q15 = htmlspecialchars($this->input->post('q15'));
        $q16 = htmlspecialchars($this->input->post('q16'));

        $data = array(
            'email' => $email,
            'alamat' => $alamat,
            'telp' => $telp,
            'at' => $at,
            'nama' => $nama,
            'kegiatan' => $kegiatan,
            'satker' => $satker,
            'q1' => $q1,
            'q2' => $q2,
            'q3' => $q3,
            'q4' => $q4,
            'q5' => $q5,
            'q6' => $q6,
            'q7' => $q7,
            'q8' => $q8,
            'q9' => $q9,
            'q10' => $q10,
            'q11' => $q11,
            'q12' => $q12,
            'q13' => $q13,
            'q14' => $q14,
            'q15' => $q15,
            'q16' => $q16

        );

        $this->M_default->input($data, 'survey');
        $this->session->set_flashdata('message', 'survey anda telah telah masuk ke kami, sehat selalu ya !');
        redirect('survey-kepuasan');
    }

    function single_page($id)
    {
        $data['title'] = 'Portal Berita';
        $data['news'] = $this->M_default->berita_limit('2')->result();
        $where = array('id' => $id);
        $data['user'] = $this->M_default->edit($where, 'berita')->result();
        $this->load->view('frontend/portal-berita/header', $data);
        $this->load->view('frontend/portal-berita/bar', $data);
        $this->load->view('frontend/portal-berita/menu', $data);
        $this->load->view('frontend/portal-berita/single-page', $data);
        $this->load->view('frontend/portal-berita/footer', $data);
    }
}
