<?php

class AuthPublic extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('m_default');
        $this->load->library('session');
    }

    function index()
    {
        if ($this->session->userdata('status') != "") {
            redirect(base_url("dashboard-m"));
        }
        $this->load->view('auth/login-m');
    }

    function verification()
    {
        if ($this->session->userdata('status') != "") {
            redirect(base_url("dashboard"));
        }
        $nrp = htmlspecialchars($this->input->post('nrp'));
        $tgl_lahir = htmlspecialchars($this->input->post('tgl_lahir'));
        $where = array(
            'nrp' => $nrp,
            'tgl_lahir' => $tgl_lahir
        );

        $cek = $this->m_default->cek_login('pokok', $where)->row_array();
        if ($cek) {
            $data_session = array(
                    'nrp' => $nrp,
                    'status' => 'Anggota'
                );

                $this->session->set_userdata($data_session);
                $this->session->set_flashdata('message', 'verifikasi data sukses, anda dapat berselancar');
                redirect(base_url("dashboard-m"));
        } else {
            $this->session->set_flashdata('message', 'Gagal mem-verifikasi data, cek kembali NRP/NIP dan Tanggal lahir anda');
            redirect(base_url('/'));
        }
    }

    function logout()
    {
        $this->session->sess_destroy();
        redirect(base_url('auth-m'));
    }

    function info()
    {
        phpinfo();
    }
}
