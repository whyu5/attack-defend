<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pemakaman extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper(array('url', 'download'));

        if ($this->session->userdata('status') != "Pemakaman") {
            redirect(base_url("auth"));
        } else {

            $this->load->model('M_default');
            $this->load->helper('url');
        }
    }

    function index()
    {
        $data['title'] = 'Dashboard';
        $data['user'] = $this->M_default->tampil_pesan()->result();
        $this->load->view('backend/pemakaman/templates/sidebar', $data);
        $this->load->view('backend/pemakaman/dashboard', $data);
        $this->load->view('backend/pemakaman/templates/footer');
    }

    function berita_kematian()
    {
        $data['title'] = 'Pemakaman';
        $where = array('status' => 'Melapor');
        $data['user'] = $this->M_default->edit($where, 'kematian')->result();
        $this->load->view('backend/pemakaman/templates/sidebar', $data);
        $this->load->view('backend/pemakaman/berita-kematian', $data);
        $this->load->view('backend/pemakaman/templates/footer');
    }

    function add_berita_kematian()
    {
        $pelapor = htmlspecialchars($this->input->post('pelapor'));
        $nohp_pelapor = htmlspecialchars($this->input->post('nohp_pelapor'));
        $email_pelapor = htmlspecialchars($this->input->post('email_pelapor'));
        $nama = $this->input->post('nama');
        $nrp = $this->input->post('nrp');
        date_default_timezone_set('Asia/Jakarta');
        $waktu_buat = date('Y-m-d H:i:s');
        $pangkat = htmlspecialchars($this->input->post('pangkat'));
        $jabatan = htmlspecialchars($this->input->post('jabatan'));
        $kesatuan = htmlspecialchars($this->input->post('kesatuan'));
        $agama = htmlspecialchars($this->input->post('agama'));
        $tpt_lahir = htmlspecialchars($this->input->post('tpt_lahir'));
        $tgl_lahir = htmlspecialchars($this->input->post('tgl_lahir'));
        $alamat = htmlspecialchars($this->input->post('alamat'));

        $anak_ke = htmlspecialchars($this->input->post('anak_ke'));
        $bapak = htmlspecialchars($this->input->post('bapak'));
        $ibu = htmlspecialchars($this->input->post('ibu'));
        $meninggalkan = htmlspecialchars($this->input->post('meninggalkan'));
        $tgl_meninggal = htmlspecialchars($this->input->post('tgl_meninggal'));
        $pukul = htmlspecialchars($this->input->post('pukul'));
        $dimana = htmlspecialchars($this->input->post('dimana'));
        $penyebab = htmlspecialchars($this->input->post('penyebab'));
        $upacara = htmlspecialchars($this->input->post('upacara'));

        $data = array(
            'nohp_pelapor' => $nohp_pelapor,
            'pelapor' => $pelapor,
            'email_pelapor' => $email_pelapor,
            'nama' => $nama,
            'nrp' => $nrp,
            'waktu_buat' => $waktu_buat,
            'pangkat' => $pangkat,
            'jabatan' => $jabatan,
            'kesatuan' => $kesatuan,
            'agama' => $agama,
            'tpt_lahir' => $tpt_lahir,
            'tgl_lahir' => $tgl_lahir,
            'alamat' => $alamat,
            'anak_ke' => $anak_ke,
            'bapak' => $bapak,
            'ibu' => $ibu,
            'meninggalkan' => $meninggalkan,
            'tgl_meninggal' => $tgl_meninggal,
            'pukul' => $pukul,
            'dimana' => $dimana,
            'penyebab' => $penyebab,
            'upacara' => $upacara,
            'status' => 'Melapor'

        );



        $this->M_default->input($data, 'kematian');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('laporan-pm');
    }

    function update_berita_kematian()
    {
        $id = $this->input->post('id');
        $pelapor = htmlspecialchars($this->input->post('pelapor'));
        $nohp_pelapor = htmlspecialchars($this->input->post('nohp_pelapor'));
        $email_pelapor = htmlspecialchars($this->input->post('email_pelapor'));
        $nama = $this->input->post('nama');
        $nrp = $this->input->post('nrp');
        date_default_timezone_set('Asia/Jakarta');
        $waktu_buat = date('Y-m-d H:i:s');
        $pangkat = htmlspecialchars($this->input->post('pangkat'));
        $jabatan = htmlspecialchars($this->input->post('jabatan'));
        $kesatuan = htmlspecialchars($this->input->post('kesatuan'));
        $agama = htmlspecialchars($this->input->post('agama'));
        $tpt_lahir = htmlspecialchars($this->input->post('tpt_lahir'));
        $tgl_lahir = htmlspecialchars($this->input->post('tgl_lahir'));
        $alamat = htmlspecialchars($this->input->post('alamat'));

        $anak_ke = htmlspecialchars($this->input->post('anak_ke'));
        $bapak = htmlspecialchars($this->input->post('bapak'));
        $ibu = htmlspecialchars($this->input->post('ibu'));
        $meninggalkan = htmlspecialchars($this->input->post('meninggalkan'));
        $tgl_meninggal = htmlspecialchars($this->input->post('tgl_meninggal'));
        $pukul = htmlspecialchars($this->input->post('pukul'));
        $dimana = htmlspecialchars($this->input->post('dimana'));
        $penyebab = htmlspecialchars($this->input->post('penyebab'));
        $keterangan = htmlspecialchars($this->input->post('keterangan'));
        $upacara = htmlspecialchars($this->input->post('upacara'));
        $rencana_dimakamkan = htmlspecialchars($this->input->post('rencana_dimakamkan'));
        $arah = htmlspecialchars($this->input->post('arah'));


        $data = array(
            'nohp_pelapor' => $nohp_pelapor,
            'pelapor' => $pelapor,
            'email_pelapor' => $email_pelapor,
            'nama' => $nama,
            'nrp' => $nrp,
            'waktu_buat' => $waktu_buat,
            'pangkat' => $pangkat,
            'jabatan' => $jabatan,
            'kesatuan' => $kesatuan,
            'agama' => $agama,
            'tpt_lahir' => $tpt_lahir,
            'tgl_lahir' => $tgl_lahir,
            'alamat' => $alamat,
            'anak_ke' => $anak_ke,
            'bapak' => $bapak,
            'ibu' => $ibu,
            'rencana_dimakamkan' => $rencana_dimakamkan,
            'keterangan' => $keterangan,
            'meninggalkan' => $meninggalkan,
            'tgl_meninggal' => $tgl_meninggal,
            'pukul' => $pukul,
            'dimana' => $dimana,
            'upacara' => $upacara,
            'penyebab' => $penyebab

        );
        $where = array(
            'id' => $id
        );

        $this->M_default->update($where, $data, 'kematian');
        $this->session->set_flashdata('message', 'data telah diperbarui kedalam sistem, terima kasih !');
        redirect($arah);
    }

    function delete_berita_kematian($id)
    {
        $where = array('id' => $id);
        $arah = $this->uri->segment(3);
        if ($arah == '1') {
            $arah = 'dash-pm';
        } else if ($arah == '2') {
            $arah = 'laporan-pm';
        };
        $this->M_default->hapus($where, 'kematian');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect($arah);
    }

    function ajukan_watzah($id)
    {
        $id = $this->uri->segment(2);
        $status = 'Diajukan';

        $data = array(
            'status' => $status
        );
        $where = array(
            'id' => $id
        );

        $this->M_default->update($where, $data, 'kematian');
        $this->session->set_flashdata('message', 'data telah diajukan kedalam sistem, terima kasih !');
        redirect('dash-pm');
    }

    function pengajuan_watzah()
    {
        $data['title'] = 'Pengajuan Watzah';
        $where = array('status' => 'Diajukan');
        $data['user'] = $this->M_default->edit($where, 'kematian')->result();
        $this->load->view('backend/pemakaman/templates/sidebar', $data);
        $this->load->view('backend/pemakaman/pengajuan-watzah', $data);
        $this->load->view('backend/pemakaman/templates/footer');
    }

    function selesaikan_watzah($id)
    {
        $id = $this->uri->segment(2);
        $status = 'Selesai';

        $data = array(
            'status' => $status
        );
        $where = array(
            'id' => $id
        );

        $this->M_default->update($where, $data, 'kematian');
        $this->session->set_flashdata('message', 'data telah diajukan kedalam sistem, terima kasih !');
        redirect('pengajuan-watzahpm');
    }

    function selesai_watzah()
    {
        $data['title'] = 'Pengajuan Selesai';
        $where = array('status' => 'Selesai');
        $data['user'] = $this->M_default->edit($where, 'kematian')->result();
        $this->load->view('backend/pemakaman/templates/sidebar', $data);
        $this->load->view('backend/pemakaman/selesai-watzah', $data);
        $this->load->view('backend/pemakaman/templates/footer');
    }

    function view_data_kematian($id)
    {
        $data['title'] = 'Pemakaman';
        $where = array('id' => $id);
        $data['user'] = $this->M_default->edit($where, 'kematian')->result();
        $get = $this->db->query("SELECT * FROM kematian WHERE id = '$id' ");
        foreach ($get->result_array() as $nrp) {
            $nrp = $nrp['nrp'];
        }
        $where2 = array('nrp' => $nrp);
        $data['berkas'] = $this->M_default->edit($where2, 'berkas_watzah')->result();
        $this->load->view('backend/pemakaman/templates/sidebar', $data);
        $this->load->view('backend/pemakaman/berkas-watzah', $data);
        $this->load->view('backend/pemakaman/templates/footer');
    }

    function berkas_upload()
    {
        $pdf = $_FILES['pdf'];
        $id = $this->input->post('id');
        $nrp = $this->input->post('nrp');
        $caption = $this->input->post('caption');


        $config['upload_path']          = './public/uploads/homepage/berkas';
        $config['allowed_types']        = 'PDF|pdf';
        $config['max_size']             = '3000';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('pdf')) {
            $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
        } else {
            $pic = $this->upload->data('file_name');
            $data = array(
                'nrp' => $nrp,
                'caption' => $caption,
                'status' => 'T',
                'pdf' => $pic
            );

            $this->M_default->input($data, 'berkas_watzah');
            $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
            redirect('view-pm/' . $id);
        }
        $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
        redirect('view-pm/' . $id);
    }

    function delete_berkas_watzah()
    {
        $id = $this->uri->segment(2);
        $where = array('id' => $id);
        $tni = $this->uri->segment(3);

        $get = $this->db->query("SELECT * FROM berkas_watzah join kematian on berkas_watzah.nrp = kematian.nrp where berkas_watzah.id='$id' ");
        foreach ($get->result_array() as $nrp) {
            $nrp = $nrp['id'];
        }
        $this->M_default->hapus($where, 'berkas_watzah');
        unlink(FCPATH . 'public/uploads/homepage/berkas/' . $tni);
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('view-pm/' . $nrp);
    }

    function full_berkas($id)
    {
        $data['title'] = 'Pemakaman';
        $where = array('id' => $id);
        $data['user'] = $this->M_default->edit($where, 'berkas_watzah')->result();
        $this->load->view('backend/pemakaman/templates/sidebar', $data);
        $this->load->view('backend/pemakaman/berkas-full', $data);
        $this->load->view('backend/pemakaman/templates/footer');
    }

    function pemakaman()
    {
        $data['title'] = 'Manual';
        $data['user'] = $this->M_default->tampil_pemakaman()->result();
        $this->load->view('backend/pemakaman/templates/sidebar', $data);
        $this->load->view('backend/pemakaman/pemakaman', $data);
        $this->load->view('backend/pemakaman/templates/footer');
    }

    function laporsen()
    {
        $data['title'] = 'Sendiri';
        $where = array('status' => 'Melapor');
        $data['user'] = $this->M_default->edit($where, 'kematian')->result();
        $this->load->view('backend/pemakaman/templates/sidebar', $data);
        $this->load->view('backend/pemakaman/laporan', $data);
        $this->load->view('backend/pemakaman/templates/footer');
    }
}
