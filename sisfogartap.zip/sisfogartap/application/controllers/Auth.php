<?php

class Auth extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('m_default');
        $this->load->library('session');
    }

    function index()
    {
        if ($this->session->userdata('status') != "") {
            redirect(base_url("dashboard"));
        }
        $this->load->view('auth/login');
    }

    function verification()
    {
        if ($this->session->userdata('status') != "") {
            redirect(base_url("dashboard"));
        }
        $username = htmlspecialchars($this->input->post('username'));
        $password = htmlspecialchars($this->input->post('password'));
        $where = array(
            'username' => $username
        );

        $cek = $this->m_default->cek_login('user', $where)->row_array();
        if ($cek) {
            if (password_verify($password, $cek['password'])) {
                if ($cek['level'] == 'Administrator') {
                    $data_session = array(
                        'nama' => $username,
                        'status' => "Administrator"
                    );

                    $this->session->set_userdata($data_session);
                    $this->session->set_flashdata('message', 'verifikasi data sukses, anda dapat berselancar sebagai administrator');
                    redirect(base_url("dashboard"));
                } else if ($cek['level'] == 'Penerangan') {
                    $data_session = array(
                        'nama' => $username,
                        'status' => "Penerangan"
                    );

                    $this->session->set_userdata($data_session);
                    $this->session->set_flashdata('message', 'verifikasi data sukses, anda dapat berselancar sebagai administrator');
                    redirect(base_url("dashboard-p"));
                } else if ($cek['level'] == 'Pemakaman') {
                    $data_session = array(
                        'nama' => $username,
                        'status' => "Pemakaman"
                    );

                    $this->session->set_userdata($data_session);
                    $this->session->set_flashdata('message', 'verifikasi data sukses, anda dapat berselancar sebagai administrator');
                    redirect(base_url("dashboard-pm"));
                } else if ($cek['level'] == 'Personel') {
                    $data_session = array(
                        'nama' => $username,
                        'status' => "Personel"
                    );

                    $this->session->set_userdata($data_session);
                    $this->session->set_flashdata('message', 'verifikasi data sukses, anda dapat berselancar sebagai administrator');
                    redirect(base_url("dashboard-ps"));
                } else if ($cek['level'] == 'Sekretariat') {
                    $data_session = array(
                        'nama' => $username,
                        'status' => "Sekretariat"
                    );

                    $this->session->set_userdata($data_session);
                    $this->session->set_flashdata('message', 'verifikasi data sukses, anda dapat berselancar sebagai administrator');
                    redirect(base_url("dashboard-s"));
                } else if ($cek['level'] == 'Denpom') {
                    $data_session = array(
                        'nama' => $username,
                        'status' => "Denpom"
                    );

                    $this->session->set_userdata($data_session);
                    $this->session->set_flashdata('message', 'verifikasi data sukses, anda dapat berselancar sebagai administrator');
                    redirect(base_url("dashboard-d"));
                } else {
                    $this->session->set_flashdata('message', 'Gagal mem-verifikasi data, cek kembali username dan password anda');
                    redirect(base_url('auth'));
                }
            } else {

                $this->session->set_flashdata('message', 'Gagal mem-verifikasi data, cek kembali username dan password anda');
                redirect(base_url('auth'));
            }
        } else {
            $this->session->set_flashdata('message', 'Gagal mem-verifikasi data, cek kembali username dan password anda');
            redirect(base_url('/'));
        }
    }

    function logout()
    {
        $this->session->sess_destroy();
        redirect(base_url('auth'));
    }

    function info()
    {
        phpinfo();
    }
}
