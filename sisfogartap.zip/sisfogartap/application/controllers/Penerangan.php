<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Penerangan extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper(array('url', 'download'));

        if ($this->session->userdata('status') != "Penerangan") {
            redirect(base_url("auth"));
        } else {

            $this->load->model('M_default');
            $this->load->helper('url');
        }
    }

    function index()
    {
        $data['title'] = 'Dashboard';
        $data['user'] = $this->M_default->tampil_pesan()->result();
        $this->load->view('backend/penerangan/templates/sidebar', $data);
        $this->load->view('backend/penerangan/dashboard', $data);
        $this->load->view('backend/penerangan/templates/footer');
    }

    function buletin()
    {
        $data['title'] = 'Data Buletin';
        $data['user'] = $this->M_default->tampil_berita()->result();
        $this->load->view('backend/penerangan/templates/sidebar', $data);
        $this->load->view('backend/penerangan/berita', $data);
        $this->load->view('backend/penerangan/templates/footer');
    }

    function add_buletin()
    {
        $data['title'] = 'Data Buletin';
        $this->load->view('backend/penerangan/templates/sidebar', $data);
        $this->load->view('backend/penerangan/berita-add', $data);
        $this->load->view('backend/penerangan/templates/footer');
    }

    function buletin_add()
    {
        $judul = htmlspecialchars($this->input->post('judul'));
        $quotes = htmlspecialchars($this->input->post('quotes'));
        $kategori = htmlspecialchars($this->input->post('kategori'));
        $isi = $this->input->post('isi');
        date_default_timezone_set('Asia/Jakarta');
        $waktu = date('d-m-Y H:i:s');

        $data = array(
            'quotes' => $quotes,
            'judul' => $judul,
            'kategori' => $kategori,
            'isi' => $isi,
            'waktu' => $waktu,
            'gambar' => 'image.png'

        );

        $this->M_default->input($data, 'berita');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('buletin');
    }

    function edit_buletin($id)
    {
        $data['title'] = 'Data Berita';
        $where = array('id' => $id);
        $data['user'] = $this->M_default->edit($where, 'berita')->result();
        $this->load->view('backend/penerangan/templates/sidebar', $data);
        $this->load->view('backend/penerangan/berita-edit', $data);
        $this->load->view('backend/penerangan/templates/footer');
    }

    function update_buletin()
    {
        $id = $this->input->post('id');
        $judul = htmlspecialchars($this->input->post('judul'));
        $quotes = htmlspecialchars($this->input->post('quotes'));
        $kategori = htmlspecialchars($this->input->post('kategori'));
        $isi = $this->input->post('isi');
        date_default_timezone_set('Asia/Jakarta');
        $waktu = date('d-m-Y H:i:s');
        $data = array(
            'quotes' => $quotes,
            'judul' => $judul,
            'kategori' => $kategori,
            'isi' => $isi,
            'waktu' => $waktu
        );
        $where = array(
            'id' => $id
        );

        $this->M_default->update($where, $data, 'berita');
        $this->session->set_flashdata('message', 'data telah diperbarui kedalam sistem, terima kasih !');
        redirect('buletin');
    }

    function update_foto_buletin()
    {
        $gambar = $_FILES['gambar'];
        $id = $this->input->post('id');

        $config['upload_path']          = './public/uploads/homepage/berita';
        $config['allowed_types']        = 'jpg|png|jpeg';
        $config['max_size']             = '1024';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('gambar')) {
            $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .jpg .png .jpeg dengan ukuran maksimal 1 Mb');
        } else {
            $old_gambar = $this->input->post('old_gambar');
            if ($old_gambar != 'image.png') {
                unlink(FCPATH . 'public/uploads/homepage/berita/' . $old_gambar);
            }
            $pic = $this->upload->data('file_name');
            $data = array(
                'gambar' => $pic
            );
            $where = array(
                'id' => $id
            );

            $this->M_default->update($where, $data, 'berita');
            $this->session->set_flashdata('message', 'data telah diperbarui kedalam sistem, terima kasih !');
            redirect('buletin');
        }
        $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .jpg .png .jpeg dengan ukuran maksimal 1 Mb');
        redirect('buletin');
    }

    function delete_buletin()
    {
        $id = $this->uri->segment(2);
        $gambar = $this->uri->segment(3);
        $where = array('id' => $id);
        if ($gambar != 'image.png') {
            unlink(FCPATH . 'public/uploads/homepage/berita/' . $gambar);
        }
        $this->M_default->hapus($where, 'berita');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('buletin');
    }

    function pimpinan()
    {
        $data['title'] = 'Profil Pimpinan';
        $data['user'] = $this->M_default->tampil_pimpinan()->result();
        $this->load->view('backend/penerangan/templates/sidebar', $data);
        $this->load->view('backend/penerangan/pimpinan', $data);
        $this->load->view('backend/penerangan/templates/footer');
    }

    function add_pimpinan()
    {
        $nama = htmlspecialchars($this->input->post('nama'));
        $jabatan = htmlspecialchars($this->input->post('jabatan'));
        $ig = htmlspecialchars($this->input->post('ig'));
        $yt = htmlspecialchars($this->input->post('yt'));
        $fb = htmlspecialchars($this->input->post('fb'));

        $data = array(
            'jabatan' => $jabatan,
            'nama' => $nama,
            'ig' => $ig,
            'yt' => $yt,
            'fb' => $fb,
            'gambar' => 'image.png'

        );

        $this->M_default->input($data, 'pimpinan');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('profil-pim');
    }

    function delete_pimpinan()
    {
        $id = $this->uri->segment(2);
        $gambar = $this->uri->segment(3);
        $where = array('id' => $id);
        if ($gambar != 'image.png') {
            unlink(FCPATH . 'public/uploads/homepage/pimpinan/' . $gambar);
        }
        $this->M_default->hapus($where, 'pimpinan');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('profil-pim');
    }

    function update_pimpinan()
    {
        $id = $this->input->post('id');
        $nama = htmlspecialchars($this->input->post('nama'));
        $jabatan = htmlspecialchars($this->input->post('jabatan'));
        $ig = htmlspecialchars($this->input->post('ig'));
        $yt = htmlspecialchars($this->input->post('yt'));
        $fb = htmlspecialchars($this->input->post('fb'));

        $data = array(
            'jabatan' => $jabatan,
            'nama' => $nama,
            'ig' => $ig,
            'yt' => $yt,
            'fb' => $fb
        );
        $where = array(
            'id' => $id
        );

        $this->M_default->update($where, $data, 'pimpinan');
        $this->session->set_flashdata('message', 'data telah diperbarui kedalam sistem, terima kasih !');
        redirect('profil-pim');
    }

    function update_foto_pimp()
    {
        $gambar = $_FILES['gambar'];
        $id = $this->input->post('id');

        $config['upload_path']          = './public/uploads/homepage/pimpinan';
        $config['allowed_types']        = 'jpg|png|jpeg';
        $config['max_size']             = '1024';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('gambar')) {
            $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .jpg .png .jpeg dengan ukuran maksimal 1 Mb');
        } else {
            $old_gambar = $this->input->post('old_gambar');
            if ($old_gambar != 'image.png') {
                unlink(FCPATH . 'public/uploads/homepage/pimpinan/' . $old_gambar);
            }
            $pic = $this->upload->data('file_name');
            $data = array(
                'gambar' => $pic
            );
            $where = array(
                'id' => $id
            );

            $this->M_default->update($where, $data, 'pimpinan');
            $this->session->set_flashdata('message', 'diperbarui');
            redirect('profil-pim');
        }
        $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .jpg .png .jpeg dengan ukuran maksimal 1 Mb');
        redirect('profil-pim');
    }
}
