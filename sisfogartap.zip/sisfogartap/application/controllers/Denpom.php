<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Denpom extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper(array('url', 'download'));

        if ($this->session->userdata('status') != "Denpom") {
            redirect(base_url("auth"));
        } else {

            $this->load->model('M_default');
            $this->load->helper('url');
        }
    }

    function index()
    {
        $data['title'] = 'Dashboard';
        $data['user'] = $this->M_default->tampil_pesan()->result();
        $this->load->view('backend/denpom/templates/sidebar', $data);
        $this->load->view('backend/denpom/dashboard', $data);
        $this->load->view('backend/denpom/templates/footer');
    }

    function denpomgar()
    {
        $data['title'] = 'Detasemen POM';
        $data['user'] = $this->M_default->tampil_kendaraan()->result();
        $this->load->view('backend/denpom/templates/sidebar', $data);
        $this->load->view('backend/denpom/ran', $data);
        $this->load->view('backend/denpom/templates/footer');
    }

    function add_kendaraan()
    {
        $name = htmlspecialchars($this->input->post('name'));
        $jenis = htmlspecialchars($this->input->post('jenis'));
        $kondisi = htmlspecialchars($this->input->post('kondisi'));
        $nomor = $this->input->post('nomor');
        date_default_timezone_set('Asia/Jakarta');
        $updated_at = date('Y-m-d H:i:s');
        $expired = htmlspecialchars($this->input->post('expired'));
        $pemilik = htmlspecialchars($this->input->post('pemilik'));
        $rangka = htmlspecialchars($this->input->post('rangka'));
        $tahun_buat = htmlspecialchars($this->input->post('tahun_buat'));
        $register = htmlspecialchars($this->input->post('register'));
        $warna = htmlspecialchars($this->input->post('warna'));
        $cc = htmlspecialchars($this->input->post('cc'));
        $alamat_pj = htmlspecialchars($this->input->post('alamat_pj'));
        $petugas = htmlspecialchars($this->input->post('petugas'));
        $nohp_pj = htmlspecialchars($this->input->post('nohp_pj'));
        $data = array(
            'jenis' => $jenis,
            'name' => $name,
            'kondisi' => $kondisi,
            'nomor' => $nomor,
            'created_at' => $updated_at,
            'updated_at' => $updated_at,
            'expired' => $expired,
            'pemilik' => $pemilik,
            'rangka' => $rangka,
            'tahun_buat' => $tahun_buat,
            'register' => $register,
            'warna' => $warna,
            'cc' => $cc,
            'alamat_pj' => $alamat_pj,
            'nohp_pj' => $nohp_pj,
            'petugas' => $petugas

        );

        $this->M_default->input($data, 'kendaraan');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('ran-dinas');
    }

    function update_kendaraan()
    {
        $id = $this->input->post('id');
        $name = htmlspecialchars($this->input->post('name'));
        $jenis = htmlspecialchars($this->input->post('jenis'));
        $kondisi = htmlspecialchars($this->input->post('kondisi'));
        $nomor = $this->input->post('nomor');
        date_default_timezone_set('Asia/Jakarta');
        $updated_at = date('Y-m-d H:i:s');
        $expired = htmlspecialchars($this->input->post('expired'));
        $pemilik = htmlspecialchars($this->input->post('pemilik'));
        $rangka = htmlspecialchars($this->input->post('rangka'));
        $tahun_buat = htmlspecialchars($this->input->post('tahun_buat'));
        $register = htmlspecialchars($this->input->post('register'));
        $warna = htmlspecialchars($this->input->post('warna'));
        $cc = htmlspecialchars($this->input->post('cc'));
        $alamat_pj = htmlspecialchars($this->input->post('alamat_pj'));
        $petugas = htmlspecialchars($this->input->post('petugas'));
        $nohp_pj = htmlspecialchars($this->input->post('nohp_pj'));
        $data = array(
            'jenis' => $jenis,
            'name' => $name,
            'kondisi' => $kondisi,
            'nomor' => $nomor,
            'updated_at' => $updated_at,
            'expired' => $expired,
            'pemilik' => $pemilik,
            'rangka' => $rangka,
            'tahun_buat' => $tahun_buat,
            'register' => $register,
            'warna' => $warna,
            'cc' => $cc,
            'alamat_pj' => $alamat_pj,
            'nohp_pj' => $nohp_pj,
            'petugas' => $petugas

        );
        $where = array(
            'id' => $id
        );

        $this->M_default->update($where, $data, 'kendaraan');
        $this->session->set_flashdata('message', 'data telah diperbarui kedalam sistem, terima kasih !');
        redirect('ran-dinas');
    }

    function delete_kendaraan($id)
    {
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'kendaraan');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('ran-dinas');
    }
}
