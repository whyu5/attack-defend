<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Anggota extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper(array('url', 'download'));

        if ($this->session->userdata('status') != "Anggota") {
            redirect(base_url("auth-m"));
        } else {

            $this->load->model('M_default');
            $this->load->helper('url');
        }
    }

    function index()
    {
        $data['title'] = 'Dashboard';
        $data['user'] = $this->M_default->tampil_pesan()->result();
        $this->load->view('backend-m/templates/sidebar', $data);
        $this->load->view('backend-m/dashboard', $data);
        $this->load->view('backend-m/templates/footer');
    }

    function view_dosir()
    {
        $data['title'] = 'Data Dosir Elektronik';
        $nrp = $this->session->userdata('nrp');
        $where = array('nrp' => $nrp);
        $data['user'] = $this->M_default->edit($where, 'pokok')->result();

        $get = $this->db->query("SELECT * FROM pokok WHERE nrp = '$nrp' ");
        foreach ($get->result_array() as $nrp) {
            $nrp = $nrp['nrp'];
        }

        $where2 = array('nrp' => $nrp);
        $data['dosir'] = $this->M_default->edit($where2, 'dosir')->result();
        $this->load->view('backend-m/templates/sidebar', $data);
        $this->load->view('backend-m/dosir', $data);
        $this->load->view('backend-m/templates/footer');
    }

    function delete_dosir()
    {
        $id = $this->uri->segment(2);
        $where = array('id' => $id);
        $tni = $this->uri->segment(3);

        $get = $this->db->query("SELECT * FROM dosir join pokok on dosir.nrp = pokok.nrp where dosir.id='$id' ");
        foreach ($get->result_array() as $nrp) {
            $nrp = $nrp['id'];
        }
        $this->M_default->hapus($where, 'dosir');
        unlink(FCPATH . 'public/uploads/pdf/' . $tni);
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('dosir-m');
    }

    function upload_dosir()
    {
        $pdf = $_FILES['pdf'];
        $id = $this->input->post('id');
        $nrp = $this->input->post('nrp');
        $idnya = $this->input->post('idnya');

        $config['upload_path']          = './public/uploads/pdf';
        $config['allowed_types']        = 'PDF|pdf';
        $config['max_size']             = '5000';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('pdf')) {
            $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
        } else {
            $old_pdf = $this->input->post('old_pdf');
            if ($old_pdf != '') {
                unlink(FCPATH . 'public/uploads/pdf/' . $old_pdf);
            }
            $pic = $this->upload->data('file_name');
            $data = array(
                'pdf' => $pic,
                'status' => 'T'
            );

            $where = array(
                'id' => $idnya
            );

            $this->M_default->update($where, $data, 'dosir');
            $this->session->set_flashdata('message', 'data telah diperbarui dari dalam sistem, terima kasih !');
            redirect('dosir-m');
        }
        $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
        redirect('dosir-m');
    }

    function dosir_upload()
    {
        $pdf = $_FILES['pdf'];
        $id = $this->input->post('id');
        $nrp = $this->input->post('nrp');
        $caption = $this->input->post('caption');


        $config['upload_path']          = './public/uploads/pdf';
        $config['allowed_types']        = 'PDF|pdf';
        $config['max_size']             = '5000';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('pdf')) {
            $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
        } else {
            $pic = $this->upload->data('file_name');
            $data = array(
                'nrp' => $nrp,
                'caption' => $caption,
                'status' => 'T',
                'pdf' => $pic
            );

            $this->M_default->input($data, 'dosir');
            $this->session->set_flashdata('message', 'ditambah');
            redirect('dosir-m');
        }
        $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .pdf dengan ukuran maksimal 1 Mb');
        redirect('dosir-m');
    }

    function full_dosir($id)
    {
        $data['title'] = 'Data Dosir Elektronik';
        $where = array('id' => $id);
        $data['user'] = $this->M_default->edit($where, 'dosir')->result();
        $this->load->view('backend-m/templates/sidebar', $data);
        $this->load->view('backend-m/dosir-full', $data);
        $this->load->view('backend-m/templates/footer');
    }

    function blanko_dosir($nrp)
    {
        $where = array('nrp' => $nrp, 'status' => 'T');
        $user = $this->db->get_where('pokok', ['nrp' => $nrp],)->row_array();
        $data['nip'] = $user['nrp'];
        $data['nama'] = $user['nama'];
        $data['dosir'] = $this->M_default->edit($where, 'dosir')->result();
        $this->load->library('pdf');
        $this->pdf->setPaper('Legal', 'potrait');
        $this->pdf->filename = "Daftar Isi Dosir " . $nrp . ".pdf";
        $this->pdf->load_view('backend/output/blanko', $data);
    }

    function stiker_dosir($nrp)
    {
        $where = array('nrp' => $nrp);
        $user = $this->db->get_where('pokok', ['nrp' => $nrp])->row_array();
        $data['nip'] = $user['nrp'];
        $data['nama'] = $user['nama'];
        $data['dosir'] = $this->M_default->edit($where, 'dosir')->result();
        $this->load->library('pdf');
        $this->pdf->setPaper('Legal', 'landscape');
        $this->pdf->filename = "Stiker.pdf";
        $this->pdf->load_view('backend/output/sticker', $data);
    }

    function view_riwayat()
    {
        $data['title'] = 'Data Riwayat Hidup';
        $nrp = $this->session->userdata('nrp');
        $where = array('nrp' => $nrp);
        $data['user'] = $this->M_default->edit($where, 'pokok')->result();
        $get = $this->db->query("SELECT * FROM pokok WHERE nrp = '$nrp' ");
        foreach ($get->result_array() as $nrp) {
            $nrp = $nrp['nrp'];
        }

        $where_pend_umum = array('kategori' => 'Umum', 'nrp' => $nrp);
        $where_bangum = array('kategori' => 'BANGUM', 'nrp' => $nrp);
        $where_bangspes = array('kategori' => 'BANGSPES', 'nrp' => $nrp);
        $where_penugasan = array('nrp' => $nrp);
        $where_riwayat = array('nrp' => $nrp);
        $where_operasi = array('nrp' => $nrp);
        $where_jasa = array('nrp' => $nrp);
        $where_kepang = array('nrp' => $nrp);
        $where_bahasa = array('nrp' => $nrp);
        $where_anak = array('nrp' => $nrp);

        $data['pendidikan1'] = $this->M_default->edit($where_pend_umum, 'pendidikan')->result();
        $data['pendidikan2'] = $this->M_default->edit($where_bangum, 'pendidikan')->result();
        $data['pendidikan3'] = $this->M_default->edit($where_bangspes, 'pendidikan')->result();
        $data['penugasan'] = $this->M_default->edit($where_penugasan, 'penugasan')->result();
        $data['riwayat_jabatan'] = $this->M_default->edit($where_riwayat, 'riwayat_jabatan')->result();
        $data['operasi'] = $this->M_default->edit($where_operasi, 'operasi')->result();
        $data['jasa'] = $this->M_default->edit($where_jasa, 'jasa')->result();
        $data['kepangkatan'] = $this->M_default->edit($where_kepang, 'kepangkatan')->result();
        $data['bahasa'] = $this->M_default->edit($where_bahasa, 'bahasa')->result();
        $data['anak'] = $this->M_default->edit($where_anak, 'anak')->result();
        $this->load->view('backend-m/templates/sidebar', $data);
        $this->load->view('backend-m/riwayat', $data);
        $this->load->view('backend-m/templates/footer');
    }

    function update_pokok()
    {
        $id = $this->input->post('id');
        $tmt_jab = htmlspecialchars($this->input->post('tmt_jab'));
        $tgl_lahir = htmlspecialchars($this->input->post('tgl_lahir'));
        $tpt_lahir = htmlspecialchars($this->input->post('tpt_lahir'));
        $kategori = htmlspecialchars($this->input->post('kategori'));
        $sumber = htmlspecialchars($this->input->post('sumber'));
        $tpt_lahir_istri = htmlspecialchars($this->input->post('tpt_lahir_istri'));
        $pekerjaan = htmlspecialchars($this->input->post('pekerjaan'));
        $istri = htmlspecialchars($this->input->post('istri'));
        $ibu = htmlspecialchars($this->input->post('ibu'));
        $ayah = htmlspecialchars($this->input->post('ayah'));
        $berat = htmlspecialchars($this->input->post('berat'));
        $tinggi = htmlspecialchars($this->input->post('tinggi'));
        $goldar = htmlspecialchars($this->input->post('goldar'));
        $status_kawin = htmlspecialchars($this->input->post('status_kawin'));
        $agama = htmlspecialchars($this->input->post('agama'));
        $suku = htmlspecialchars($this->input->post('suku'));
        $tmt_tni = htmlspecialchars($this->input->post('tmt_tni'));
        $tmt_kat = htmlspecialchars($this->input->post('tmt_kat'));
        $tgl_lahir_istri = htmlspecialchars($this->input->post('tgl_lahir_istri'));
        $baju = htmlspecialchars($this->input->post('baju'));
        $celana = htmlspecialchars($this->input->post('celana'));
        $sepatu = htmlspecialchars($this->input->post('sepatu'));
        $topi = htmlspecialchars($this->input->post('topi'));
        $matra = htmlspecialchars($this->input->post('matra'));
        $alamat = htmlspecialchars($this->input->post('alamat'));


        $data = array(
            'tmt_jab' => $tmt_jab,
            'tgl_lahir' => $tgl_lahir,
            'tpt_lahir' => $tpt_lahir,
            'kategori' => $kategori,
            'sumber' => $sumber,
            'tmt_tni' => $tmt_tni,
            'tmt_kat' => $tmt_kat,
            'suku' => $suku,
            'agama' => $agama,
            'status_kawin' => $status_kawin,
            'goldar' => $goldar,
            'tinggi' => $tinggi,
            'berat' => $berat,
            'ayah' => $ayah,
            'ibu' => $ibu,
            'matra' => $matra,
            'istri' => $istri,
            'pekerjaan' => $pekerjaan,
            'tpt_lahir_istri' => $tpt_lahir_istri,
            'tgl_lahir_istri' => $tgl_lahir_istri,
            'baju' => $baju,
            'celana' => $celana,
            'sepatu' => $sepatu,
            'topi' => $topi,
            'alamat' => $alamat

        );

        $where = array(
            'id' => $id
        );

        $this->M_default->update($where, $data, 'pokok');
        $this->session->set_flashdata('message', 'data telah diperbarui dari dalam sistem, terima kasih !');
        redirect('riwayat-m');
    }

    function update_anak()
    {
        $nrp = htmlspecialchars($this->input->post('nrp-keturunan'));
        $nama = htmlspecialchars($this->input->post('nama'));
        $tpt_lahir = htmlspecialchars($this->input->post('tpt_lahir'));
        $tgl_lahir = htmlspecialchars($this->input->post('tgl_lahir'));

        $data = array(
            'nama' => $nama,
            'nrp' => $nrp,
            'tpt_lahir' => $tpt_lahir,
            'tgl_lahir' => $tgl_lahir

        );

        $this->M_default->input($data, 'anak');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('riwayat-m');
    }

    function delete_anak()
    {
        $id = $this->uri->segment(2);
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'anak');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('riwayat-m');
    }

    function update_pendidikan()
    {
        $id = htmlspecialchars($this->input->post('id'));
        $nrp = htmlspecialchars($this->input->post('nrp'));
        $kategori = htmlspecialchars($this->input->post('kategori'));
        $thun_lulus = htmlspecialchars($this->input->post('thun_lulus'));
        $nama = htmlspecialchars($this->input->post('nama'));
        $data = array(
            'nrp' => $nrp,
            'kategori' => $kategori,
            'thun_lulus' => $thun_lulus,
            'nama' => $nama
        );
        $this->M_default->input($data, 'pendidikan');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('riwayat-m');
    }

    function delete_pendidikan()
    {
        $id = $this->uri->segment(2);
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'pendidikan');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('riwayat-m');
    }

    function update_bahasa()
    {
        $id = htmlspecialchars($this->input->post('id'));
        $nrp = htmlspecialchars($this->input->post('nrp'));
        $bahasa = htmlspecialchars($this->input->post('bahasa'));
        $ket = htmlspecialchars($this->input->post('ket'));
        $jenis = htmlspecialchars($this->input->post('jenis'));

        $data = array(
            'bahasa' => $bahasa,
            'nrp' => $nrp,
            'jenis' => $jenis,
            'ket' => $ket

        );

        $this->M_default->input($data, 'bahasa');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('riwayat-m');
    }

    function delete_bahasa()
    {
        $id = $this->uri->segment(2);
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'bahasa');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('riwayat-m');
    }

    function update_jasa()
    {
        $id = htmlspecialchars($this->input->post('id'));
        $nrp = htmlspecialchars($this->input->post('nrp'));
        $nama = htmlspecialchars($this->input->post('nama'));
        $tahun = htmlspecialchars($this->input->post('tahun'));

        $data = array(
            'nama' => $nama,
            'nrp' => $nrp,
            'tahun' => $tahun

        );

        $this->M_default->input($data, 'jasa');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('riwayat-m');
    }

    function delete_jasa()
    {
        $id = $this->uri->segment(2);
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'jasa');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('riwayat-m');
    }

    function update_operasi()
    {
        $id = htmlspecialchars($this->input->post('id'));
        $nrp = htmlspecialchars($this->input->post('nrp'));
        $nama = htmlspecialchars($this->input->post('nama'));
        $tahun = htmlspecialchars($this->input->post('tahun'));
        $data = array(
            'nama' => $nama,
            'nrp' => $nrp,
            'tahun' => $tahun
        );
        $this->M_default->input($data, 'operasi');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('riwayat-m');
    }

    function delete_operasi()
    {
        $id = $this->uri->segment(2);
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'operasi');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('riwayat-m');
    }

    function update_penugasan()
    {
        $id = htmlspecialchars($this->input->post('id'));
        $nrp = htmlspecialchars($this->input->post('nrp'));
        $nama = htmlspecialchars($this->input->post('nama'));
        $tahun = htmlspecialchars($this->input->post('tahun'));
        $negara = htmlspecialchars($this->input->post('negara'));
        $data = array(
            'nama' => $nama,
            'nrp' => $nrp,
            'tahun' => $tahun,
            'negara' => $negara
        );
        $this->M_default->input($data, 'penugasan');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('riwayat-m');
    }

    function delete_penugasan()
    {
        $id = $this->uri->segment(2);
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'penugasan');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('riwayat-m');
    }

    function update_kepangkatan()
    {
        $id = htmlspecialchars($this->input->post('id'));
        $nrp = htmlspecialchars($this->input->post('nrp'));
        $pangkat = htmlspecialchars($this->input->post('pangkat'));
        $tmt = htmlspecialchars($this->input->post('tmt'));
        $skep = htmlspecialchars($this->input->post('skep'));

        $data = array(
            'pangkat' => $pangkat,
            'nrp' => $nrp,
            'tmt' => $tmt,
            'skep' => $skep

        );

        $this->M_default->input($data, 'kepangkatan');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('riwayat-m');
    }

    function delete_kepangkatan()
    {
        $id = $this->uri->segment(2);
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'kepangkatan');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('riwayat-m');
    }

    function update_jabatan_r()
    {
        $id = htmlspecialchars($this->input->post('id'));
        $nrp = htmlspecialchars($this->input->post('nrp'));
        $nama = htmlspecialchars($this->input->post('nama'));
        $tmt = htmlspecialchars($this->input->post('tmt'));
        $skep = htmlspecialchars($this->input->post('skep'));
        $data = array(
            'nama' => $nama,
            'nrp' => $nrp,
            'tmt' => $tmt,
            'skep' => $skep
        );
        $this->M_default->input($data, 'riwayat_jabatan');
        $this->session->set_flashdata('message', 'data telah ditambahkan kedalam sistem, terima kasih !');
        redirect('riwayat-m');
    }

    function delete_jabatan_r()
    {
        $id = $this->uri->segment(2);
        $where = array('id' => $id);
        $this->M_default->hapus($where, 'riwayat_jabatan');
        $this->session->set_flashdata('message', 'data telah dihapus dari dalam sistem, terima kasih !');
        redirect('riwayat-m');
    }

    function update_foto()
    {
        $foto = $_FILES['foto'];
        $id = $this->input->post('id');

        $config['upload_path']          = './public/uploads/img';
        $config['allowed_types']        = 'jpg|png|jpeg';
        $config['max_size']             = '1024';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('foto')) {
            $this->session->set_flashdata('pesan', 'File yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .jpg .png .jpeg dengan ukuran maksimal 1 Mb');
        } else {
            $old_foto = $this->input->post('old_foto');
            if ($old_foto != 'image.png') {
                unlink(FCPATH . 'public/uploads/img/' . $old_foto);
            }
            $pic = $this->upload->data('file_name');
            $data = array(
                'foto' => $pic
            );
            $where = array(
                'id' => $id
            );

            $this->M_default->update($where, $data, 'pokok');
            $this->session->set_flashdata('message', 'foto telah diupload kedalam sistem, terima kasih !');
            redirect('riwayat-m');
        }
        $this->session->set_flashdata('pesan', 'file yang anda masukan terindikasi salah format atau file terlalu besar, gunakan file dengan ekstensi .jpg .png .jpeg dengan ukuran maksimal 1 Mb');
        redirect('riwayat-m');
    }

    function print_riwayat($id)
    {
        $get = $this->db->query("SELECT * FROM pokok where id='$id' ");
        foreach ($get->result_array() as $nrp) {
            $nrp = $nrp['nrp'];
        }
        $where = array('nrp' => $nrp);
        $where_pend_umum = array('nrp' => $nrp, 'kategori' => 'Umum');
        $where_bangum = array('nrp' => $nrp, 'kategori' => 'BANGUM');
        $where_bangspes = array('nrp' => $nrp, 'kategori' => 'BANGSPES');
        $where_bahasa1 = array('nrp' => $nrp, 'jenis' => 'ASING');
        $where_bahasa2 = array('nrp' => $nrp, 'jenis' => 'DAERAH');
        $data['title'] = 'Riwayat Hidup Singkat';
        $data['pokok'] = $this->M_default->edit($where, 'pokok')->result();
        $data['anak'] = $this->M_default->edit($where, 'anak')->result();
        $data['pendidikan1'] = $this->M_default->edit($where_pend_umum, 'pendidikan')->result();
        $data['pendidikan2'] = $this->M_default->edit($where_bangum, 'pendidikan')->result();
        $data['pendidikan3'] = $this->M_default->edit($where_bangspes, 'pendidikan')->result();
        $data['penugasan'] = $this->M_default->edit($where, 'penugasan')->result();
        $data['operasi'] = $this->M_default->edit($where, 'operasi')->result();
        $data['jasa'] = $this->M_default->edit($where, 'jasa')->result();
        $data['kepangkatan'] = $this->M_default->edit($where, 'kepangkatan')->result();
        $data['bahasa1'] = $this->M_default->edit($where_bahasa1, 'bahasa')->result();
        $data['bahasa2'] = $this->M_default->edit($where_bahasa2, 'bahasa')->result();

        $data['riwayat_jabatan'] = $this->M_default->edit($where, 'riwayat_jabatan')->result();

        $this->load->library('pdf');
        $this->pdf->setPaper('A4', 'potrait');
        $this->pdf->filename = "Riwayat hidup.pdf";
        $this->pdf->load_view('backend/output/riwayat-hidup', $data);
    }
    
}