<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?php
    $no = 1;
    foreach ($pokok as $p) {
    ?>
    <?php } ?>
    <title><?= $title ?> - <?= $p->nrp ?></title>
    <style type="text/css">
        .line-title {
            border: 0;
            border-style: inset;
            border-top: 1px solid #000;
        }

        .collapsed {
            border-collapse: collapse;
        }
    </style>

</head>

<body style="margin: -30px; font-size:10px; font-family: sans-serif;">

    <table border="0" width="100%">
        <tr>
            <td width="200" align="center" style="line-height: 100%;">MARKAS BESAR TENTARA NASIONAL INDONESIA <br>
                KOMANDO GARNISUN TETAP II/BANDUNG <br>
                <hr class="line-title">
            </td>
            <td></td>
        </tr>
    </table>
    <h2 align="center" style="letter-spacing: 2px;"><b><u>&nbsp;RIWAYAT HIDUP SINGKAT</u></b></h2>
    <table class="collapsed" style="width: 100%; vertical-align: top;" border="0">
        <tr>
            <th colspan="9" align="left">I. <u>DATA POKOK</u></th>
        </tr>
        <tr>
            <td width="10">1.</td>
            <td width="70">NAMA LENGKAP</td>
            <td width="100">: <?= $p->nama; ?></td>
            <td width="10">10.</td>
            <td width="70">SUMBER TNI</td>
            <td width="60">: <?= $p->sumber; ?></td>
            <td width="10">19.</td>
            <td width="70">AYAH</td>
            <td width="100">: <?= $p->ayah; ?></td>
        </tr>
        <tr>
            <td>2.</td>
            <td>PANGKAT CORPS</td>
            <td>: <?= $p->pangkat; ?></td>
            <td>11.</td>
            <td>TMT TNI</td>
            <td>: <?= $p->tmt_tni; ?></td>
            <td>20.</td>
            <td>IBU</td>
            <td>: <?= $p->ibu; ?></td>
        </tr>
        <tr>
            <td>3.</td>
            <td width="70">NRP / NBI</td>
            <td width="100">: <?= $p->nrp; ?></td>
            <td>12.</td>
            <td width="70">SUKU BANGSA</td>
            <td width="60">: <?= $p->suku; ?></td>
            <td></td>
            <td width="70">a. NAMA ISTRI</td>
            <td width="100">: <?= $p->istri; ?></td>
        </tr>
        <tr>
            <td valign="top">4.</td>
            <td width="70" valign="top">JABATAN</td>
            <td width="100" valign="top">: <?= $p->jabatan; ?></td>
            <td valign="top">13.</td>
            <td width="70" valign="top">AGAMA</td>
            <td width="60" valign="top">: <?= $p->agama; ?></td>
            <td valign="top"></td>
            <td width="70" valign="top">b. PEKERJAAN</td>
            <td width="100" valign="top">: <?= $p->pekerjaan; ?></td>
        </tr>
        <tr>
            <td>5.</td>
            <td width="70">TMT JABATAN</td>
            <td width="100">: <?= $p->tmt_jab; ?></td>
            <td>14,</td>
            <td width="70">STATUS KAWIN</td>
            <td width="60">: <?= $p->status_kawin; ?></td>
            <td></td>
            <td width="70">b. TTL</td>
            <td width="100">: <?= $p->tpt_lahir_istri; ?>, <?= $p->tgl_lahir_istri; ?> </td>
        </tr>
        <tr>
            <td>6.</td>
            <td width="70">KESATUAN</td>
            <td width="100">: KOGARTAP II/BDG</td>
            <td>15.</td>
            <td width="70">GOL DARAH</td>
            <td width="60">: <?= $p->goldar; ?></td>
            <td>21.</td>
            <td width="70">JUMLAH ANAK</td>
            <td width="100">
                <?php
                $querys = $this->db->query("SELECT * from anak where nrp='$p->nrp'");
                $hasil = $querys->num_rows();
                ?>: <?= $hasil ?>
            </td>
        </tr>
        <tr>
            <td>7.</td>
            <td width="70">TANGGAL LAHIR</td>
            <td width="100">: <?= $p->tgl_lahir; ?></td>
            <td>16.</td>
            <td width="70">BAJU/CELANA</td>
            <td width="60">: <?= $p->baju; ?> / <?= $p->celana; ?></td>
            <td></td>
            <td width="70" rowspan="4" colspan="2" valign="top">
                <table style="width: 100%; border: none;">
                    <?php
                    $no = 'a';
                    foreach ($anak as $a) {
                    ?>
                        <tr>
                            <td valign="top"><?= $no++ ?>. <?= $a->nama ?></td>
                            <td valign="top">: <?= $a->tgl_lahir ?></td>
                        </tr>
                    <?php } ?>
                </table>
            </td>
        </tr>
        <tr>
            <td>8.</td>
            <td width="70">TEMPAT LAHIR</td>
            <td width="100">: <?= $p->tpt_lahir; ?></td>
            <td>17.</td>
            <td width="70">NO SEPATU/TOPI</td>
            <td width="60">: <?= $p->sepatu; ?> / <?= $p->topi; ?></td>
            <td></td>
        </tr>
        <tr>
            <td>9.</td>
            <td width="70">KATEGORI</td>
            <td width="100">: <?= $p->kategori; ?></td>
            <td>18.</td>
            <td width="70">TINGGI/BERAT</td>
            <td width="60">: <?= $p->tinggi; ?> CM / <?= $p->berat; ?> KG</td>
            <td></td>
        </tr>
        <tr>
            <td colspan="7"></td>
        </tr>
    </table>

    <table style="width: 100%; vertical-align: top;" border="0">
        <tr>
            <th colspan="3" align="left">II. <u>PENDIDIKAN</u></th>
        </tr>
        <tr>
            <th width="35%">II.A. <u>UMUM</u></th>
            <th colspan="2">II.B. <u>MILITER</u></th>
        </tr>
        <tr>
            <td valign="top">
                <table border="0" width="100%" style="vertical-align: top;">
                    <tr>
                        <td colspan="2">&nbsp;</td>
                    </tr>
                    <?php
                    $no = 1;
                    foreach ($pendidikan1 as $p1) {
                    ?>
                        <tr>
                            <td><?= $no++ ?>. <?= $p1->nama ?></td>
                            <td width="40">THN <?= $p1->thun_lulus ?></td>
                        </tr>
                    <?php } ?>
                </table>
            </td>
            <td width="30%" valign="top">
                <table border="0" width="100%">
                    <tr>
                        <th colspan="2" valign="top" align="left"><u>II.B.I.BANGUM</u></th>
                    </tr>
                    <?php
                    $no = 1;
                    foreach ($pendidikan2 as $p2) {
                    ?>
                        <tr>
                            <td><?= $no++ ?>. <?= $p2->nama ?></td>
                            <td width="40">THN <?= $p2->thun_lulus ?></td>
                        </tr>
                    <?php } ?>
                </table>
            </td>
            <td valign="top">
                <table border="0" width="100%">
                    <tr>
                        <th colspan="2" valign="top" align="left"><u>II.B.II.BANGSPES</u></th>
                    </tr>
                    <?php
                    $no = 1;
                    foreach ($pendidikan3 as $p3) {
                    ?>
                        <tr>
                            <td><?= $no++ ?>. <?= $p3->nama ?></td>
                            <td width="40">THN <?= $p3->thun_lulus ?></td>
                        </tr>
                    <?php } ?>
                </table>
            </td>
        </tr>
    </table>
    <br>
    <table width="100%" border="0">
        <tr valign="top">
            <th width="35%" align="left">III. <u>KECAKAPAN BAHASA</u></th>
            <th width="35%" align="left">IV. <u>TANDA JASA</u></th>
            <th width="35%" align="left">V. <u>RIWAYAT PENUGASAN OPERASI</u></th>
        </tr>
        <tr>
            <td valign="top">
                <table border="0" width="100%">
                    <tr>
                        <th colspan="2" valign="top"><u>III.A. BAHASA ASING</u></th>
                    </tr>
                    <?php
                    $no = 1;
                    foreach ($bahasa1 as $b1) {
                    ?>
                        <tr>
                            <td><?= $no++ ?>. <?= $b1->bahasa ?></td>
                            <td width="40" align="right"><?= $b1->ket ?></td>
                        </tr>
                    <?php } ?>
                </table>
                <table border="0" width="100%">
                    <tr>
                        <th colspan="2" valign="top"><u>III.B. BAHASA DAERAH</u></th>
                    </tr>
                    <?php
                    $no = 1;
                    foreach ($bahasa2 as $b2) {
                    ?>
                        <tr>
                            <td><?= $no++ ?>. <?= $b2->bahasa ?></td>
                            <td width="40" align="right"><?= $b2->ket ?></td>
                        </tr>
                    <?php } ?>
                </table>
            </td>
            <td valign="top">
                <table border="0" width="100%" style="vertical-align:top;">
                    <tr>
                        <th colspan="2" valign="top">&nbsp;</th>
                    </tr>
                    <?php
                    $no = 1;
                    foreach ($jasa as $j) {
                    ?>
                        <tr>
                            <td><?= $no++ ?>. <?= $j->nama ?></td>
                            <td width="40" align="right">THN <?= $j->tahun ?></td>
                        </tr>
                    <?php } ?>
                </table>
            </td>
            <td valign="top">
                <table border="0" width="100%" style="vertical-align:top;">
                    <tr>
                        <th colspan="2" valign="top">&nbsp;</th>
                    </tr>
                    <?php
                    $no = 1;
                    foreach ($operasi as $o) {
                    ?>
                        <tr>
                            <td><?= $no++ ?>. <?= $o->nama ?></td>
                            <td width="40" align="right">THN <?= $o->tahun ?></td>
                        </tr>
                    <?php } ?>
                </table>
            </td>
        </tr>
    </table>

    <br>
    <table width="100%" border="0">
        <tr>
            <th align="left">VI. <u>PENUGASAN LUAR NEGERI</u></th>
            <th align="left">VII. <u>RIWAYAT KEPANGKATAN</u></th>
        </tr>
        <tr>
            <td valign="top">
                <table border="0" width="100%">
                    <tr>
                        <th valign="top">MACAM TUGAS</th>
                        <th valign="top">
                            <center>TAHUN</center>
                        </th>
                        <th valign="top">NEGARA TUJUAN</th>
                    </tr>
                    <?php
                    $no = 1;
                    foreach ($penugasan as $pn) {
                    ?>
                        <tr>
                            <td><?= $no++ ?>. <?= $pn->nama ?></td>
                            <td width="40" align="center"><?= $pn->tahun ?></td>
                            <td><?= $pn->negara ?></td>
                        </tr>
                    <?php } ?>
                </table>
            </td>
            <td valign="top">
                <table border="0" width="100%">
                    <tr>
                        <th valign="top">PANGKAT</th>
                        <th valign="top">
                            <center>TMT</center>
                        </th>
                        <th valign="top">NOMOR SKEP</th>
                    </tr>
                    <?php
                    $no = 1;
                    foreach ($kepangkatan as $k) {
                    ?>
                        <tr>
                            <td><?= $no++ ?>. <?= $k->pangkat ?></td>
                            <td width="40" align="center"><?= $k->tmt ?></td>
                            <td><?= $k->skep ?></td>
                        </tr>
                    <?php } ?>
                </table>
            </td>
        </tr>
    </table>

    <br>
    <table width="70%" border="0">
        <tr valign="top">
            <th colspan="3" align="left">VIII. <u>RIWAYAT JABATAN</u></th>
        </tr>
        <tr valign="top">
            <th>JABATAN</th>
            <th width="70">
                <center>TMT</center>
            </th>
            <th width="100">NOMOR SKEP</th>
        </tr>

        <?php
        $no = 1;
        foreach ($riwayat_jabatan as $r) {
        ?>
            <tr valign="top">
                <td><?= $no++ ?>. <?= $r->nama ?></td>
                <td align="center"><?= $r->tmt ?></td>
                <td><?= $r->skep ?></td>
            </tr>
        <?php } ?>
    </table>

    <br>
    <table width="100%" border="0">
        <tr valign="top">
            <th align="left">IX. <u>ALAMAT RUMAH LENGKAP</u></th>
        </tr>
        <tr valign="top">
            <td><?= $p->alamat ?></td>
        </tr>
    </table>

    <br>
    <table width="100%" border="0">
        <tr valign="top">
            <th width="180">
                <center>
                    Mengetahui <br>
                    a.n Komandan Kogartap II/Bdg <br>
                    Kepala Staf <br>
                    U.B. <br>
                    Asisten Administrasi, <br>
                    <br><br><br>
                    M. Zaenal Arifin, S.T. <br>
                    Kolonel Adm NRP 521889
                </center>
            </th>
            <th>&nbsp;</th>
            <th width="150" align="left">
                Dikeluarkan di Bandung <br>
                Pada tanggal <?= date('d F Y') ?> <br>
                _________________________________ <br>
                <center>
                    Yang Bersangkutan <br>
                    <br><br><br><br>
                    <?= $p->nama ?> <br>
                    <?= $p->pangkat ?> NRP <?= $p->nrp ?>
                </center>
            </th>
            <th>&nbsp;</th>
        </tr>

    </table>

</body>

</html>