<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?php
    $no = 1;
    foreach ($pokok as $p) {
    ?>
    <?php } ?>
    <title>Surat Ijin Jalan - <?= $p->nrp ?></title>
    <style type="text/css">
        .line-title {
            border: 0;
            border-style: inset;
            border-top: 1px solid #000;
        }

        .collapsed {
            border-collapse: collapse;
        }

        .underline {
            display: inline-block;
            border-bottom: 1px solid black;
        }
    </style>

</head>

<body style="font-size:12pt; font-family: sans-serif;">
    <table border="0" width="100%">
        <tr>
            <td width="300" align="center" style="line-height: 100%;">MARKAS BESAR TENTARA NASIONAL INDONESIA <br>
                KOMANDO GARNISUN TETAP II/BANDUNG <br>
                <hr class="line-title">
            </td>
            <td></td>
        </tr>
    </table>
    <?php
    $bulan = date('n');
    $romawi = ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];
    $bulan_romawi = $romawi[$bulan];
    ?> <br><br><br>
    <center><img src="data:image/png;base64,<?= base64_encode(file_get_contents(base_url('public/logo.png'))) ?>" width="100px"></center>
    <p style="margin-bottom: -15px; text-align:center">SURAT IZIN JALAN</p>
    <p style="text-align:center">Nomor SIJ / &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/<?= $bulan_romawi ?>/<?= date('Y') ?></p>
    <?php
    $no = 1;
    foreach ($sij as $s) {
    ?>
        <p style="font-size:14pt;margin-bottom: -15px; text-align:center">PERMOHONAN <?= $s->permohonan ?></p>
        <br><br>

        <table border="0" width="95%" align="center">

            <tr>
                <td colspan="3">Diberikan kepada</td>
            </tr>
            <tr>
                <td width="130">Nama</td>
                <td width="10">:</td>
                <td><?= ucwords(strtolower($s->nama)) ?></td>
            </tr>
            <tr>
                <td>Pangkat Korps/NRP</td>
                <td>:</td>
                <td><?= $s->pangkat ?> <?= $s->korps ?> / <?= $s->nrp ?></td>
            </tr>
            <tr>
                <td>Jabatan</td>
                <td>:</td>
                <td><?= ucwords(strtolower($s->jabatan)) ?></td>
            </tr>
            <tr>
                <td>Kesatuan</td>
                <td>:</td>
                <td>Kogartap II/Bdg</td>
            </tr>
            <tr>
                <td>Pengikut</td>
                <td>:</td>
                <td>Keluarga</td>
            </tr>
            <tr>
                <td>Pergi dari</td>
                <td>:</td>
                <td>Bandung</td>
            </tr>
            <tr>
                <td valign="top">Alamat Tujuan</td>
                <td valign="top">:</td>
                <td valign="top"><?= $s->tujuan ?></td>
            </tr>
            <tr>
                <td>Keperluan</td>
                <td>:</td>
                <td><?= $s->keperluan ?></td>
            </tr>
            <tr>
                <td>Berangkat</td>
                <td>:</td>
                <td><?= $s->waktu_berangkat ?></td>
            </tr>
            <tr>
                <td>Kembali</td>
                <td>:</td>
                <td><?= $s->waktu_kembali ?></td>
            </tr>
            <tr>
                <td>Kendaraan</td>
                <td>:</td>
                <td><?= $s->kendaraan ?></td>
            </tr>
            <tr>
                <td>Catatan</td>
                <td>:</td>
                <td>Membawa Perlengkapan Seperlunya</td>
            </tr>
        </table>

        <br>
        <table width="95%" border="0" align="center">
            <tr>
                <td width="290"></td>
                <td>
                    Dikeluarkan di Bandung <br>
                    pada tanggal &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <?= date('F Y') ?>
                    <hr class="line-title">
                </td>
            </tr>
            <tr>
                <td valign="bottom">Tembusan : <br>&nbsp;</td>
                <td align="center">a.n Komandan Kogartap II/Bdg <br>Kepala Staf,
                    <br>
                    <br>
                    <br>
                    <br>
                    Tri Bowo Setyo C., S.Sos., M.M. <br> Marsekal Pertama TNI
                </td>
            </tr>
            <tr>
                <td rowspan="2"><span class="underline">- <?= $s->tembusan ?></span>

                </td>
            </tr>
        </table>
    <?php } ?>

</body>

</html>