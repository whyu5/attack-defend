<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Kogartap II/Bdg - Daftar List Dosir</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <link rel="stylesheet" href="">

</head>

<body style=" font-size:10px; text-transform: uppercase; font-family:sans-serif">
    <div class="container">
        <table border="1" cellpadding="10">
            <tr>
                <td><img src="<?= base_url('vendor/') ?>mabes.png" width="100px" style="transform: rotate(-90deg);">
                    <?php
                    $link = 'yusufandika.rf.gd/';  ?>
                    <img src="<?php echo base_url('QR_Code/qrcode/yusufandika.rf.gd' . $nip) ?>" width="100"
                        style="transform: rotate(-90deg);">
                </td>
                <td>
                    <h1><?= $nip ?> <br> <?= $nama ?></h1>
                </td>
            </tr>
        </table>
    </div>


</body>

</html>