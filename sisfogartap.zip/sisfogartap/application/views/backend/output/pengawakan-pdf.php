<!DOCTYPE html>
<html lang="en">

<head>
    <title>Kogartap II/Bdg - Data Pengawakan</title>

</head>

<body style="margin: -30px; text-transform: uppercase; font-family: sans-serif;">

    <table border="0" width="100%" style="border-collapse: collapse;">
        <tr>
            <td width="200" align="center" style="line-height: 100%; font-size:10px;">MARKAS BESAR TENTARA NASIONAL
                INDONESIA <br>
                KOMANDO GARNISUN TETAP II/BANDUNG <br>
                <hr style="border: 0;
        border-style: inset;
        border-top: 1px solid #000;">
            </td>
            <td></td>
        </tr>
    </table>
    <h3 align="center" style="letter-spacing: 2px; font-size:16px;"><b>&nbsp;PENGAWAKAN PERSONEL PA,BA,TA & PNS</b></h3>
    <table style="width: 100%; border-collapse: collapse; border: 1px solid black; font-size:12px;" border="1">
        <tr style="background-color: #bdc3c7;">
            <th colspan="2" rowspan="2" width="30">
                <center>NOMOR</center>
            </th>
            <th colspan="6">
                <center>DSP BARU</center>
            </th>
        </tr>
        <tr style="background-color: #bdc3c7;">
            <th rowspan="2">JABATAN</center>
            </th>
            <th width="30">PKT</center>
            </th>
            <th rowspan="2">N A M A</center>
            </th>
            <th width="80">PANGKAT /</center>
            </th>
            <th rowspan="2" width="100">NRP/NIP</center>
            </th>
            <th width="50" rowspan="2">MATRA</center>
            </th>
        </tr>
        <tr style="background-color: #bdc3c7;">
            <th width="10">
                <center>URT</center>
            </th>
            <th width="10">
                <center>BAG</center>
            </th>
            <th>
                <center>DSP</center>
            </th>
            <th>
                <center>KORPS</center>
            </th>
        </tr>
        <tr align="center" style="background-color: #ecf0f1;">
            <td>1</td>
            <td>2</td>
            <td>3</td>
            <td>4</td>
            <td>5</td>
            <td>6</td>
            <td>7</td>
            <td>8</td>
        </tr>
        <tr>
            <th></th>
            <th align="center">A.</th>
            <th colspan="6" align="left">ESELON PIMPINAN</th>

        </tr>

        <tr>
            <th></th>
            <th align="center">B.</th>
            <th colspan="6" align="left">ESELON PEMBANTU PIMPINAN</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6" align="left">SOPS</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6" align="left">SMIN</th>
        </tr>

        <tr>
            <th></th>
            <th align="center">C.</th>
            <th colspan="6" align="left">ESELON PELAYANAN</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6" align="left">DENMA</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6" align="left">SEKRETARIAT</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6" align="left">RENGAR</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6" align="left">HUKUM</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6" align="left">PENERANGAN</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6" align="left">KESEHATAN</th>
        </tr>

        <tr>
            <th></th>
            <th align="center">D.</th>
            <th colspan="6" align="left">ESELON PELAKSANA</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6" align="left">PROTOKOL</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6" align="left">PEMAKAMAN</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6" align="left">SATINTEL</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6" align="left">DENPOM</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6" align="left">SUBGAR 0618/BDG</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6" align="left">SUBGAR 0609/CMI</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6" align="left">SUBGAR 0612/TSK</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6" align="left">SUBGAR 0606/BGR</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6" align="left">SUBGAR 0614/CRB</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6" align="left">SUBGAR 0623/CLG</th>
        </tr>

    </table>

</body>

</html>