<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Kogartap II/Bdg - Daftar List Dosir</title>

    <style type="text/css">
    .line-title {
        border: 0;
        border-style: inset;
        border-top: 1px solid #000;
    }

    .collapsed {
        border-collapse: collapse;
    }
    </style>

</head>

<body style="margin: -30px; font-size:10px; text-transform: uppercase; font-family:sans-serif">

    <table border="0" width="100%">
        <tr>
            <td width="200" align="center" style="line-height: 100%;">MARKAS BESAR TENTARA NASIONAL INDONESIA <br>
                KOMANDO GARNISUN TETAP II/BANDUNG <br>
                <hr class="line-title">
            </td>
            <td></td>
        </tr>
    </table> <br><br><br>
    <h1 align="center" style="letter-spacing: 2px;"><b>&nbsp;DAFTAR ISI DOKUMEN DOSIR <br><?= $nip ?> - <?= $nama ?></b>
    </h1> <br><br>

    <table class="collapsed" border="1" width="100%"
        style="outline-color: black; font-size: 14px; padding-left: 100px; padding-right: 100px;" cellpadding="7">
        <tr bgcolor="#95a5a6">
            <th width="10">NO</th>
            <th>NAMA DOKUMEN</th>
            <th>CEKLIST</th>
        </tr>
        <?php
        $no = 1;
        foreach ($dosir as $u) {
        ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= $u->caption ?></td>
            <td width="50"></td>
        </tr>
        <?php } ?>
    </table>
    <br><br>
    <p style="padding-left: 320;">Komando Garnisun Tetap II/Bdg <br>Pemilik Dosir <br><br><br><br>
        <b><?= $nama ?> <br> NRP/NIP. <?= $nip ?></b>
    </p>




</body>

</html>