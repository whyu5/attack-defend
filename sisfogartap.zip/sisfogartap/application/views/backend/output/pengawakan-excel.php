<?php
header("Content-type: application/vnd-ms-excel");

header("Content-Disposition: attachment; filename=Data Pengawakan.xls");

header("Pragma: no-cache");

header("Expires: 0");
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Kogartap II/Bdg - Data Pengawakan</title>
    <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('vendor/') ?>mabes.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <link rel="stylesheet" href="">

</head>

<body style="margin: -30px; font-size:10px; text-transform: uppercase;">

    <table border="0" width="100%">
        <tr>
            <td width="200" align="center" style="line-height: 100%;">MARKAS BESAR TENTARA NASIONAL INDONESIA <br>
                KOMANDO GARNISUN TETAP II/BANDUNG <br>
                <hr style="margin-top:-0.1px">
            </td>
            <td></td>
        </tr>
    </table>
    <h3 align="center" style="letter-spacing: 2px;"><b>&nbsp;PENGAWAKAN PERSONEL PA,BA,TA & PNS</b></h3>
    <table style="width: 100%;" border="1">
        <tr style="background-color: #bdc3c7;">
            <th colspan="2" rowspan="2" width="30">
                <center>NOMOR</center>
            </th>
            <th colspan="6">
                <center>DSP BARU</center>
            </th>
        </tr>
        <tr style="background-color: #bdc3c7;">
            <th rowspan="2">
                <center>JABATAN</center>
            </th>
            <th width="30">
                <center>PKT</center>
            </th>
            <th rowspan="2">
                <center>N A M A</center>
            </th>
            <th width="50">
                <center>PANGKAT /</center>
            </th>
            <th rowspan="2" width="100">
                <center>NRP/NIP</center>
            </th>
            <th width="10" rowspan="2">
                <center>MATRA</center>
            </th>
        </tr>
        <tr style="background-color: #bdc3c7;">
            <th>
                <center>URT</center>
            </th>
            <th>
                <center>BAG</center>
            </th>
            <th>
                <center>DSP</center>
            </th>
            <th>
                <center>KORPS</center>
            </th>
        </tr>
        <tr align="center" style="background-color: #ecf0f1;">
            <td>1</td>
            <td>2</td>
            <td>3</td>
            <td>4</td>
            <td>5</td>
            <td>6</td>
            <td>7</td>
            <td>8</td>
        </tr>
        <tr>
            <th></th>
            <th align="center">A.</th>
            <th colspan="6">ESELON PIMPINAN</th>

        </tr>

        <tr>
            <th></th>
            <th align="center">B.</th>
            <th colspan="6">ESELON PEMBANTU PIMPINAN</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6">SOPS</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6">SMIN</th>
        </tr>

        <tr>
            <th></th>
            <th align="center">C.</th>
            <th colspan="6">ESELON PELAYANAN</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6">DENMA</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6">SEKRETARIAT</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6">RENGAR</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6">HUKUM</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6">PENERANGAN</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6">KESEHATAN</th>
        </tr>

        <tr>
            <th></th>
            <th align="center">D.</th>
            <th colspan="6">ESELON PELAKSANA</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6">PROTOKOL</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6">PEMAKAMAN</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6">SATINTEL</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6">DENPOM</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6">SUBGAR 0618/BDG</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6">SUBGAR 0609/CMI</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6">SUBGAR 0612/TSK</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6">SUBGAR 0606/BGR</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6">SUBGAR 0614/CRB</th>
        </tr>

        <tr>
            <th></th>
            <th></th>
            <th colspan="6">SUBGAR 0623/CLG</th>
        </tr>

    </table>

</body>

</html>