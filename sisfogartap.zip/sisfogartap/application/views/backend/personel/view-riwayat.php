<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>
<div class="flash-data2" data-flashdata2="<?= $this->session->flashdata('pesan') ?>"></div>
<?php
$no = 1;
foreach ($user as $u) {
?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800"><b><?= $title ?>, <?php echo $u->pangkat ?> <?php echo $u->nama ?></b></h1>
        <p class="mb-4">Anda dapat mengelola masing-masing anggota secara mandiri</p>

        <!-- DataTales Example -->
        <div class="row">

            <div class="col-lg-12">

                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <a href="<?= base_url('profil-printr/' . $u->id) ?>" class="btn btn-outline-primary btn-konfirm">
                            <i class="fas fa-fw fa-print"></i>
                        </a>
                    </div>
                    <div class="card-body">
                        <nav>
                            <div class="nav nav-tabs" id="nav-contact-tab" role="tablist">
                                <a class="nav-link active" id="nav-datariri" data-toggle="tab" href="#nav-dd" role="tab" aria-controls="nav-home" aria-selected="true">DATA POKOK</a>

                                <a class="nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-pendidikan" role="tab" aria-controls="nav-pendidikan" aria-selected="false">PENDIDIKAN</a>

                                <a class="nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-bahasa" role="tab" aria-controls="nav-bahasa" aria-selected="false">BAHASA & TANDA JASA</a>

                                <a class="nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-operasi" role="tab" aria-controls="nav-contact" aria-selected="false">PENUGASAN</a>

                                <a class="nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-pangkat" role="tab" aria-controls="nav-contact" aria-selected="false">KEPANGKATAN</a>

                                <a class="nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-foto" role="tab" aria-controls="nav-contact" aria-selected="false">FOTO</a>
                            </div>
                        </nav>


                        <div class="tab-content" id="nav-tabContent">
                            <div class="tab-pane fade show active" id="nav-dd" role="tabpanel" aria-labelledby="nav-datariri">
                                <br>
                                <h5><b>DATA POKOK PERSONIL</b></h5>
                                <?= $u->alamat ?>
                                <hr>
                                <form>
                                    <div class="form-row align-items-center">
                                        <div class="col-lg-6">
                                            <table>
                                                <tr>
                                                    <th width="140">Nama Lengkap</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->nama ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Pangkat</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->pangkat ?></td>
                                                </tr>
                                                <tr>
                                                    <th>NRP/NBI</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->nrp ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Jabatan</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->jabatan ?></td>
                                                </tr>
                                                <tr>
                                                    <th>TMT Jabatan</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->tmt_jab ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Matra / Kesatuan</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->matra ?> / <?= $u->kesatuan ?></td>
                                                </tr>
                                                <tr>
                                                    <th>TTL</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->tpt_lahir ?>, <?= $u->tgl_lahir ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Kategori</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->kategori ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Sumber / TMT</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->sumber ?> / <?= $u->tmt_tni ?></td>
                                                </tr>
                                                <tr>
                                                    <th>TMT Pangkat</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->tmt_kat ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Suku</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->suku ?></td>
                                                </tr>

                                            </table>
                                        </div>
                                        <div class="col-lg-6">
                                            <table>


                                                <tr>
                                                    <th width="140">Agama</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->agama ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Status Kawin</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->status_kawin ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Gol. Darah</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->goldar ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Tinggi/B. Badan</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->tinggi ?> CM/ <?= $u->berat ?> KG</td>
                                                </tr>
                                                <tr>
                                                    <th>Ayah</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->ayah ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Ibu</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->goldar ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Nama Istri</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->istri ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Pekerjaan</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->pekerjaan ?></td>
                                                </tr>
                                                <tr>
                                                    <th>TTL</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->tpt_lahir_istri ?>, <?= $u->tgl_lahir_istri ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th>Baju / Celana</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->baju ?> / <?= $u->celana ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Topi / Sepatu</th>
                                                    <td>:</td>
                                                    <td>&nbsp;&nbsp;<?= $u->topi ?> CM / <?= $u->sepatu ?></td>
                                                </tr>
                                            </table>
                                        </div>

                                    </div>
                                </form>

                                <br>
                                <button type="button" data-toggle="modal" data-target="#M_Edit_Data_Pokok" id="btn-edit-data-pokok" class="btn btn-outline-success" data-id="<?= $u->id; ?>" data-nrp="<?= $u->nrp; ?>" data-nama="<?= $u->nama; ?>" data-pangkat="<?= $u->pangkat; ?>" data-jabatan="<?= $u->jabatan; ?>" data-kesatuan="<?= $u->kesatuan; ?>" data-tmt_jab="<?= $u->tmt_jab; ?>" data-tpt_lahir="<?= $u->tpt_lahir; ?>" data-tgl_lahir="<?= $u->tgl_lahir; ?>" data-kategori="<?= $u->kategori; ?>" data-sumber="<?= $u->sumber; ?>" data-tmt_tni="<?= $u->tmt_tni; ?>" data-suku="<?= $u->suku; ?>" data-tmt_kat="<?= $u->tmt_kat; ?>" data-agama="<?= $u->agama; ?>" data-status_kawin="<?= $u->status_kawin; ?>" data-goldar="<?= $u->goldar; ?>" data-tinggi="<?= $u->tinggi; ?>" data-berat="<?= $u->berat; ?>" data-ayah="<?= $u->ayah; ?>" data-ibu="<?= $u->ibu; ?>" data-istri="<?= $u->istri; ?>" data-pekerjaan="<?= $u->pekerjaan; ?>" data-tpt_lahir_istri="<?= $u->tpt_lahir_istri; ?>" data-tgl_lahir_istri="<?= $u->tgl_lahir_istri; ?>" data-baju="<?= $u->baju; ?>" data-celana="<?= $u->celana; ?>" data-topi="<?= $u->topi; ?>" data-alamat="<?= $u->alamat; ?>" data-sepatu="<?= $u->sepatu; ?>" data-matra="<?= $u->matra; ?>">

                                    <i class="fas fa-fw fa-edit"></i>
                                    Update Data
                                </button>
                                <hr>

                                <br>
                                <h5><b>TANGGUNGAN ANAK</b></h5>
                                <div class="table-responsive">
                                    <table class="table table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th class="table-plus datatable-nosort" width="20">NO.</th>
                                                <th>AKSI</th>
                                                <th>NAMA</th>
                                                <th>TEMPAT TANGGAL LAHIR</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $no = 1;
                                            foreach ($anak as $ank) {
                                            ?>
                                                <tr>
                                                    <td><?= $no++ ?></td>
                                                    <td width="10">
                                                        <a href="<?= base_url() ?>profil-keturunandelete/<?= $ank->id ?>/<?= $u->id ?>" class="btn btn-danger btn-hapus">
                                                            <i class="fas fa-fw fa-trash"></i>
                                                        </a>
                                                    </td>
                                                    <td><?= $ank->nama ?></td>
                                                    <td><?= $ank->tpt_lahir ?>, <?= $ank->tgl_lahir ?></td>
                                                </tr>

                                            <?php } ?>
                                        </tbody>

                                    </table>
                                    <button type="button" data-toggle="modal" data-target="#M_Edit_Data_Anak" id="btn-edit-data-pokok" class="btn btn-outline-success" data-id="<?= $u->id; ?>" data-nrp="<?= $u->nrp; ?>">
                                        <i class="fas fa-fw fa-plus"></i>
                                        Tambah Data
                                    </button>
                                </div>
                            </div>


                            <div class="tab-pane fade" id="nav-pendidikan" role="tabpanel" aria-labelledby="nav-pendidikan">
                                <br>
                                <h5><b>PENDIDIKAN UMUM</b></h5>
                                <div class="table-responsive">
                                    <table class="table table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th class="table-plus datatable-nosort" width="20">NO.</th>
                                                <th>AKSI</th>
                                                <th>KATEGORI</th>
                                                <th>TAHUN LULUS</th>
                                                <th>NAMA INSTANSI</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $no = 1;
                                            foreach ($pendidikan1 as $pend) {
                                            ?>
                                                <tr>
                                                    <td><?= $no++ ?></td>
                                                    <td width="10">
                                                        <a href="<?= base_url() ?>profil-pendidikandelete/<?= $pend->id ?>/<?= $u->id ?>" class="btn btn-danger btn-hapus">
                                                            <i class="fas fa-fw fa-trash"></i>
                                                        </a>
                                                    </td>
                                                    <td><?= $pend->kategori ?></td>
                                                    <td><?= $pend->thun_lulus ?></td>
                                                    <td><?= $pend->nama ?></td>
                                                </tr>

                                            <?php } ?>
                                        </tbody>

                                    </table>
                                    <button type="button" data-toggle="modal" data-target="#M_Edit_Data_Pendi_Umum" id="btn-edit-data-pokok" class="btn btn-outline-success" data-id="<?= $u->id; ?>" data-nrp="<?= $u->nrp; ?>">
                                        <i class="fas fa-fw fa-plus"></i>
                                        Tambah Data
                                    </button>
                                </div>
                                <br>
                                <hr>
                                <h5><b>PENDIDIKAN MILITER (BANGUM)</b></h5>
                                <div class="table-responsive">
                                    <table class="table table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th class="table-plus datatable-nosort" width="20">NO.</th>
                                                <th>AKSI</th>
                                                <th>KATEGORI</th>
                                                <th>TAHUN LULUS</th>
                                                <th>NAMA INSTANSI</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $no = 1;
                                            foreach ($pendidikan2 as $bangum) {
                                            ?>
                                                <tr>
                                                    <td><?= $no++ ?></td>
                                                    <td width="10">
                                                        <a href="<?= base_url() ?>profil-pendidikandelete/<?= $bangum->id ?>/<?= $u->id ?>" class="btn btn-danger btn-hapus">
                                                            <i class="fas fa-fw fa-trash"></i>
                                                        </a>
                                                    </td>
                                                    <td><?= $bangum->kategori ?></td>
                                                    <td><?= $bangum->thun_lulus ?></td>
                                                    <td><?= $bangum->nama ?></td>
                                                </tr>

                                            <?php } ?>
                                        </tbody>

                                    </table>
                                    <button type="button" data-toggle="modal" data-target="#M_Edit_Data_Pendi_Militer" id="btn-edit-data-pokok" class="btn btn-outline-success" data-id="<?= $u->id; ?>" data-nrp="<?= $u->nrp; ?>" data-kategori="BANGUM">
                                        <i class="fas fa-fw fa-plus"></i>
                                        Tambah Data
                                    </button>
                                </div>
                                <br>
                                <hr>
                                <h5><b>PENDIDIKAN MILITER (BANGSPES)</b></h5>
                                <div class="table-responsive">
                                    <table class="table table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th class="table-plus datatable-nosort" width="20">NO.</th>
                                                <th>AKSI</th>
                                                <th>KATEGORI</th>
                                                <th>TAHUN LULUS</th>
                                                <th>NAMA INSTANSI</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $no = 1;
                                            foreach ($pendidikan3 as $bangspes) {
                                            ?>
                                                <tr>
                                                    <td><?= $no++ ?></td>
                                                    <td width="10">
                                                        <a href="<?= base_url() ?>profil-pendidikandelete/<?= $bangspes->id ?>/<?= $u->id ?>" class="btn btn-danger btn-hapus">
                                                            <i class="fas fa-fw fa-trash"></i>
                                                        </a>
                                                    </td>
                                                    <td><?= $bangspes->kategori ?></td>
                                                    <td><?= $bangspes->thun_lulus ?></td>
                                                    <td><?= $bangspes->nama ?></td>
                                                </tr>

                                            <?php } ?>
                                        </tbody>

                                    </table>
                                    <button type="button" data-toggle="modal" data-target="#M_Edit_Data_Pendi_Militer" id="btn-edit-data-pokok" class="btn btn-outline-success" data-id="<?= $u->id; ?>" data-nrp="<?= $u->nrp; ?>" data-kategori="BANGSPES">
                                        <i class="fas fa-fw fa-plus"></i>
                                        Tambah Data
                                    </button>
                                </div>

                            </div>
                            <div class="tab-pane fade" id="nav-bahasa" role="tabpanel" aria-labelledby="nav-pendidikan">
                                <br>
                                <h5><b>KECAKAPAN BAHASA</b></h5>
                                <div class="table-responsive">
                                    <table class="table table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th class="table-plus datatable-nosort" width="20">NO.</th>
                                                <th>AKSI</th>
                                                <th>JENIS BAHASA</th>
                                                <th>BAHASA</th>
                                                <th>KETERANGAN</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $no = 1;
                                            foreach ($bahasa as $bah) {
                                            ?>
                                                <tr>
                                                    <td><?= $no++ ?></td>
                                                    <td width="10">
                                                        <a href="<?= base_url() ?>profil-bahasadelete/<?= $bah->id ?>/<?= $u->id ?>" class="btn btn-danger btn-hapus">
                                                            <i class="fas fa-fw fa-trash"></i>
                                                        </a>
                                                    </td>
                                                    <td><?= $bah->jenis ?></td>
                                                    <td><?= $bah->bahasa ?></td>
                                                    <td><?= $bah->ket ?></td>
                                                </tr>

                                            <?php } ?>
                                        </tbody>

                                    </table>
                                    <button type="button" data-toggle="modal" data-target="#M_Edit_Data_Bahasa" id="btn-edit-data-pokok" class="btn btn-outline-success" data-id="<?= $u->id; ?>" data-nrp="<?= $u->nrp; ?>">
                                        <i class="fas fa-fw fa-plus"></i>
                                        Tambah Data
                                    </button>
                                </div>
                                <hr>
                                <h5><b>TANDA JASA</b></h5>
                                <div class="table-responsive">
                                    <table class="table table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th class="table-plus datatable-nosort" width="20">NO.</th>
                                                <th>AKSI</th>
                                                <th>NAMA</th>
                                                <th>TAHUN</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $no = 1;
                                            foreach ($jasa as $jas) {
                                            ?>
                                                <tr>
                                                    <td><?= $no++ ?></td>
                                                    <td width="10">
                                                        <a href="<?= base_url() ?>profil-jasadelete/<?= $jas->id ?>/<?= $u->id ?>" class="btn btn-danger btn-hapus">
                                                            <i class="fas fa-fw fa-trash"></i>
                                                        </a>
                                                    </td>
                                                    <td><?= $jas->nama ?></td>
                                                    <td><?= $jas->tahun ?></td>
                                                </tr>

                                            <?php } ?>
                                        </tbody>

                                    </table>
                                    <button type="button" data-toggle="modal" data-target="#M_Edit_Data_Jasa" id="btn-edit-data-pokok" class="btn btn-outline-success" data-id="<?= $u->id; ?>" data-nrp="<?= $u->nrp; ?>">
                                        <i class="fas fa-fw fa-plus"></i>
                                        Tambah Data
                                    </button>
                                </div>

                            </div>
                            <div class="tab-pane fade" id="nav-operasi" role="tabpanel" aria-labelledby="nav-contact-tab">
                                <br>
                                <h5><b>RIWAYAT PENUGASAN OPERASI</b></h5>
                                <div class="table-responsive">
                                    <table class="table table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th class="table-plus datatable-nosort" width="20">NO.</th>
                                                <th>AKSI</th>
                                                <th>NAMA</th>
                                                <th>TAHUN</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $no = 1;
                                            foreach ($operasi as $ops) {
                                            ?>
                                                <tr>
                                                    <td><?= $no++ ?></td>
                                                    <td width="10">
                                                        <a href="<?= base_url() ?>profil-operasidelete/<?= $ops->id ?>/<?= $u->id ?>" class="btn btn-danger btn-hapus">
                                                            <i class="fas fa-fw fa-trash"></i>
                                                        </a>
                                                    </td>
                                                    <td><?= $ops->nama ?></td>
                                                    <td><?= $ops->tahun ?></td>
                                                </tr>

                                            <?php } ?>
                                        </tbody>

                                    </table>
                                    <button type="button" data-toggle="modal" data-target="#M_Edit_Data_Operasi" id="btn-edit-data-pokok" class="btn btn-outline-success" data-id="<?= $u->id; ?>" data-nrp="<?= $u->nrp; ?>">
                                        <i class="fas fa-fw fa-plus"></i>
                                        Tambah Data
                                    </button>
                                </div>


                                <br>
                                <hr>
                                <h5><b>RIWAYAT PENUGASAN LUAR NEGERI</b></h5>
                                <div class="table-responsive">
                                    <table class="table table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th class="table-plus datatable-nosort" width="20">NO.</th>
                                                <th>AKSI</th>
                                                <th>NAMA TUGAS</th>
                                                <th>TAHUN</th>
                                                <th>NEGARA TUJUAN</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $no = 1;
                                            foreach ($penugasan as $penugas) {
                                            ?>
                                                <tr>
                                                    <td><?= $no++ ?></td>
                                                    <td width="10">
                                                        <a href="<?= base_url() ?>profil-penugasandelete/<?= $penugas->id ?>/<?= $u->id ?>" class="btn btn-danger btn-hapus">
                                                            <i class="fas fa-fw fa-trash"></i>
                                                        </a>
                                                    </td>
                                                    <td><?= $penugas->nama ?></td>
                                                    <td><?= $penugas->tahun ?></td>
                                                    <td><?= $penugas->negara ?></td>
                                                </tr>

                                            <?php } ?>
                                        </tbody>

                                    </table>
                                    <button type="button" data-toggle="modal" data-target="#M_Edit_Data_Penugasan" id="btn-edit-data-pokok" class="btn btn-outline-success" data-id="<?= $u->id; ?>" data-nrp="<?= $u->nrp; ?>">
                                        <i class="fas fa-fw fa-plus"></i>
                                        Tambah Data
                                    </button>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="nav-pangkat" role="tabpanel" aria-labelledby="nav-contact-tab">
                                <br>
                                <h5><b>RIWAYAT KEPANGKATAN</b></h5>
                                <div class="table-responsive">
                                    <table class="table table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th class="table-plus datatable-nosort" width="20">NO.</th>
                                                <th>AKSI</th>
                                                <th>PANGKAT</th>
                                                <th>TMT</th>
                                                <th>NO SKEP/SPRIN/ST/RDG</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $no = 1;
                                            foreach ($kepangkatan as $kepangkat) {
                                            ?>
                                                <tr>
                                                    <td><?= $no++ ?></td>
                                                    <td width="10">
                                                        <a href="<?= base_url() ?>profil-kepangkatandelete/<?= $kepangkat->id ?>/<?= $u->id ?>" class="btn btn-danger btn-hapus">
                                                            <i class="fas fa-fw fa-trash"></i>
                                                        </a>
                                                    </td>
                                                    <td><?= $kepangkat->pangkat ?></td>
                                                    <td><?= $kepangkat->tmt ?></td>
                                                    <td><?= $kepangkat->skep ?></td>
                                                </tr>

                                            <?php } ?>
                                        </tbody>

                                    </table>
                                    <button type="button" data-toggle="modal" data-target="#M_Edit_Data_Kepangkatan" id="btn-edit-data-pokok" class="btn btn-outline-success" data-id="<?= $u->id; ?>" data-nrp="<?= $u->nrp; ?>">
                                        <i class="fas fa-fw fa-plus"></i>
                                        Tambah Data
                                    </button>
                                </div>

                                <br>
                                <hr>
                                <h5><b>RIWAYAT JABATAN</b></h5>
                                <div class="table-responsive">
                                    <table class="table table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th class="table-plus datatable-nosort" width="20">NO.</th>
                                                <th>AKSI</th>
                                                <th>NAMA</th>
                                                <th>TMT</th>
                                                <th>NO SKEP/SPRIN/ST/RDG</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $no = 1;
                                            foreach ($riwayat_jabatan as $jabat) {
                                            ?>
                                                <tr>
                                                    <td><?= $no++ ?></td>
                                                    <td width="10">
                                                        <a href="<?= base_url() ?>profil-jabatandelete/<?= $jabat->id ?>/<?= $u->id ?>" class="btn btn-danger btn-hapus">
                                                            <i class="fas fa-fw fa-trash"></i>
                                                        </a>
                                                    </td>
                                                    <td><?= $jabat->nama ?></td>
                                                    <td><?= $jabat->tmt ?></td>
                                                    <td><?= $jabat->skep ?></td>
                                                </tr>

                                            <?php } ?>
                                        </tbody>

                                    </table>
                                    <button type="button" data-toggle="modal" data-target="#M_Edit_Data_Jabatan" id="btn-edit-data-pokok" class="btn btn-outline-success" data-id="<?= $u->id; ?>" data-nrp="<?= $u->nrp; ?>">
                                        <i class="fas fa-fw fa-plus"></i>
                                        Tambah Data
                                    </button>
                                </div>
                            </div>


                            <div class="tab-pane fade" id="nav-foto" role="tabpanel" aria-labelledby="nav-contact-tab">
                                <br>
                                <img src="<?= base_url('public/uploads/img/') ?><?= $u->foto; ?>" width="250px" class="img-fluid">
                                <br> <br>
                                <button type="button" data-toggle="modal" data-target="#M_Edit_Data_Foto" id="btn-edit-data-pokok" class="btn btn-outline-success" data-id="<?= $u->id; ?>" data-nrp="<?= $u->nrp; ?>" data-foto="<?= $u->foto; ?>">
                                    <i class="fas fa-fw fa-camera"></i>
                                    Upload Foto
                                </button>

                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>
<?php } ?>

<div class="modal fade" id="M_Edit_Data_Pokok" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;"><b>Perbarui Data</b></h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('profil-pokok'); ?>">
                    <input type="hidden" placeholder="Username" name="id" id="id-pokok" class="form-control">
                    <h3><b>DATA PERSONAL</b></h3>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label><b>NRP/NBI : </b></label>
                            <input type="text" placeholder="Nomor NRP/NBI" id="nrp-pokok" name="nrp" class="form-control" readonly>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Nama Lengkap : </b></label>
                            <input type="text" placeholder="Nama Lengkap" id="nama-pokok" name="nama" class="form-control" readonly>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Jabatan : </b></label>
                            <input type="text" placeholder="Jabatan" id="jabatan-pokok" name="jabatan" class="form-control" readonly>
                        </div>

                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label><b>Pangkat : </b></label>
                            <input type="text" placeholder="Pangkat saat ini" id="pangkat-pokok" name="pangkat" class="form-control" readonly>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Kesatuan : </b></label>
                            <input type="text" value="Kogartap II/Bandung" id="kesatuan-pokok" name="kesatuan" class="form-control" readonly>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>TMT Pangkat : </b></label>
                            <input type="date" id="tmt_kat-pokok" name="tmt_kat" class="form-control" required>
                        </div>

                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label><b>TMT Jabatan : </b></label>
                            <input type="date" placeholder="Jabatan" id="tmt_jab-pokok" name="tmt_jab" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Tempat Lahir : </b></label>
                            <input type="text" id="tpt_lahir-pokok" placeholder="Tempat Lahir" name="tpt_lahir" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Tanggal Lahir : </b></label>
                            <input type="date" id="tgl_lahir-pokok" name="tgl_lahir" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label><b>Kategori : </b></label>
                            <select class="form-control" name="kategori" id="kategori-pokok" required>
                                <option>Aktif</option>
                                <option>Pasif</option>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Sumber Penerimaan : </b></label>
                            <input type="text" placeholder="Sumber PA" id="sumber-pokok" name="sumber" class="form-control" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>TMT TNI : </b></label>
                            <input type="date" id="tmt_tni-pokok" name="tmt_tni" class="form-control" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>MATRA TNI : </b></label>
                            <select class="form-control" name="matra" id="matra-pokok">
                                <option>TNI AD</option>
                                <option>TNI AU</option>
                                <option>TNI AL</option>
                                <option>TNI PNS</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label><b>Agama : </b></label>
                            <select class="form-control" name="agama" id="agama-pokok" required>
                                <option>Islam</option>
                                <option>Protestan</option>
                                <option>Katholik</option>
                                <option>Hindu</option>
                                <option>Buddha</option>
                                <option>Kong Hu Chu</option>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Suku : </b></label>
                            <input type="text" placeholder="Suku" id="suku-pokok" name="suku" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Status Kawin : </b></label>
                            <select class="form-control" name="status_kawin" id="status_kawin-pokok" required>
                                <option>Kawin</option>
                                <option>Belum Kawin</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label><b>Golongan Darah : </b></label>
                            <select class="form-control" name="goldar" id="goldar-pokok" required>
                                <option>A</option>
                                <option>B</option>
                                <option>O</option>
                                <option>AB</option>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Tinggi Badan : </b></label>
                            <div class="input-group mb-2 mr-sm-2">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">CM</div>
                                </div>
                                <input type="number" class="form-control" id="tinggi-pokok" placeholder="Tinggi" name="tinggi">
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Berat Badan : </b></label>
                            <div class="input-group mb-2 mr-sm-2">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">KG</div>
                                </div>
                                <input type="number" class="form-control" id="berat-pokok" placeholder="Berat" name="berat">
                            </div>
                        </div>
                    </div>
                    <hr>
                    <h3><b>DATA KELUARGA</b></h3>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label><b>Nama Ayah : </b></label>
                            <input type="text" placeholder="Nama Ayah" id="ayah-pokok" name="ayah" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Nama Ibu : </b></label>
                            <input type="text" placeholder="Nama Ibu" id="ibu-pokok" name="ibu" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Nama Istri : </b></label>
                            <input type="text" placeholder="Nama Istri" id="istri-pokok" name="istri" class="form-control" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label><b>Pekerjaan Istri : </b></label>
                            <input type="text" placeholder="Pekerjaan Istri" id="pekerjaan-pokok" name="pekerjaan" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Tempat Lahir Istri : </b></label>
                            <input type="text" placeholder="Tempat Lahir Istri" id="tpt_lahir_istri-pokok" name="tpt_lahir_istri" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Tanggal Lahir Istri : </b></label>
                            <input type="date" id="tgl_lahir_istri-pokok" name="tgl_lahir_istri" class="form-control" required>
                        </div>
                    </div>

                    <hr>
                    <h3><b>DATA UKURAN PAKAIAN</b></h3>
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label><b>Baju : </b></label>
                            <input type="number" id="baju-pokok" name="baju" class="form-control" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Celana : </b></label>
                            <input type="number" id="celana-pokok" name="celana" class="form-control" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Sepatu : </b></label>
                            <input type="number" id="sepatu-pokok" name="sepatu" class="form-control" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Topi : </b></label>
                            <input type="number" id="topi-pokok" name="topi" class="form-control" required>
                        </div>
                        <div class="form-group col-md-12">
                            <label><b>Alamat Lengkap : </b></label>
                            <textarea class="form-control" name="alamat" id="alamat-pokok" rows="4"></textarea>
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="M_Edit_Data_Anak" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Tambah Anak</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('profil-keturunan'); ?>">
                    <input type="hidden" placeholder="Username" name="id-keturunan" id="id2-pokok" class="form-control">
                    <label>NRP/NBI : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nomor NRP/NBI" id="nrp2-pokok" name="nrp-keturunan" class="form-control" readonly>
                    </div>
                    <label>Nama Lengkap : </label>
                    <div class="form-group">
                        <input type="text" name="nama" class="form-control" required>
                    </div>
                    <label>Tempat Lahir : </label>
                    <div class="form-group">
                        <input type="text" name="tpt_lahir" class="form-control" required>
                    </div>
                    <label>Tanggal Lahir : </label>
                    <div class="form-group">
                        <input type="date" name="tgl_lahir" class="form-control" required>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="M_Edit_Data_Pendi_Umum" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Tambah Pendidikan Umum</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('profil-pendidikan'); ?>">
                    <input type="hidden" placeholder="Username" name="id" id="id3-pokok" class="form-control">
                    <label>NRP/NBI : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nomor NRP/NBI" id="nrp3-pokok" name="nrp" class="form-control" readonly>
                    </div>
                    <label>Tahun Lulus : </label>
                    <div class="form-group">
                        <input type="number" name="thun_lulus" class="form-control" required>
                    </div>
                    <label>Nama Instansi : </label>
                    <div class="form-group">
                        <input type="text" name="nama" class="form-control" required>
                    </div>
                    <label>Kategori Pendidikan : </label>
                    <div class="form-group">
                        <input type="text" value="Umum" name="kategori" class="form-control" readonly>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="M_Edit_Data_Pendi_Militer" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Tambah Pendidikan Militer</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('profil-pendidikan'); ?>">
                    <input type="hidden" placeholder="Username" name="id" id="id4-pokok" class="form-control">
                    <label>NRP/NBI : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nomor NRP/NBI" id="nrp4-pokok" name="nrp" class="form-control" readonly>
                    </div>
                    <label>Tahun Lulus : </label>
                    <div class="form-group">
                        <input type="number" name="thun_lulus" class="form-control" required>
                    </div>
                    <label>Nama Instansi : </label>
                    <div class="form-group">
                        <input type="text" name="nama" class="form-control" required>
                    </div>
                    <label>Kategori Pendidikan : </label>
                    <div class="form-group">
                        <input type="text" name="kategori" id="kategori2-pokok" class="form-control" readonly>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="M_Edit_Data_Bahasa" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Tambah Kecakapan Bahasa</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('profil-bahasa'); ?>">
                    <input type="hidden" placeholder="Username" name="id" id="id5-pokok" class="form-control">
                    <label>NRP/NBI : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nomor NRP/NBI" id="nrp5-pokok" name="nrp" class="form-control" readonly>
                    </div>
                    <label>Bahasa : </label>
                    <div class="form-group">
                        <input type="text" name="bahasa" class="form-control" required>
                    </div>
                    <label>Jenis Bahasa : </label>
                    <div class="form-group">
                        <select name="jenis" class="form-control" required>
                            <option>ASING</option>
                            <option>DAERAH</option>
                        </select>
                    </div>
                    <label>Keterangan : </label>
                    <div class="form-group">
                        <select name="ket" class="form-control" required>
                            <option>Aktif</option>
                            <option>Pasif</option>
                        </select>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="M_Edit_Data_Jasa" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Tambah Tanda Jasa</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('profil-jasa'); ?>">
                    <input type="hidden" placeholder="Username" name="id" id="id6-pokok" class="form-control">
                    <label>NRP/NBI : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nomor NRP/NBI" id="nrp6-pokok" name="nrp" class="form-control" readonly>
                    </div>
                    <label>Nama Tanda Jasa : </label>
                    <div class="form-group">
                        <input type="text" name="nama" class="form-control" required>
                    </div>
                    <label>Tahun Diterima : </label>
                    <div class="form-group">
                        <input type="number" name="tahun" class="form-control" required>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="M_Edit_Data_Operasi" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Tambah Riwayat Operasi</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('profil-operasi'); ?>">
                    <input type="hidden" placeholder="Username" name="id" id="id7-pokok" class="form-control">
                    <label>NRP/NBI : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nomor NRP/NBI" id="nrp7-pokok" name="nrp" class="form-control" readonly>
                    </div>
                    <label>Nama Operasi : </label>
                    <div class="form-group">
                        <input type="text" name="nama" class="form-control" required>
                    </div>
                    <label>Tahun : </label>
                    <div class="form-group">
                        <input type="number" name="tahun" class="form-control" required>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="M_Edit_Data_Penugasan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Tambah Riwayat Penugasan Luar
                    Negeri</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('profil-penugasan'); ?>">
                    <input type="hidden" placeholder="Username" name="id" id="id8-pokok" class="form-control">
                    <label>NRP/NBI : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nomor NRP/NBI" id="nrp8-pokok" name="nrp" class="form-control" readonly>
                    </div>
                    <label>Nama Macam Tugas : </label>
                    <div class="form-group">
                        <input type="text" name="nama" class="form-control" required>
                    </div>
                    <label>Tahun : </label>
                    <div class="form-group">
                        <input type="number" min="1980" max="2023" name="tahun" class="form-control" required>
                    </div>
                    <label>Negara Tujuan : </label>
                    <div class="form-group">
                        <input type="text" name="negara" class="form-control" required>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="M_Edit_Data_Kepangkatan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Tambah Riwayat Kepangkatan</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('profil-kepangkatan'); ?>">
                    <input type="hidden" placeholder="Username" name="id" id="id9-pokok" class="form-control">
                    <label>NRP/NBI : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nomor NRP/NBI" id="nrp9-pokok" name="nrp" class="form-control" readonly>
                    </div>
                    <label>Pangkat : </label>
                    <div class="form-group">
                        <input type="text" name="pangkat" class="form-control" required>
                    </div>
                    <label>TMT : </label>
                    <div class="form-group">
                        <input type="date" name="tmt" class="form-control" required>
                    </div>
                    <label>Nomor SKEP/SPRIN/ST/RDG : </label>
                    <div class="form-group">
                        <input type="text" name="skep" class="form-control" required>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="M_Edit_Data_Jabatan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Tambah Riwayat Jabatan</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('profil-jabatan'); ?>">
                    <input type="hidden" placeholder="Username" name="id" id="id10-pokok" class="form-control">
                    <label>NRP/NBI : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nomor NRP/NBI" id="nrp10-pokok" name="nrp" class="form-control" readonly>
                    </div>
                    <label>Nama : </label>
                    <div class="form-group">
                        <input type="text" name="nama" class="form-control" required>
                    </div>
                    <label>TMT : </label>
                    <div class="form-group">
                        <input type="date" name="tmt" class="form-control" required>
                    </div>
                    <label>Nomor SKEP/SPRIN/ST/RDG : </label>
                    <div class="form-group">
                        <input type="text" name="skep" class="form-control" required>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="M_Edit_Data_Foto" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Upload Foto</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" enctype="multipart/form-data" method="post" action="<?= base_url('profil-foto'); ?>">
                    <input type="hidden" placeholder="Username" name="id" id="id11-pokok" class="form-control">
                    <label>NRP/NBI : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nomor NRP/NBI" id="nrp11-pokok" name="nrp" class="form-control" readonly>
                        <input type="hidden" id="foto-pokok" name="old_foto" class="form-control" readonly>
                    </div>
                    <label>Foto : </label>
                    <div class="form-group">
                        <input type="file" name="foto" class="form-control" required>
                        <small>Gunakan file ukuran maksimal 1 Mb dan ber-ekstensi jpg, png, jpeg. Untuk memperkecil
                            ukuran file dapat dilakukan <a href="https://www.iloveimg.com/compress-image/compress-jpg" class="badge badge-danger">di Link ini
                                !!</a></small>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).on('click', '#btn-edit-data-pokok', function() {
        $('.modal-body #id-pokok').val($(this).data('id'));
        $('.modal-body #id2-pokok').val($(this).data('id'));
        $('.modal-body #id3-pokok').val($(this).data('id'));
        $('.modal-body #id4-pokok').val($(this).data('id'));
        $('.modal-body #id5-pokok').val($(this).data('id'));
        $('.modal-body #id6-pokok').val($(this).data('id'));
        $('.modal-body #id7-pokok').val($(this).data('id'));
        $('.modal-body #id8-pokok').val($(this).data('id'));
        $('.modal-body #id9-pokok').val($(this).data('id'));
        $('.modal-body #id10-pokok').val($(this).data('id'));
        $('.modal-body #id11-pokok').val($(this).data('id'));

        $('.modal-body #nrp-pokok').val($(this).data('nrp'));
        $('.modal-body #nrp2-pokok').val($(this).data('nrp'));
        $('.modal-body #nrp3-pokok').val($(this).data('nrp'));
        $('.modal-body #nrp4-pokok').val($(this).data('nrp'));
        $('.modal-body #nrp5-pokok').val($(this).data('nrp'));
        $('.modal-body #nrp6-pokok').val($(this).data('nrp'));
        $('.modal-body #nrp7-pokok').val($(this).data('nrp'));
        $('.modal-body #nrp8-pokok').val($(this).data('nrp'));
        $('.modal-body #nrp9-pokok').val($(this).data('nrp'));
        $('.modal-body #id10-pokok').val($(this).data('id'));
        $('.modal-body #nrp11-pokok').val($(this).data('nrp'));

        $('.modal-body #pangkat-pokok').val($(this).data('pangkat'));
        $('.modal-body #nama-pokok').val($(this).data('nama'));
        $('.modal-body #jabatan-pokok').val($(this).data('jabatan'));
        $('.modal-body #kesatuan-pokok').val($(this).data('kesatuan'));
        $('.modal-body #tpt_lahir-pokok').val($(this).data('tpt_lahir'));
        $('.modal-body #tgl_lahir-pokok').val($(this).data('tgl_lahir'));
        $('.modal-body #kategori-pokok').val($(this).data('kategori'));
        $('.modal-body #sumber-pokok').val($(this).data('sumber'));
        $('.modal-body #tmt_jab-pokok').val($(this).data('tmt_jab'));
        $('.modal-body #tmt_kat-pokok').val($(this).data('tmt_kat'));
        $('.modal-body #tmt_tni-pokok').val($(this).data('tmt_tni'));
        $('.modal-body #suku-pokok').val($(this).data('suku'));
        $('.modal-body #agama-pokok').val($(this).data('agama'));
        $('.modal-body #status_kawin-pokok').val($(this).data('status_kawin'));
        $('.modal-body #goldar-pokok').val($(this).data('goldar'));
        $('.modal-body #tinggi-pokok').val($(this).data('tinggi'));
        $('.modal-body #berat-pokok').val($(this).data('berat'));
        $('.modal-body #ayah-pokok').val($(this).data('ayah'));
        $('.modal-body #ibu-pokok').val($(this).data('ibu'));
        $('.modal-body #istri-pokok').val($(this).data('istri'));
        $('.modal-body #pekerjaan-pokok').val($(this).data('pekerjaan'));
        $('.modal-body #tgl_lahir_istri-pokok').val($(this).data('tgl_lahir_istri'));
        $('.modal-body #tpt_lahir_istri-pokok').val($(this).data('tpt_lahir_istri'));
        $('.modal-body #baju-pokok').val($(this).data('baju'));
        $('.modal-body #celana-pokok').val($(this).data('celana'));
        $('.modal-body #sepatu-pokok').val($(this).data('sepatu'));
        $('.modal-body #topi-pokok').val($(this).data('topi'));
        $('.modal-body #matra-pokok').val($(this).data('matra'));
        $('.modal-body #alamat-pokok').val($(this).data('alamat'));
        $('.modal-body #foto-pokok').val($(this).data('foto'));
        $('.modal-body #kategori2-pokok').val($(this).data('kategori'));
    });
</script>