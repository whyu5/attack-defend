<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><b><?= $title ?></b></h1>
    <p class="mb-4">Anda dapat menambah atau menghapus masing-masing anggota secara mandiri</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3" align="left">
            <a href="#" class="btn btn-outline-primary" data-toggle="modal" data-target="#M_Add_Jab" type="button">
                <i class="fas fa-fw fa-plus"></i>
            </a>

            <a href="<?= base_url('pdf-dspg') ?>" class="btn btn-outline-danger" type="button">
                <i class="fas fa-fw fa-file-pdf"></i>
            </a>

            <a href="<?= base_url('excel-dspg') ?>" class="btn btn-outline-success" type="button">
                <i class="fas fa-fw fa-file-excel"></i>
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th class="table-plus datatable-nosort" width="20">NO.</th>
                            <th>AKSI</th>
                            <th>NAMA</th>
                            <th>SATKER</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($user as $u) {
                        ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td width="100">
                                    <button type="button" data-toggle="modal" data-target="#M_Edit_Jab" id="btn-edit-jab" class="btn btn-primary" data-id="<?= $u->id; ?>" data-kode_jab="<?= $u->kode_jab; ?>" data-nama="<?= $u->nama; ?>" data-kode_satker="<?= $u->kode_satker; ?>">
                                        <i class="fas fa-fw fa-edit"></i>
                                    </button>

                                    <a href="delete-jabatan/<?= $u->idnya ?>" class="btn btn-danger btn-hapus">
                                        <i class="fas fa-fw fa-trash"></i>
                                    </a>
                                </td>
                                <td><?= $u->nama ?></td>
                                <td><?= $u->nama_satker ?></td>
                            </tr>

                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<div class="modal fade" id="M_Add_Jab" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Tambah Data</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('add-dspg'); ?>">
                    <label>Kode Jabatan : </label>
                    <div class="form-group">
                        <input type="text" name="kode_jab" value="<?= $kodeh; ?>" class="form-control" readonly>
                    </div>
                    <label>Nama Jabatan : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nama Jabatan" name="nama" class="form-control" required>
                    </div>
                    <label>Jabatan pada Satker</label>
                    <div class="form-group">
                        <select name="kode_satker" class="form-control">
                            <?php
                            $no = 1;
                            foreach ($satker as $s) {
                            ?>
                                <option value="<?= $s->kode_satker ?>"><?= $s->nama_satker ?></option>
                            <?php } ?>
                        </select>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="M_Edit_Jab" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Perbarui Data</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('update-dspg'); ?>">
                    <input type="hidden" placeholder="Username" name="id" id="id-akun" class="form-control">

                    <label>Kode Jabatan : </label>
                    <div class="form-group">
                        <input type="text" name="kode_jab" id="kode_jab-akun" class="form-control" readonly>
                    </div>
                    <label>Nama Jabatan : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nama Jabatan" id="nama-akun" name="nama" class="form-control" required>
                    </div>
                    <label>Jabatan pada Satker</label>
                    <div class="form-group">
                        <select name="kode_satker" id="kode_satker-akun" class="form-control">
                            <?php
                            $no = 1;
                            foreach ($satker as $s) {
                            ?>
                                <option value="<?= $s->kode_satker ?>"><?= $s->nama_satker ?></option>
                            <?php } ?>
                        </select>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).on('click', '#btn-edit-jab', function() {
        $('.modal-body #id-akun').val($(this).data('id'));
        $('.modal-body #nama-akun').val($(this).data('nama'));
        $('.modal-body #kode_jab-akun').val($(this).data('kode_jab'));
        $('.modal-body #kode_satker-akun').val($(this).data('kode_satker'));
    });
</script>