<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?= $title; ?> - Kogartap II/Bdg</title>
    <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('public/backend/') ?>mabes.png">


    <!-- Custom fonts for this template-->
    <link href="<?= base_url('public/backend/') ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?= base_url('public/backend/') ?>css/sb-admin-2.min.css" rel="stylesheet">
    <link href="<?= base_url('public/backend/') ?>vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="<?= base_url('public/backend/') ?>sweetalert2/package/dist/sweetalert2.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <style type="text/css">
        .nav-item {
            margin-top: -10px;
            margin-bottom: -10px;
        }
    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url(); ?>">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-balance-scale"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Kogartap <sup>II</sup></div>
            </a>


            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="#">
                    <img class="img-profile rounded-circle" src="<?= base_url('public/backend/') ?>img/undraw_profile.svg">
                    <?php $nama = $this->session->userdata('nama');
                    $user = $this->db->get_where('user', ['username' => $nama])->row_array();
                    $namanya = $user['nama'];
                    $level = $user['level'];
                    $id = $user['id'];
                    ?>
                    <span><?= strtoupper($namanya); ?></span>
                </a>
            </li>
            <!-- Divider -->
            <hr class="sidebar-divider">
            <li class="nav-item <?php if ($title == 'Dashboard') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?>">
                <a class="nav-link" href="<?= base_url('dashboard-m'); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>DASHBOARD</span>
                </a>
            </li>

            <!-- Heading -->
            <div class="sidebar-heading">
                MAIN MENU
            </div>

            <li class="nav-item <?php if ($title == 'Data Personel') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?>">
                <a class="nav-link " href="<?= base_url('pers-gar'); ?>">
                    <i class="fas fa-fw fa-user"></i>
                    <span>DATA PERSONEL</span></a>
            </li>
            <li class="nav-item <?php if ($title == 'Riwayat Hidup') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?>">
                <a class="nav-link " href="<?= base_url('rh-pers'); ?>">
                    <i class="fas fa-fw fa-file-alt"></i>
                    <span>RIWAYAT HIDUP</span></a>
            </li>
            <li class="nav-item <?php if ($title == 'Dosir Elektronik') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?>">
                <a class="nav-link " href="<?= base_url('pers-dosir'); ?>">
                    <i class="fas fa-fw fa-archive"></i>
                    <span>DOSIR ELEKTRONIK</span></a>
            </li>
            <div class="sidebar-heading">
                DSP PERSONEL
            </div>

            <li class="nav-item <?php if ($title == 'Data Jabatan') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?>">
                <a class="nav-link " href="<?= base_url('dsp-gartap'); ?>">
                    <i class="fas fa-fw fa-home"></i>
                    <span>DSP JABATAN</span></a>
            </li>
            <li class="nav-item <?php if ($title == 'Surat Ijin dan Cuti') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?>">
                <a class="nav-link " href="<?= base_url('cuti-ijin'); ?>">
                    <i class="fas fa-fw fa-tag"></i>
                    <span>SURAT IJIN & CUTI</span></a>
            </li>
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" data-toggle="modal" data-target="#logoutModal" id="btn-edit" data-id="<?= $id; ?>">
                                <i class="fas fa-power-off text-primary-400 fa-fw"></i>
                            </a>

                            <!-- Dropdown - Alerts -->

                        </li>
                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?= strtoupper($namanya); ?></span>
                                <img class="img-profile rounded-circle" src="<?= base_url('public/backend/') ?>img/undraw_profile.svg">
                            </a>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->