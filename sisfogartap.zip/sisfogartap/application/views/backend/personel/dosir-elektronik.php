<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><b><?= $title ?></b></h1>
    <p class="mb-4">Anda dapat mengelola Dosir Elektronik masing-masing anggota secara mandiri</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th class="table-plus datatable-nosort" width="20">NO.</th>
                            <th>AKSI</th>
                            <th>NRP</th>
                            <th>NAMA</th>
                            <th>PANGKAT</th>
                            <th>JABATAN</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($user as $u) {
                        ?>
                            <tr>
                                <td><?php echo $no++ ?></td>
                                <td width="100">
                                    <a href="view-persdosir/<?= $u->id ?>" class="btn btn-success">
                                        <i class="fas fa-fw fa-eye"></i>
                                    </a>
                                    <a href="persblanko/<?= $u->nrp ?>" class="btn btn-danger btn-file">
                                        <i class="fas fa-fw fa-file-alt"></i>
                                    </a>
                                </td>
                                <td><?php echo $u->nrp ?></td>
                                <td><?php echo $u->nama ?></td>
                                <td><?php echo $u->pangkat ?></td>
                                <td><?php echo $u->jabatan ?></td>
                            </tr>

                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>