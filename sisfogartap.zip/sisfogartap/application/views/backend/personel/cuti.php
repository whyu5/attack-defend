<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>
<div class="flash-data2" data-flashdata2="<?= $this->session->flashdata('pesan') ?>"></div>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><b><?= $title ?></b></h1>
    <p class="mb-4">Anda dapat mengelola perizinan cuti dan ijin di halaman ini</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="#" class="btn btn-outline-primary" data-toggle="modal" data-target="#M_Add_User" type="button">
                <i class="fas fa-fw fa-plus"></i>
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th class="table-plus datatable-nosort" width="20">NO.</th>
                            <th>AKSI</th>
                            <th>DATA ANGGOTA</th>
                            <th>TUJUAN</th>
                            <th>KEPERLUAN</th>
                            <th>JENIS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($user as $u) {
                        ?>
                            <tr>
                                <td align="center"><?= $no++ ?></td>
                                <td width="100">
                                    <a href="delete-cuti/<?= $u->id_sij ?> ?>" class="btn btn-danger btn-hapus">
                                        <i class="fas fa-fw fa-trash"></i>
                                    </a>
                                    <a href="cetak-sij/<?= $u->id_sij ?>" class="btn btn-primary">
                                        <i class="fas fa-fw fa-print"></i>
                                    </a>
                                </td>
                                <td><?= $u->anggota ?> <br><?= strtoupper($u->pangkat) ?> <?= strtoupper($u->korps) ?> <?= $u->nama ?>
                                    <br><?= $u->jabatan ?>
                                </td>
                                <td><?= $u->tujuan ?></td>
                                <td><?= $u->keperluan ?> <br>
                                    <?= $u->waktu_berangkat ?> s/d <?= $u->waktu_kembali ?></td>
                                <td><?= $u->permohonan ?></td>
                            </tr>

                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>


<div class="modal fade" id="M_Add_User" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Tambah Pengajuan</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('add-sij'); ?>">
                    <div class="form-row">
                        <div class="col-6">
                            <label>Pilih Personel : </label>
                            <div class="form-group">
                                <select name="anggota" class="js-example-basic-single" style="width:100%;">
                                    <option>-- Pilih satu anggota --</option>
                                    <?php
                                    $no = 1;
                                    foreach ($pers as $p) {
                                    ?>
                                        <option value="<?= $p->nrp ?>"><?= $p->pangkat ?> - <?= $p->nama ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-4">
                            <label>Tembusan : </label>
                            <div class="form-group">
                                <textarea name="tembusan" class="form-control" rows="3" required></textarea>
                            </div>
                        </div>
                        <div class="col-2">
                            <label>Permohonan : </label>
                            <div class="form-group">
                                <select name="permohonan" class="form-control">
                                    <option>CUTI</option>
                                    <option>IJIN</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="col-7"><label>Alamat Tujuan (Lengkap) : </label>
                            <div class="form-group">
                                <textarea name="tujuan" class="form-control" rows="4" required></textarea>
                            </div>
                        </div>
                        <div class="col-5"><label>Keperluan : </label>
                            <div class="form-group">
                                <textarea name="keperluan" class="form-control" rows="4" required></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="col-4"><label>Berangkat : </label>
                            <div class="form-group">
                                <input type="date" name="waktu_berangkat" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-4"><label>Kembali : </label>
                            <div class="form-group">
                                <input type="date" name="waktu_kembali" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-4"><label>Kendaraan : </label>
                            <div class="form-group">
                                <select name="kendaraan" class="form-control" required>
                                    <option>Pribadi/Bus</option>
                                    <option>Kendaraan Dinas</option>
                                    <option>Kendaraan Lain</option>
                                </select>
                            </div>
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>