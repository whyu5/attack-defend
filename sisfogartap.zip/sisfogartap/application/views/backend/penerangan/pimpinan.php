<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>
<div class="flash-data2" data-flashdata2="<?= $this->session->flashdata('pesan') ?>"></div>


<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><b><?= $title ?></b></h1>
    <p class="mb-4">Anda dapat mengelola para Pimpinan Kogartap II/Bdg untuk dapat di bagikan ke publik disini !</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="#" class="btn btn-outline-primary" data-toggle="modal" data-target="#M_Add_Pimpin" type="button">
                <i class="fas fa-fw fa-plus"></i>
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th class="table-plus datatable-nosort" width="20">NO.</th>
                            <th>AKSI</th>
                            <th>GAMBAR</th>
                            <th>NAMA</th>
                            <th>JABATAN</th>
                            <th>AKUN SOSMED</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($user as $u) {
                        ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td>

                                    <button type="button" data-toggle="modal" data-target="#M_Edit_Pimp" id="btn-edit-pimpinan" class="btn btn-primary" data-id="<?= $u->id; ?>" data-jabatan="<?= $u->jabatan; ?>" data-nama="<?= $u->nama; ?>" data-fb="<?= $u->fb; ?>" data-yt="<?= $u->yt; ?>" data-ig="<?= $u->ig; ?>">
                                        <i class="fas fa-fw fa-edit"></i>
                                    </button>

                                    <a href="delete-propim/<?= $u->id ?>/<?= $u->gambar ?>" class="btn btn-danger btn-hapus">
                                        <i class="fas fa-fw fa-trash"></i>
                                    </a>

                                    <button type="button" data-toggle="modal" data-target="#M_Edit_Pimp_Gambar" id="btn-edit-pimpinan" class="btn btn-success" data-id="<?= $u->id; ?>" data-nama="<?= $u->nama; ?>" data-gambar="<?= $u->gambar; ?>">
                                        <i class="fas fa-fw fa-camera"></i>
                                    </button>
                                </td>
                                <td><img src="<?= base_url('public/uploads/homepage/pimpinan/') ?><?= $u->gambar; ?>" width="100px" class="img-fluid"></td>
                                <td><?= $u->nama ?></td>
                                <td><?= $u->jabatan ?></td>
                                <td>IG : <?= $u->ig ?>
                                    <br>YT : <?= $u->yt ?>
                                    <br>FB : <?= $u->fb ?>
                                </td>
                            </tr>

                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<div class="modal fade" id="M_Add_Pimpin" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Tambah Pimpinan</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('add-propim'); ?>">
                    <label>Nama Lengkap : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nama Lengkap" name="nama" class="form-control" required>
                    </div>
                    <label>Jabatan : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Jabatan" name="jabatan" class="form-control" required>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label>Instagram : </label>
                            <input type="text" placeholder="Akun Instagram" name="ig" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label>Youtube : </label>
                            <input type="text" placeholder="Youtube Channel" name="yt" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label>Facebook : </label>
                            <input type="text" placeholder="Akun Facebook" name="fb" class="form-control" required>
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="M_Edit_Pimp" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Perbarui Data</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('update-propim'); ?>">
                    <input type="hidden" name="id" id="id2-pimpinan" class="form-control">
                    <label>Nama Lengkap : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nama Lengkap" id="nama2-pimpinan" name="nama" class="form-control" required>
                    </div>
                    <label>Jabatan : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Jabatan" id="jabatan-pimpinan" name="jabatan" class="form-control" required>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label>Instagram : </label>
                            <input type="text" placeholder="Akun Instagram" id="ig-pimpinan" name="ig" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label>Youtube : </label>
                            <input type="text" placeholder="Youtube Channel" id="yt-pimpinan" name="yt" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label>Facebook : </label>
                            <input type="text" placeholder="Akun Facebook" id="fb-pimpinan" name="fb" class="form-control" required>
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="M_Edit_Pimp_Gambar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Foto Pimpinan</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" enctype="multipart/form-data" method="post" action="<?= base_url('foto-propim'); ?>">
                    <input type="hidden" name="id" id="id-pimpinan" class="form-control">
                    <label>Nama Lengkap : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nomor NRP/NBI" id="nama-pimpinan" name="nama" class="form-control" readonly>
                        <input type="hidden" id="gambar-pimpinan" name="old_gambar" class="form-control" readonly>
                    </div>
                    <label>Gambar : </label>
                    <div class="form-group">
                        <input type="file" name="gambar" class="form-control" required>
                        <small>Gunakan file ukuran maksimal 1 Mb dan ber-ekstensi jpg, png, jpeg. Untuk memperkecil
                            ukuran file dapat dilakukan <a href="https://www.iloveimg.com/compress-image/compress-jpg" class="badge badge-danger">di Link ini
                                !!</a></small>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).on('click', '#btn-edit-pimpinan', function() {
        $('.modal-body #id-pimpinan').val($(this).data('id'));
        $('.modal-body #id2-pimpinan').val($(this).data('id'));
        $('.modal-body #nama-pimpinan').val($(this).data('nama'));
        $('.modal-body #nama2-pimpinan').val($(this).data('nama'));
        $('.modal-body #jabatan-pimpinan').val($(this).data('jabatan'));
        $('.modal-body #ig-pimpinan').val($(this).data('ig'));
        $('.modal-body #yt-pimpinan').val($(this).data('yt'));
        $('.modal-body #fb-pimpinan').val($(this).data('fb'));
        $('.modal-body #gambar-pimpinan').val($(this).data('gambar'));
    });
</script>