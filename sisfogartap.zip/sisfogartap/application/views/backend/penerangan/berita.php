<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><b><?= $title ?></b></h1>
    <p class="mb-4">Anda dapat mengelola Berita terkait Kogartap II/Bdg untuk dapat di bagikan ke publik disini !</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?= base_url('add-buletin') ?>" class="btn btn-outline-primary" type="button">
                <i class="fas fa-fw fa-plus"></i>
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th class="table-plus datatable-nosort" width="20">NO.</th>
                            <th>AKSI</th>
                            <th>KATEGORI</th>
                            <th>JUDUL</th>
                            <th>GAMBAR</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($user as $u) {
                        ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td width="150">
                                    <a href="<?= base_url('edit-buletin/' . $u->id) ?>" class="btn btn-primary">
                                        <i class="fas fa-fw fa-eye"></i>
                                    </a>
                                    <a href="delete-buletin/<?= $u->id ?>/<?= $u->gambar ?>" class="btn btn-danger btn-hapus">
                                        <i class="fas fa-fw fa-trash"></i>
                                    </a>
                                    <button type="button" data-toggle="modal" data-target="#M_Edit_Pimp_Berita" id="btn-edit-berita" class="btn btn-success" data-id="<?= $u->id; ?>" data-judul="<?= $u->judul; ?>" data-gambar="<?= $u->gambar; ?>">
                                        <i class="fas fa-fw fa-camera"></i>
                                    </button>
                                </td>
                                <td><?= $u->kategori ?></td>
                                <td><?= $u->judul ?></td>
                                <td><img src="<?= base_url('public/uploads/homepage/berita/') ?><?= $u->gambar; ?>" width="100px" class="img-fluid"></td>
                            </tr>

                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<div class="modal fade" id="M_Edit_Pimp_Berita" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Foto Pemberitaan</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" enctype="multipart/form-data" method="post" action="<?= base_url('update-foto-buletin'); ?>">
                    <input type="hidden" name="id" id="id-berita" class="form-control">
                    <label>Judul Berita : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nomor NRP/NBI" id="judul-berita" name="judul" class="form-control" readonly>
                        <input type="hidden" id="gambar-berita" name="old_gambar" class="form-control" readonly>
                    </div>
                    <label>Gambar : </label>
                    <div class="form-group">
                        <input type="file" name="gambar" class="form-control" required>
                        <small>Gunakan file ukuran maksimal 1 Mb dan ber-ekstensi jpg, png, jpeg. Untuk memperkecil
                            ukuran file dapat dilakukan <a href="https://www.iloveimg.com/compress-image/compress-jpg" class="badge badge-danger">di Link ini
                                !!</a></small>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).on('click', '#btn-edit-berita', function() {
        $('.modal-body #id-berita').val($(this).data('id'));
        $('.modal-body #judul-berita').val($(this).data('judul'));
        $('.modal-body #gambar-berita').val($(this).data('gambar'));
    });
</script>