<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><b>Survey UP3M Garnisun II</b></h1>
    <p class="mb-4">Anda dapat mengelola Berita terkait Kogartap II/Bdg untuk dapat di bagikan ke publik disini !</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th class="table-plus datatable-nosort" width="20">NO.</th>
                            <th>WAKTU</th>
                            <th>EMAIL</th>
                            <th>NAMA</th>
                            <th>JUDUL</th>
                            <th>ISI PESAN</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($user as $u) {
                        ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td>
                                    <button type="button" class="btn btn-danger btn-sm"><i class="fas fa-fw fa-clock"></i> |
                                        <?= $u->waktu ?></button>
                                </td>
                                <td><span class="badge badge-pill badge-success"><?= $u->email ?></span></td>
                                <td><?= $u->nama ?></td>
                                <td><?= $u->judul ?></td>
                                <td><?= $u->pesan ?></td>
                            </tr>

                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>