<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><b><?= $title ?> Indeks Kepuasan Masyarakat</b></h1>
    <p class="mb-4">Anda dapat melihat hasil polling survey terkait pelayanan Kogartap II/Bdg dengan nilai tertinggi <span class="badge badge-primary">48</span> !</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th class="table-plus datatable-nosort" width="20">NO.</th>
                            <th>WAKTU</th>
                            <th>EMAIL / NO HP</th>
                            <th>NAMA</th>
                            <th>SATKER</th>
                            <th>SKOR</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($user as $u) {
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <button type="button" class="btn btn-danger btn-sm"><i class="fas fa-fw fa-clock"></i> |
                                    <?= $u->at ?></button>
                            </td>
                            <td><?= $u->email ?> / <?= $u->telp ?></td>
                            <td><?= $u->nama ?></td>
                            <td><?= $u->satker ?></td>
                            <td>
                                <?php
                                $qq = ($u->q1+$u->q2+$u->q3+$u->q4+$u->q5+$u->q6+$u->q7+$u->q8+$u->q9+$u->q10+$u->q11+$u->q12+$u->q13+$u->q14+$u->q15+$u->q16);
                                
                                ?>
                                <button class="btn btn-sm btn-primary"><?= $qq ?></button>
                            </td>
                        </tr>

                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>