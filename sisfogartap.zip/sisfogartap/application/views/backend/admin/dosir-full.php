<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>
<div class="flash-data2" data-flashdata2="<?= $this->session->flashdata('pesan') ?>"></div>

<?php
$no = 1;
foreach ($user as $u) {
?>
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><b><?= $title; ?></b></h1>
    <p class="mb-4">Dihalaman ini, Anda dapat mengelola dosir secara ter-struktur dan rapi</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <object data="<?= base_url('public/uploads/pdf/') ?><?php echo $u->pdf ?>" width="100%" height="1000px"
                style="border:1px; box-shadow: 2px 2px 8px #000000;">

            </object>
        </div>
    </div>

</div>
<?php } ?>