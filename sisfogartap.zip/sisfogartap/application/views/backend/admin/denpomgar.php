<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><b><?= $title ?></b></h1>
    <p class="mb-4">Anda dapat mengelola Inventaris Kendaraan Bermotor Kogartap II/Bdg disini !</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="#" class="btn btn-outline-primary" data-toggle="modal" data-target="#M_Add_Kendaraan" type="button">
                <i class="fas fa-fw fa-plus"></i>
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th class="table-plus datatable-nosort" width="20">NO.</th>
                            <th>AKSI</th>
                            <th>NAMA KENDARAAN</th>
                            <th>REGISTER</th>
                            <th>PEMILIK</th>
                            <th>EXPIRED</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($user as $u) {
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <button type="button" data-toggle="modal" data-target="#M_Edit_Kendaraan"
                                    id="btn-edit-kendaraan" class="btn btn-primary" data-id="<?= $u->id; ?>"
                                    data-name="<?= $u->name; ?>" data-jenis="<?= $u->jenis; ?>"
                                    data-kondisi="<?= $u->kondisi; ?>" data-nomor="<?= $u->nomor; ?>" data-register="<?= $u->register; ?>"
                                    data-tahun_buat="<?= $u->tahun_buat; ?>"
                                    data-warna="<?= $u->warna; ?>"
                                    data-expired="<?= $u->expired; ?>"
                                    data-pemilik="<?= $u->pemilik; ?>"
                                    data-rangka="<?= $u->rangka; ?>"
                                    data-alamat_pj="<?= $u->alamat_pj; ?>"
                                    data-nohp_pj="<?= $u->nohp_pj; ?>"
                                    data-petugas="<?= $u->petugas; ?>"
                                    data-cc="<?= $u->cc; ?>">
                                    <i class="fas fa-fw fa-edit"></i>
                                </button>

                                <a href="delete-kendaraan/<?= $u->id ?>" class="btn btn-danger btn-hapus">
                                    <i class="fas fa-fw fa-trash"></i>
                                </a>
                            </td>
                            <td><?= $u->name ?></td>
                            <td><?= $u->register ?></td>
                            <td><?= $u->pemilik ?></td>
                            <td><button type="button" class="btn btn-success btn-sm"><?= $u->expired ?></button></td>
                        </tr>

                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<div class="modal fade" id="M_Add_Kendaraan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;"><b>Tambah Kendaraan</b></h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('add-kendaraan'); ?>">
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label><b>Nama Kendaraan : </b></label>
                            <input type="text" placeholder="Nama Kendaraan"  name="name"
                                class="form-control">
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Nomor Mesin : </b></label>
                            <input type="text" placeholder="Nomor Mesin"  name="nomor"
                                class="form-control">
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Nomor Rangka : </b></label>
                            <input type="text" placeholder="Nomor Rangka"  name="rangka"
                                class="form-control">
                        </div>

                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label><b>Jenis Kendaraan : </b></label>
                            <select class="form-control" name="jenis" required>
                                <option>MOTOR</option>
                                <option>JEEP</option>
                                <option>MINIBUS</option>
                                <option>SEDAN</option>
                                <option>TRUCK</option>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Tanggal Expired : </b></label>
                            <input type="date" name="expired"
                                class="form-control" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Pengguna Kendaraan : </b></label>
                            <input type="text" placeholder="Pengguna Kendaraan" name="pemilik" class="form-control"
                                required>
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Kondisi Kendaraan : </b></label>
                            <input type="text" placeholder="Kondisi Kendaraan" name="kondisi" class="form-control"
                                required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label><b>Tahun Keluar : </b></label>
                            <input type="number" placeholder="Tahun Keluar"  name="tahun_buat"
                                class="form-control">
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Nomor Register : </b></label>
                            <input type="text" placeholder="Nomor Register"  name="register"
                                class="form-control">
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Warna Kendaraan : </b></label>
                            <input type="text" placeholder="Warna Kendaraan" name="warna"
                                class="form-control">
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Jumlah CC : </b></label>
                            <input type="number" placeholder="Jumlah CC" name="cc"
                                class="form-control">
                        </div>

                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label><b>Pengusul : </b></label>
                            <input type="text" placeholder="Pengusul"  name="petugas"
                                class="form-control">
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Nomor HP Pemilik : </b></label>
                            <input type="number" placeholder="Nomor HP Pemilik"  name="nohp_pj"
                                class="form-control">
                        </div>
                        <div class="form-group col-md-6">
                            <label><b>Alamat Pemilik : </b></label>
                            <textarea name="alamat_pj"  rows="5" class="form-control"></textarea>
                        </div>

                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="M_Edit_Kendaraan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;"><b>Perbarui Kendaraan</b></h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('update-kendaraan'); ?>">
                    <input type="hidden" name="id" id="id-kendaraan" class="form-control">
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label><b>Nama Kendaraan : </b></label>
                            <input type="text" placeholder="Nama Kendaraan" id="name-kendaraan" name="name"
                                class="form-control">
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Nomor Mesin : </b></label>
                            <input type="text" placeholder="Nomor Mesin" id="nomor-kendaraan" name="nomor"
                                class="form-control">
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Nomor Rangka : </b></label>
                            <input type="text" placeholder="Nomor Rangka" id="rangka-kendaraan" name="rangka"
                                class="form-control">
                        </div>

                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label><b>Jenis Kendaraan : </b></label>
                            <select class="form-control" name="jenis" id="jenis-kendaraan" required>
                                <option>MOTOR</option>
                                <option>JEEP</option>
                                <option>MINIBUS</option>
                                <option>SEDAN</option>
                                <option>TRUCK</option>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Tanggal Expired : </b></label>
                            <input type="date"  id="expired-kendaraan" name="expired"
                                class="form-control" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Pengguna Kendaraan : </b></label>
                            <input type="text" placeholder="Pengguna Kendaraan" id="pemilik-kendaraan" name="pemilik" class="form-control"
                                required>
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Kondisi Kendaraan : </b></label>
                            <input type="text" placeholder="Kondisi Kendaraan" id="kondisi-kendaraan" name="kondisi" class="form-control"
                                required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label><b>Tahun Keluar : </b></label>
                            <input type="number" placeholder="Tahun Keluar" id="tahun_buat-kendaraan" name="tahun_buat"
                                class="form-control">
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Nomor Register : </b></label>
                            <input type="text" placeholder="Nomor Register" id="register-kendaraan" name="register"
                                class="form-control">
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Warna Kendaraan : </b></label>
                            <input type="text" placeholder="Warna Kendaraan" id="warna-kendaraan" name="warna"
                                class="form-control">
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Jumlah CC : </b></label>
                            <input type="number" placeholder="Jumlah CC" id="cc-kendaraan" name="cc"
                                class="form-control">
                        </div>

                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label><b>Pengusul : </b></label>
                            <input type="text" placeholder="Pengusul" id="petugas-kendaraan" name="petugas"
                                class="form-control">
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Nomor HP Pemilik : </b></label>
                            <input type="number" id="nohp_pj-kendaraan" placeholder="Nomor HP Pemilik"  name="nohp_pj"
                                class="form-control">
                        </div>
                        <div class="form-group col-md-6">
                            <label><b>Alamat Pemilik : </b></label>
                            <textarea name="alamat_pj" id="alamat_pj-kendaraan" rows="5" class="form-control"></textarea>
                        </div>

                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>
<script type="text/javascript">
$(document).on('click', '#btn-edit-kendaraan', function() {
    $('.modal-body #id-kendaraan').val($(this).data('id'));
    $('.modal-body #jenis-kendaraan').val($(this).data('jenis'));
    $('.modal-body #expired-kendaraan').val($(this).data('expired'));
    $('.modal-body #name-kendaraan').val($(this).data('name'));
    $('.modal-body #nomor-kendaraan').val($(this).data('nomor'));
    $('.modal-body #pemilik-kendaraan').val($(this).data('pemilik'));
    $('.modal-body #rangka-kendaraan').val($(this).data('rangka'));
    $('.modal-body #register-kendaraan').val($(this).data('register'));
    $('.modal-body #tahun_buat-kendaraan').val($(this).data('tahun_buat'));
    $('.modal-body #warna-kendaraan').val($(this).data('warna'));
    $('.modal-body #cc-kendaraan').val($(this).data('cc'));
    $('.modal-body #kondisi-kendaraan').val($(this).data('kondisi'));
    $('.modal-body #petugas-kendaraan').val($(this).data('petugas'));
    $('.modal-body #nohp_pj-kendaraan').val($(this).data('nohp_pj'));
    $('.modal-body #alamat_pj-kendaraan').val($(this).data('alamat_pj'));
});
</script>