<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><b><?= $title ?></b></h1>
    <p class="mb-4">Anda dapat mengelola daftar riwayat hidup masing-masing anggota secara mandiri</p>


    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th class="table-plus datatable-nosort" width="20">NO.</th>
                            <th>AKSI</th>
                            <th>(NRP/NIP) / PANGKAT</th>
                            <th>NAMA / JABATAN</th>
                            <th>TMT JABATAN</th>
                            <th>UKP</th>
                            <th>STATUS</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($user as $u) {
                        ?>
                            <tr>
                                <td><?php echo $no++ ?></td>
                                <td width="50">
                                    <a href="view-riwayat/<?= $u->id ?>" class="btn btn-success">
                                        <i class="fas fa-fw fa-eye"></i>
                                    </a>
                                </td>
                                <td><?php echo $u->nrp ?> <br>
                                    <?php echo $u->pangkat ?>
                                </td>
                                <td><?php echo $u->nama ?> <br>
                                    <?php echo $u->jabatan ?>
                                </td>
                                <?php
                                $tanggal = new DateTime($u->tmt_jab);
                                $today = new DateTime("today");
                                $y = $today->diff($tanggal)->y;
                                $m = $today->diff($tanggal)->m;
                                $d = $today->diff($tanggal)->d;

                                ?>

                                <td><?php echo $u->tmt_jab ?> <br>
                                    <b><?= $y ?> tahun, <?= $m ?> bulan,
                                        <?= $d ?> hari</b>
                                </td>
                                <?php
                                $date = date("Y-m-d");
                                $timeStart = strtotime("$u->tmt_kat");
                                $timeEnd = strtotime("$date");
                                // Menambah bulan ini + semua bulan pada tahun sebelumnya
                                $numBulan = (date("Y", $timeEnd) - date("Y", $timeStart)) * 12;
                                // menghitung selisih bulan
                                $numBulan += date("m", $timeEnd) - date("m", $timeStart);


                                ?>
                                <td><?php
                                    if ($numBulan >= 42 && $numBulan <= 49) {
                                        echo "<button class='btn btn-sm btn-danger'><i class='fas fa-fw fa-clock'></i></button>";
                                    } else {
                                        echo "<button class='btn btn-sm btn-primary'><i class='fas fa-fw fa-check'></i></button>";
                                    }
                                    ?></td>
                                <td>
                                    <?php
                                    if ($y > 2) {
                                        echo "<button class='btn btn-sm btn-danger'>Danger</button>";
                                    } else if ($y > 1 and $m >= 0) {
                                        echo "<button class='btn btn-sm btn-success'>Warning</button>";
                                    } else if ($y >= 0 and $m >= 0) {
                                        echo "<button class='btn btn-sm btn-primary'>Normal</button>";
                                    }
                                    ?>
                                </td>
                            </tr>

                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>