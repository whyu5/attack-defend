   <div class="container-fluid">

       <!-- Page Heading -->
       <h1 class="h3 mb-2 text-gray-800"><b>Update <?= $title ?></b></h1>
       <p class="mb-4">Anda dapat menambah Personil dari Kogartap II/Bandung</p>

       <!-- DataTales Example -->
       <div class="card shadow mb-4">
           <div class="card-body">
               <?php
                $no = 1;
                foreach ($user as $u) {
                ?>
               <?php } ?>
               <form method="post" action="<?= base_url('update-news'); ?>">
                   <div class="form-group row">
                       <label class="col-sm-2 col-form-label">JUDUL</label>
                       <div class="col-sm-10">
                           <input type="hidden" class="form-control" name="id" value="<?= $u->id ?>" required>
                           <input type="text" class="form-control" name="judul" value="<?= $u->judul ?>" required>
                       </div>
                   </div>
                   <div class="form-group row">
                       <label class="col-sm-2 col-form-label">SUBJEK</label>
                       <div class="col-sm-10">
                           <textarea name="quotes" class="form-control" rows="3"><?= $u->quotes ?></textarea>
                       </div>
                   </div>
                   <div class="form-group row">
                       <label class="col-sm-2 col-form-label">KATEGORI</label>
                       <div class="col-sm-10">
                           <select class="form-control" name="kategori" required>
                               <option><?= $u->kategori ?></option>
                               <option>PROTOKOLER</option>
                               <option>PEMAKAMAN</option>
                               <option>DENPOM</option>
                               <option>DETASEMEN</option>
                               <option>OPERASI</option>
                               <option>INTELIJEN</option>
                           </select>
                       </div>
                   </div>
                   <div class="form-group row">
                       <label class="col-sm-2 col-form-label">ISI BERITA</label>
                       <div class="col-sm-10">
                           <textarea id="mytextarea" name="isi"><?= $u->isi ?></textarea>
                       </div>
                   </div>
                   <div class="form-group row">
                       <div class="col-sm-12" style="text-align: right;">
                           <button type="reset" class="btn btn-secondary"><i class="fas fa-fw fa-retweet"></i></button>
                           <button type="submit" class="btn btn-primary"><i
                                   class="fas fa-fw fa-paper-plane"></i></button>

                       </div>
                   </div>
               </form>

           </div>
       </div>

   </div>