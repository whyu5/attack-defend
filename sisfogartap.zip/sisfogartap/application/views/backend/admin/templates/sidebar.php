<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?= $title; ?> - Kogartap II/Bdg</title>
    <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('public/backend/') ?>mabes.png">


    <!-- Custom fonts for this template-->
    <link href="<?= base_url('public/backend/') ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet"
        type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?= base_url('public/backend/') ?>css/sb-admin-2.min.css" rel="stylesheet">
    <link href="<?= base_url('public/backend/') ?>vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="<?= base_url('public/backend/') ?>sweetalert2/package/dist/sweetalert2.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <style type="text/css">
    .nav-item {
        margin-top: -10px;
        margin-bottom: -10px;
    }
    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url(); ?>">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-balance-scale"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Kogartap <sup>II</sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="#">
                    <img class="img-profile rounded-circle"
                        src="<?= base_url('public/backend/') ?>img/undraw_profile.svg">
                    <?php $nama = $this->session->userdata('nama');
                    $user = $this->db->get_where('user', ['username' => $nama])->row_array();
                    $namanya = $user['nama'];
                    $level = $user['level'];
                    $id = $user['id'];
                    ?>
                    <span><?= strtoupper($namanya); ?></span>
                </a>
            </li>



            <!-- Divider -->
            <!-- <hr class="sidebar-divider"> -->
            <li class="nav-item <?php if ($title == 'Dashboard') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?>">
                <a class="nav-link" href="<?= base_url('dashboard'); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>DASHBOARD</span>
                </a>
            </li>
            <!-- Heading -->
            <div class="sidebar-heading">
                MAIN MENU
            </div>
            <li class="nav-item <?php if ($title == 'Data Berita') {
                                    echo "active";
                                } else if ($title == 'Data Pimpinan') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?>">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
                    aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-camera"></i>
                    <span>PENERANGAN</span>
                </a>
                <div id="collapseUtilities" class="collapse <?php if ($title == 'Data Berita') {
                                                                echo "show";
                                                            } else if ($title == 'Data Pimpinan') {
                                                                echo "show";
                                                            } else {
                                                                echo "";
                                                            }; ?>" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">SETUP HOMEPAGE:</h6>
                        <a class="collapse-item <?php if ($title == 'Data Berita') {
                                                    echo "active";
                                                } else {
                                                    echo "";
                                                }; ?>" href="<?= base_url('news'); ?>">BULETIN</a>
                        <a class="collapse-item <?php if ($title == 'Data Pimpinan') {
                                                    echo "active";
                                                } else {
                                                    echo "";
                                                }; ?>" href="<?= base_url('pimpinan'); ?>">UNSUR PIMPINAN</a>
                    </div>
                </div>
            </li>

            <li class="nav-item <?php if ($title == 'Surat Elektronik') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?>">
                <a class="nav-link" href="<?= base_url('surat-elektronik'); ?>">
                    <i class="fas fa-fw fa-envelope"></i>
                    <span>SEKRETARIAT</span></a>
            </li>

            <li class="nav-item <?php if ($title == 'Detasemen POM') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?>">
                <a class="nav-link" href="<?= base_url('denpom'); ?>">
                    <i class="fas fa-fw fa-warehouse"></i>
                    <span>DETASEMEN POM</span></a>
            </li>

            <li class="nav-item <?php if ($title == 'Pemakaman') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?>">
                <a class="nav-link" href="<?= base_url('berita-kematian'); ?>">
                    <i class="fas fa-fw fa-home"></i>
                    <span>PERAWATAN JENAZAH</span></a>
            </li>

            <li class="nav-item <?php if ($title == 'Data Berita') {
                                    echo "active";
                                } else if ($title == 'Data Pesan') {
                                    echo "active";
                                } else if ($title == 'Data Pimpinan') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?>">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities2"
                    aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-flag"></i>
                    <span>SURVEY PUBLIC</span>
                </a>
                <div id="collapseUtilities2" class="collapse <?php if ($title == 'Survey') {
                                                                echo "show";
                                                            } else if ($title == 'Data Pesan') {
                                                                echo "show";
                                                            } else {
                                                                echo "";
                                                            }; ?>" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">SETUP SURVEY:</h6>
                        <a class="collapse-item <?php if ($title == 'Data Pesan') {
                                                    echo "active";
                                                } else {
                                                    echo "";
                                                }; ?>" href="<?= base_url('comment'); ?>">SURVEY UP3M</a>
                        <a class="collapse-item <?php if ($title == 'Survey') {
                                                    echo "active";
                                                } else {
                                                    echo "";
                                                }; ?>" href="<?= base_url('feed-survey'); ?>">SURVEY KEPUASAN</a>
                        
                    </div>
                </div>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                DATABASE & SETTINGS
            </div>
            <li class="nav-item <?php if ($title == 'Dosir Elektronik') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?>">
                <a class="nav-link" href="<?= base_url('dosir'); ?>">
                    <i class="fas fa-fw fa-print"></i>
                    <span>DOSIR ELEKTRONIK</span></a>
            </li>
            <li class="nav-item <?php if ($title == 'Data Personil') {
                                    echo "active";
                                } else if ($title == 'Data Jabatan') {
                                    echo "active";
                                } else if ($title == 'Riwayat Hidup') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?>">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-briefcase"></i>
                    <span>MASTER PERSONEL</span>
                </a>
                <div id="collapseTwo" class="collapse <?php if ($title == 'Data Personil') {
                                                            echo "show";
                                                        } else if ($title == 'Data Jabatan') {
                                                            echo "show";
                                                        } else if ($title == 'Riwayat Hidup') {
                                                            echo "show";
                                                        } else {
                                                            echo "";
                                                        }; ?>" aria-labelledby="headingTwo"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">DATABASE PERSONEL:</h6>
                        <a class="collapse-item <?php if ($title == 'Data Jabatan') {
                                                    echo "active";
                                                } else {
                                                    echo "";
                                                }; ?>" href="<?= base_url('jabatan'); ?>"
                            href="<?= base_url('Dash/Jabatan'); ?>">DSP JABATAN</a>

                        <a class="collapse-item <?php if ($title == 'Data Personil') {
                                                    echo "active";
                                                } else {
                                                    echo "";
                                                }; ?>" href="<?= base_url('personil'); ?>">ALL PERSONEL</a>

                        <a class="collapse-item <?php if ($title == 'Riwayat Hidup') {
                                                    echo "active";
                                                } else {
                                                    echo "";
                                                }; ?>" href="<?= base_url('riwayat-hidup'); ?>"
                            href="<?= base_url('Dash/Jabatan'); ?>">RIWAYAT HIDUP</a>
                    </div>
                </div>

            </li>

            <li class="nav-item <?php if ($title == 'Users') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?>">
                <a class="nav-link " href="<?= base_url('users'); ?>">
                    <i class="fas fa-fw fa-cogs"></i>
                    <span>AKUN</span></a>
            </li>

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                    <!-- Topbar Search -->
                    <form
                        class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div class="input-group">
                            <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..."
                                aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search "></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-book fa-fw"></i>
                            </a>
                            <!-- Dropdown - Alerts -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="alertsDropdown">
                                <h6 class="dropdown-header">
                                    PUSTAKA DATA KOGARTAP II/BDG
                                </h6>
                                <a class="dropdown-item d-flex align-items-center"
                                    href="<?= base_url('surat-menyurat') ?>">
                                    <div class="mr-3">
                                        <i class="fas fa-file fa-fw"></i>
                                    </div>
                                    <div>
                                        <span>Format surat menyurat</span>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center"
                                    href="<?= base_url('pip-bulanan') ?>">
                                    <div class="mr-3">
                                        <i class="fas fa-list fa-fw"></i>
                                    </div>
                                    <div>
                                        <span>Penilaian individu pegawai</span>
                                    </div>
                                </a>
                            </div>
                        </li>

                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" data-toggle="modal"
                                data-target="#M_Change_Pass" id="btn-edit" data-id="<?= $id; ?>">
                                <i class="fas fa-unlock fa-fw"></i>
                            </a>

                            <!-- Dropdown - Alerts -->

                        </li>
                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span
                                    class="mr-2 d-none d-lg-inline text-gray-600 small"><?= strtoupper($namanya); ?></span>
                                <img class="img-profile rounded-circle"
                                    src="<?= base_url('public/backend/') ?>img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">

                                <a class="dropdown-item" href="" data-toggle="modal" data-target="#M_Profile"
                                    id="btn-edit" data-id="<?= $id; ?>">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>Profile
                                </a>
                                <a class="dropdown-item" href="<?= base_url('logout') ?>" data-toggle="modal"
                                    data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->