   <div class="container-fluid">

       <!-- Page Heading -->
       <h1 class="h3 mb-2 text-gray-800"><b><?= $title ?></b></h1>
       <p class="mb-4">Anda dapat menambah Personil dari Kogartap II/Bandung</p>

       <!-- DataTales Example -->
       <div class="card shadow mb-4">
           <div class="card-header py-3" align="left">
               <h6 class="m-0 font-weight-bold text-primary">FORM TAMBAH PERSONIL KOGARTAP II/BDG</h6>
           </div>
           <div class="card-body">

               <form method="post" action="<?= base_url('add-personil'); ?>">
                   <div class="form-group row">
                       <label class="col-sm-2 col-form-label">NRP/NIB/NIP</label>
                       <div class="col-sm-10">
                           <input type="number" class="form-control" name="nrp" required>
                       </div>
                   </div>
                   <div class="form-group row">
                       <label class="col-sm-2 col-form-label">NAMA LENGKAP</label>
                       <div class="col-sm-10">
                           <input type="text" name="nama" class="form-control" required>
                       </div>
                   </div>
                   <div class="form-group row">
                       <label class="col-sm-2 col-form-label">PANGKAT</label>
                       <div class="col-sm-10">
                           <select class="js-example-basic-single" style="width:100%" name="pangkat" required>
                               <?php
                                $no = 1;
                                foreach ($pangkat as $u) {
                                ?>
                               <option value="<?= $u->pangkat ?>"><?= $u->pangkat ?> - <?= $u->deskripsi ?></option>
                               <?php } ?>
                           </select>
                       </div>
                   </div>
                   <div class="form-group row">
                       <label class="col-sm-2 col-form-label">JABATAN</label>
                       <div class="col-sm-10">
                           <select class="js-example-basic-single" style="width:100%" name="jabatan" required>
                               <?php
                                $no = 1;
                                foreach ($user as $u) {
                                ?>
                               <option><?= $u->nama ?></option>
                               <?php } ?>
                           </select>
                       </div>
                   </div>
                   <div class="form-group row">
                       <label class="col-sm-2 col-form-label">TMT JABATAN</label>
                       <div class="col-sm-10">
                           <input type="date" class="form-control" name="tmt_jab" required>
                       </div>
                   </div>
                   <div class="form-group row">
                       <label class="col-sm-2 col-form-label">TANGGAL LAHIR</label>
                       <div class="col-sm-10">
                           <input type="date" class="form-control" name="tgl_lahir" required>
                       </div>
                   </div>
                   <div class="form-group row">
                       <label class="col-sm-2 col-form-label">KESATUAN</label>
                       <div class="col-sm-10">
                           <input type="text" class="form-control" name="kesatuan" value="KOGARTAP II/BDG" readonly>
                       </div>
                   </div>
                   <div class="form-group row">
                       <div class="col-sm-12" style="text-align: right;">
                           <button type="reset" class="btn btn-secondary"><i class="fas fa-fw fa-retweet"></i></button>
                           <button type="submit" class="btn btn-primary"><i
                                   class="fas fa-fw fa-paper-plane"></i></button>

                       </div>
                   </div>
               </form>

           </div>
       </div>

   </div>