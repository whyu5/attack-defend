
<?php
$no = 1;
foreach ($user as $u) {
?>
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><b>Berkas Watzah</b></h1>
    <p class="mb-4">Dihalaman ini, Anda dapat melihat berkas watzah dalam bentuk pdf secara ter-struktur dan rapi</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <object data="<?= base_url('public/uploads/homepage/berkas/') ?><?php echo $u->pdf ?>" width="100%" height="1000px"
                style="border:1px; box-shadow: 2px 2px 8px #000000;">

            </object>
        </div>
    </div>

</div>
<?php } ?>