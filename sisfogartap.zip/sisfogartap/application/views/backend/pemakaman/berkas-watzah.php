<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>
<?php
$no = 1;
foreach ($user as $u) {
?>
    <div class="container-fluid">
        <h1 class="h3 mb-2 text-gray-800"><b>Pengelolaan <?= $title ?></b></h1>
        <p class="mb-4">Berikut ini adalah data dukung pelaporan kematian dari <span class="badge badge-primary"><?php echo $u->pangkat . ' ' . $u->nama ?></span></p>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <button type="button" data-toggle="modal" data-target="#M_Add_Berkas" id="btn-update-berkas" class="btn btn-outline-primary" data-id="<?= $u->id; ?>" data-nrp="<?= $u->nrp; ?>" data-nama="<?= $u->nama; ?>">
                    <i class="fas fa-fw fa-upload"></i>
                </button>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th class="table-plus datatable-nosort" width="20">NO.</th>
                                <th width="90">AKSI</th>
                                <th>CAPTION BERKAS</th>
                                <th>NRP</th>
                                <th>STATUS</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            foreach ($berkas as $br) {
                            ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td>
                                        <a href="<?= base_url('full-berkaspm/') ?><?= $br->id ?>" class="btn btn-primary">
                                            <i class="fas fa-fw fa-eye"></i>
                                        </a>
                                        <a href="<?= base_url('delete-berkas-pm/') ?><?= $br->id ?>/<?= $br->pdf ?>" class="btn btn-danger btn-hapus">
                                            <i class="fas fa-fw fa-trash"></i>
                                        </a>
                                    </td>
                                    <td><?= $br->caption ?></td>
                                    <td><?= $br->nrp ?></td>
                                    <td width="50">
                                        <?php if ($br->pdf == '') {
                                            echo '<a href="#" class="btn btn-danger btn-circle"> <i class="fas fa-times"></i>';
                                        } else {
                                            echo '<a href="#" class="btn btn-success btn-circle"> <i class="fas fa-check"></i>';
                                        }
                                        ?></td>
                                </tr>

                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
<?php } ?>

<div class="modal fade" id="M_Add_Berkas" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Update Dokumen</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" enctype="multipart/form-data" method="post" action="<?= base_url('berkas-uploadpm'); ?>">
                    <input type="hidden" name="nrp" id="nrp-berkas">
                    <input type="hidden" name="id" id="id-berkas">

                    <label>Nama Anggota : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nama Anggota" name="nama" id="nama-berkas" class="form-control" readonly>
                    </div>
                    <label>Judul File : </label>
                    <div class="form-group">
                        <input type="text" placeholder="e.g : 'Surat Kelahiran'" name="caption" class="form-control" required>
                    </div>

                    <label>File PDF (Max 1Mb) : </label>
                    <div class="form-group">
                        <input type="file" name="pdf" class="form-control" required>
                        <small>Untuk memperkecil file pdf dapat dilakukan <a href="https://www.ilovepdf.com/id/mengompres-pdf" class="badge badge-danger">di Link ini
                                !!</a></small>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).on('click', '#btn-update-berkas', function() {
        $('.modal-body #id-berkas').val($(this).data('id'));
        $('.modal-body #nama-berkas').val($(this).data('nama'));
        $('.modal-body #nrp-berkas').val($(this).data('nrp'));
        $('.modal-body #caption-berkas').val($(this).data('caption'));
        $('.modal-body #idnya-berkas').val($(this).data('idnya'));
    });
</script>