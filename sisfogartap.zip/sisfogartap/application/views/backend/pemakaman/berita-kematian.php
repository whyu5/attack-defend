<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>

<div class="container-fluid">
    <h1 class="h3 mb-2 text-gray-800"><b>Pelaporan Kematian</b></h1>
    <p class="mb-4">Anda dapat mengelola Pemakaman dan Perawatan Jenazah Kogartap II/Bdg disini !</p>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th class="table-plus datatable-nosort" width="20">NO.</th>
                            <th width="140">AKSI</th>
                            <th>NAMA JENAZAH</th>
                            <th>NRP</th>
                            <th>TGL KEMATIAN</th>
                            <th>STATUS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($user as $u) {
                        ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td>
                                    <button type="button" data-toggle="modal" data-target="#M_Edit_Kematian" id="btn-edit-kematian" class="btn btn-primary" data-id="<?= $u->id; ?>" data-pelapor="<?= $u->pelapor; ?>" data-nohp_pelapor="<?= $u->nohp_pelapor; ?>" data-email_pelapor="<?= $u->email_pelapor; ?>" data-nama="<?= $u->nama; ?>" data-nrp="<?= $u->nrp; ?>" data-pangkat="<?= $u->pangkat; ?>" data-jabatan="<?= $u->jabatan; ?>" data-kesatuan="<?= $u->kesatuan; ?>" data-agama="<?= $u->agama; ?>" data-tpt_lahir="<?= $u->tpt_lahir; ?>" data-tgl_lahir="<?= $u->tgl_lahir; ?>" data-alamat="<?= $u->alamat; ?>" data-anak_ke="<?= $u->anak_ke; ?>" data-bapak="<?= $u->bapak; ?>" data-ibu="<?= $u->ibu; ?>" data-upacara="<?= $u->upacara; ?>" data-keterangan="<?= $u->keterangan; ?>" data-rencana_dimakamkan="<?= $u->rencana_dimakamkan; ?>" data-meninggalkan="<?= $u->meninggalkan; ?>" data-tgl_meninggal="<?= $u->tgl_meninggal; ?>" data-pukul="<?= $u->pukul; ?>" data-dimana="<?= $u->dimana; ?>" data-penyebab="<?= $u->penyebab; ?>">
                                        <i class="fas fa-fw fa-edit"></i>
                                    </button>

                                    <a href="delete-pm/<?= $u->id ?>/1" class="btn btn-danger btn-hapus">
                                        <i class="fas fa-fw fa-trash"></i>
                                    </a>

                                    <a href="view-pm/<?= $u->id ?>" class="btn btn-success">
                                        <i class="fas fa-fw fa-file-alt"></i>
                                    </a>
                                </td>
                                <td><?= $u->pangkat ?> <?= $u->nama ?></td>
                                <td><?= $u->nrp ?></td>
                                <td><?= $u->tgl_meninggal ?></td>
                                <td width="120"><button type="button" class="btn btn-danger btn-sm"><?= $u->status ?></button>
                                    <a href="ajukan-watzahpm/<?= $u->id ?>" class="btn btn-success btn-watzah btn-sm">
                                        <i class="fas fa-fw fa-arrow-up"></i>
                                    </a>
                                </td>
                            </tr>

                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>


<div class="modal fade" id="M_Add_Kematian" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;"><b>Tambah Berita Kematian</b></h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('add-pm'); ?>">
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label><b>Nama Pelapor : </b></label>
                            <input type="text" placeholder="Nama Pelapor" name="pelapor" class="form-control">
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Nomor Handphone : </b></label>
                            <input type="number" placeholder="Nomor Handphone" name="nohp_pelapor" class="form-control">
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Alamat Email : </b></label>
                            <input type="email" placeholder="Alamat Email" name="email_pelapor" class="form-control">
                        </div>
                    </div>
                    <hr>
                    <h3><b>Data yang meninggal</b></h3>
                    <p style="color: red; margin-top:-10px;"><i>*Data ini akan digunakan sebagai acuan untuk membentuk data dukung lainnya.</i></p>
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label><b>Nama Jenazah : </b></label>
                            <input type="text" name="nama" placeholder="Nama Jenazah" class="form-control" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Pangkat/Korps : </b></label>
                            <input type="text" name="pangkat" placeholder="Pangkat/Korps" class="form-control" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>NRP : </b></label>
                            <input type="text" name="nrp" placeholder="NRP" class="form-control" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Jabatan Terakhir: </b></label>
                            <input type="text" placeholder="Jabatan" name="jabatan" class="form-control" required>
                        </div>

                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label><b>Kesatuan Terakhir : </b></label>
                            <input type="text" placeholder="Kesatuan" name="kesatuan" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Agama : </b></label>
                            <select class="form-control" name="agama" required>
                                <option>ISLAM</option>
                                <option>PROTESTAN</option>
                                <option>KATHOLIK</option>
                                <option>HINDU</option>
                                <option>BUDHA</option>
                                <option>KONG HU CU</option>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Anak Ke : </b></label>
                            <input type="number" placeholder="Anak Ke" name="anak_ke" class="form-control">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label><b>Tempat Lahir : </b></label>
                            <input type="text" placeholder="Tempat Lahir" name="tpt_lahir" class="form-control">
                            <label style="margin-top:10px;"><b>Rencana Pemakaman : </b></label>
                            <input type="text" placeholder="Rencana Tempat Dimakamkan" name="rencana_dimakamkan" class="form-control">
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Tanggal Lahir : </b></label>
                            <input type="date" name="tgl_lahir" class="form-control">

                            <label style="margin-top:10px;"><b>Keterangan : </b></label>
                            <select class="form-control" name="keterangan" required>
                                <option>AKTIF</option>
                                <option>PURNAWIRAWAN</option>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label><b>Alamat : </b></label>
                            <textarea name="alamat" class="form-control" rows="5"></textarea>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label><b>Nama Bapak : </b></label>
                            <input type="text" placeholder="Nama Bapak" name="bapak" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Nama Ibu : </b></label>
                            <input type="text" placeholder="Nama Ibu" name="ibu" class="form-control">
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Meninggalkan Seorang : </b></label>
                            <select class="form-control" name="meninggalkan" required>
                                <option>SUAMI</option>
                                <option>ISTRI</option>
                            </select>
                        </div>

                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label><b>Tanggal Meninggal : </b></label>
                            <input type="date" placeholder="Tanggal Meninggal" name="tgl_meninggal" class="form-control" required>
                            <label style="margin-top:10px;"><b>Ket Upacara : </b></label>
                            <select name="upacara" class="form-control">
                                <option>UPACARA</option>
                                <option>NON UPACARA</option>

                            </select>

                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Pukul : </b></label>
                            <input type="time" name="pukul" class="form-control">
                        </div>
                        <div class="form-group col-md-6">
                            <label><b>Lokasi Meninggal : </b></label>
                            <textarea name="dimana" class="form-control" rows="5"></textarea>
                        </div>

                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label><b>Uraian Singkat Kematian : </b></label>
                            <textarea name="penyebab" class="form-control" rows="5"></textarea>
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="M_Edit_Kematian" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;"><b>Edit Berita Kematian</b></h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('update-pm'); ?>">
                    <div class="form-row">
                        <input type="hidden" name="id" id="id-kematian" class="form-control">
                        <input type="hidden" name="arah" value="<?= $this->uri->segment(1) ?>" class="form-control">

                        <div class="form-group col-md-4">
                            <label><b>Nama Pelapor : </b></label>
                            <input type="text" placeholder="Nama Pelapor" name="pelapor" id="pelapor-kematian" class="form-control">
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Nomor Handphone : </b></label>
                            <input type="number" placeholder="Nomor Handphone" name="nohp_pelapor" id="nohp_pelapor-kematian" class="form-control">
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Alamat Email : </b></label>
                            <input type="email" placeholder="Alamat Email" name="email_pelapor" id="email_pelapor-kematian" class="form-control">
                        </div>
                    </div>
                    <hr>
                    <h3><b>Data yang meninggal</b></h3>
                    <p style="color: red; margin-top:-10px;"><i>*Data ini akan digunakan sebagai acuan untuk membentuk data dukung lainnya.</i></p>
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label><b>Nama Jenazah : </b></label>
                            <input type="text" name="nama" placeholder="Nama Jenazah" class="form-control" id="nama-kematian" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Pangkat/Korps : </b></label>
                            <input type="text" id="pangkat-kematian" name="pangkat" placeholder="Pangkat/Korps" class="form-control" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>NRP : </b></label>
                            <input type="text" name="nrp" id="nrp-kematian" placeholder="NRP" class="form-control" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Jabatan Terakhir: </b></label>
                            <input type="text" id="jabatan-kematian" placeholder="Jabatan" name="jabatan" class="form-control" required>
                        </div>

                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label><b>Kesatuan Terakhir : </b></label>
                            <input type="text" id="kesatuan-kematian" placeholder="Kesatuan" name="kesatuan" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Agama : </b></label>
                            <select class="form-control" id="agama-kematian" name="agama" required>
                                <option>ISLAM</option>
                                <option>PROTESTAN</option>
                                <option>KATHOLIK</option>
                                <option>HINDU</option>
                                <option>BUDHA</option>
                                <option>KONG HU CU</option>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Anak Ke : </b></label>
                            <input type="number" id="anak_ke-kematian" placeholder="Anak Ke" name="anak_ke" class="form-control">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label><b>Tempat Lahir : </b></label>
                            <input type="text" id="tpt_lahir-kematian" placeholder="Tempat Lahir" name="tpt_lahir" class="form-control">
                            <label style="margin-top:10px;"><b>Rencana Pemakaman : </b></label>
                            <input type="text" placeholder="Rencana Tempat Dimakamkan" name="rencana_dimakamkan" id="rencana_dimakamkan-kematian" class="form-control">
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Tanggal Lahir : </b></label>
                            <input type="date" id="tgl_lahir-kematian" name="tgl_lahir" class="form-control">
                            <label style="margin-top:10px;"><b>Keterangan : </b></label>
                            <select class="form-control" name="keterangan" id="keterangan-kematian" required>
                                <option>AKTIF</option>
                                <option>PURNAWIRAWAN</option>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label><b>Alamat : </b></label>
                            <textarea name="alamat" id="alamat-kematian" class="form-control" rows="5"></textarea>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label><b>Nama Bapak : </b></label>
                            <input type="text" id="bapak-kematian" placeholder="Nama Bapak" name="bapak" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Nama Ibu : </b></label>
                            <input type="text" id="ibu-kematian" placeholder="Nama Ibu" name="ibu" class="form-control">
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Meninggalkan Seorang : </b></label>
                            <select class="form-control" id="meninggalkan-kematian" name="meninggalkan" required>
                                <option>SUAMI</option>
                                <option>ISTRI</option>
                            </select>
                        </div>

                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label><b>Tanggal Meninggal : </b></label>
                            <input type="date" id="tgl_meninggal-kematian" placeholder="Tanggal Meninggal" name="tgl_meninggal" class="form-control" required>
                            <label style="margin-top:10px;"><b>Ket Upacara : </b></label>
                            <select name="upacara" id="upacara-kematian" class="form-control">
                                <option>UPACARA</option>
                                <option>NON UPACARA</option>

                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label><b>Pukul : </b></label>
                            <input type="time" id="pukul-kematian" name="pukul" class="form-control">
                        </div>
                        <div class="form-group col-md-6">
                            <label><b>Lokasi Meninggal : </b></label>
                            <textarea name="dimana" id="dimana-kematian" class="form-control" rows="5"></textarea>
                        </div>

                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label><b>Uraian Singkat Kematian : </b></label>
                            <textarea name="penyebab" id="penyebab-kematian" class="form-control" rows="5"></textarea>
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).on('click', '#btn-edit-kematian', function() {
        $('.modal-body #id-kematian').val($(this).data('id'));
        $('.modal-body #pelapor-kematian').val($(this).data('pelapor'));
        $('.modal-body #nohp_pelapor-kematian').val($(this).data('nohp_pelapor'));
        $('.modal-body #email_pelapor-kematian').val($(this).data('email_pelapor'));
        $('.modal-body #nama-kematian').val($(this).data('nama'));
        $('.modal-body #nrp-kematian').val($(this).data('nrp'));
        $('.modal-body #pangkat-kematian').val($(this).data('pangkat'));
        $('.modal-body #jabatan-kematian').val($(this).data('jabatan'));
        $('.modal-body #kesatuan-kematian').val($(this).data('kesatuan'));
        $('.modal-body #agama-kematian').val($(this).data('agama'));
        $('.modal-body #tpt_lahir-kematian').val($(this).data('tpt_lahir'));
        $('.modal-body #tgl_lahir-kematian').val($(this).data('tgl_lahir'));
        $('.modal-body #alamat-kematian').val($(this).data('alamat'));
        $('.modal-body #anak_ke-kematian').val($(this).data('anak_ke'));
        $('.modal-body #bapak-kematian').val($(this).data('bapak'));
        $('.modal-body #ibu-kematian').val($(this).data('ibu'));
        $('.modal-body #meninggalkan-kematian').val($(this).data('meninggalkan'));
        $('.modal-body #tgl_meninggal-kematian').val($(this).data('tgl_meninggal'));
        $('.modal-body #pukul-kematian').val($(this).data('pukul'));
        $('.modal-body #dimana-kematian').val($(this).data('dimana'));
        $('.modal-body #penyebab-kematian').val($(this).data('penyebab'));
        $('.modal-body #rencana_dimakamkan-kematian').val($(this).data('rencana_dimakamkan'));
        $('.modal-body #keterangan-kematian').val($(this).data('keterangan'));
        $('.modal-body #upacara-kematian').val($(this).data('upacara'));
    });
</script>