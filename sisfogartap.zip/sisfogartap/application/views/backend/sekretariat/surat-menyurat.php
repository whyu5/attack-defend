<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>
<div class="flash-dat2a" data-flashdata2="<?= $this->session->flashdata('pesan') ?>"></div>


<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><b><?= $title ?></b></h1>
    <p class="mb-4">Anda dapat mengelola berbagai jenis file milik satuan terkait Kogartap II/Bdg untuk dapat di bagikan
        ke publik disini !</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <button type="button" data-toggle="modal" data-target="#M_Add_File" class="btn btn-outline-primary">
                <i class="fas fa-fw fa-plus"></i>
            </button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th class="table-plus datatable-nosort" width="20">NO.</th>
                            <th>AKSI</th>
                            <th>UPDATE</th>
                            <th>MILIK SATKER</th>
                            <th>JUDUL</th>
                            <th width="10">FILE</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($user as $u) {
                        ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td width="100">
                                    <button type="button" data-toggle="modal" data-target="#M_Edit_File" id="btn-edit-file" class="btn btn-primary" data-id="<?= $u->id; ?>" data-nama="<?= $u->nama; ?>" data-pdf="<?= $u->pdf; ?>" data-oleh="<?= $u->oleh; ?>">
                                        <i class="fas fa-fw fa-edit"></i>
                                    </button>
                                    <a href="delete-sur/<?= $u->id ?>/<?= $u->pdf ?>" class="btn btn-danger btn-hapus">
                                        <i class="fas fa-fw fa-trash"></i>
                                    </a>
                                </td>
                                <th width="100"><?= $u->tgl_masuk ?></th>
                                <td><?= $u->oleh ?></td>
                                <td><?= $u->nama ?></td>
                                <td><a href="<?= base_url('download-sur/' . $u->id) ?>" class="btn btn-warning">
                                        <i class="fas fa-fw fa-download"></i>
                                    </a></td>
                            </tr>

                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<div class="modal fade" id="M_Add_File" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Tambah File</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" enctype="multipart/form-data" method="post" action="<?= base_url('add-sur'); ?>">
                    <label>Nama File : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nama file" name="nama" class="form-control" required>
                    </div>
                    <label>Milik Satker : </label>
                    <div class="form-group">
                        <select class="form-control" name="oleh" required>
                            <option>PERSONEL</option>
                            <option>PROTOKOL</option>
                            <option>SEKRETARIAT</option>
                            <option>PEMAKAMAN</option>
                            <option>DENPOM</option>
                            <option>DETASEMEN</option>
                            <option>OPERASI</option>
                            <option>SATINTEL</option>
                        </select>
                    </div>
                    <label>File PDF : </label>
                    <div class="form-group">
                        <input type="file" name="pdf" class="form-control" accept="application/pdf" required>
                        <small>Gunakan file ukuran maksimal 1 Mb dan ber-ekstensi pdf. Untuk memperkecil
                            ukuran file dapat dilakukan <a href="https://www.ilovepdf.com/compress_pdf" class="badge badge-danger">di Link ini
                                !!</a></small>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>


<div class="modal fade" id="M_Edit_File" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Tambah File</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" enctype="multipart/form-data" method="post" action="<?= base_url('update-sur'); ?>">
                    <input type="hidden" name="id" id="id-file" class="form-control" readonly>
                    <input type="hidden" id="pdf-file" name="old_pdf" class="form-control" readonly>
                    <label>Nama File : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nama file" id="nama-file" name="nama" class="form-control" required>
                    </div>
                    <label>Milik Satker : </label>
                    <div class="form-group">
                        <select class="form-control" name="oleh" id="oleh-file" required>
                            <option>PERSONEL</option>
                            <option>PROTOKOL</option>
                            <option>SEKRETARIAT</option>
                            <option>PEMAKAMAN</option>
                            <option>DENPOM</option>
                            <option>DETASEMEN</option>
                            <option>OPERASI</option>
                            <option>SATINTEL</option>
                        </select>
                    </div>

                    <label>File PDF : </label>
                    <div class="form-group">
                        <input type="file" name="pdf" class="form-control" accept="application/pdf">
                        <small>Gunakan file ukuran maksimal 1 Mb dan ber-ekstensi pdf. Untuk memperkecil
                            ukuran file dapat dilakukan <a href="https://www.ilovepdf.com/compress_pdf" class="badge badge-danger">di Link ini
                                !!</a></small>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).on('click', '#btn-edit-file', function() {
        $('.modal-body #id-file').val($(this).data('id'));
        $('.modal-body #nama-file').val($(this).data('nama'));
        $('.modal-body #oleh-file').val($(this).data('oleh'));
        $('.modal-body #pdf-file').val($(this).data('pdf'));
    });
</script>