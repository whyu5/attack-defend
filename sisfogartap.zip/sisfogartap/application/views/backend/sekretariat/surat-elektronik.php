<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><b><?= $title ?></b></h1>
    <p class="mb-4">Anda dapat mengelola Surat masuk dan keluar terkait Kogartap II/Bdg disini !</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="#" class="btn btn-outline-primary" data-toggle="modal" data-target="#M_Add_Surat" type="button">
                <i class="fas fa-fw fa-plus"></i>
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th class="table-plus datatable-nosort" width="20">NO.</th>
                            <th>AKSI</th>
                            <th>WAKTU</th>
                            <th>NOMOR</th>
                            <th>PERIHAL</th>
                            <th>KATEGORI</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($user as $u) {
                        ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td>
                                    <button type="button" data-toggle="modal" data-target="#M_Edit_Surat" id="btn-edit-surel" class="btn btn-primary" data-id="<?= $u->id; ?>" data-kategori="<?= $u->kategori; ?>" data-nomor="<?= $u->nomor; ?>" data-dari="<?= $u->dari; ?>" data-tujuan="<?= $u->tujuan; ?>" data-perihal="<?= $u->perihal; ?>" data-penerima="<?= $u->penerima; ?>" data-ket="<?= $u->ket; ?>">
                                        <i class="fas fa-fw fa-edit"></i>
                                    </button>

                                    <a href="delete-el/<?= $u->id ?>" class="btn btn-danger btn-hapus">
                                        <i class="fas fa-fw fa-trash"></i>
                                    </a>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-info btn-sm"><i class="fas fa-fw fa-clock"></i> |
                                        <?= $u->waktu ?></button>
                                </td>
                                <td><?= $u->nomor ?></td>
                                <td><?= $u->perihal ?></td>
                                <td><button type="button" class="btn btn-success btn-sm"><?= $u->kategori ?></button></td>
                            </tr>

                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<div class="modal fade" id="M_Add_Surat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;"><b>Tambah Data</b></h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('add-el'); ?>">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label><b>Ditujukan ke : </b></label>
                            <input type="text" placeholder="Tujuan Surat" name="tujuan" class="form-control">
                        </div>
                        <div class="form-group col-md-6">
                            <label><b>Perihal : </b></label>
                            <input type="text" placeholder="Perihal" name="perihal" class="form-control">
                        </div>

                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label><b>Kategori : </b></label>
                            <select class="form-control" name="kategori" required>
                                <option>SURAT MASUK</option>
                                <option>SURAT KELUAR</option>
                                <option>NOTA DINAS MASUK</option>
                                <option>NOTA DINAS KELUAR</option>
                                <option>SPRIN MASUK</option>
                                <option>SPRIN KELUAR</option>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Nomor Surat : </b></label>
                            <input type="text" placeholder="SPRIN/XXX/VIII/2022" name="nomor" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Surat Dari : </b></label>
                            <input type="text" placeholder="Asal Surat" name="dari" class="form-control" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label><b>Penerima Surat : </b></label>
                            <input type="text" class="form-control" placeholder="Penerima" name="penerima" required>
                        </div>
                        <div class="form-group col-md-8">
                            <label><b>Keterangan : </b></label>
                            <div class="input-group mb-2 mr-sm-2">
                                <textarea class="form-control" name="ket" rows="4" required></textarea>
                            </div>
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="M_Edit_Surat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;"><b>Perbarui Data</b></h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="post" action="<?= base_url('update-el'); ?>">
                    <input type="hidden" name="id" id="id-surel" class="form-control">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label><b>Ditujukan ke : </b></label>
                            <input type="text" placeholder="Tujuan Surat" id="tujuan-surel" name="tujuan" class="form-control">
                        </div>
                        <div class="form-group col-md-6">
                            <label><b>Perihal : </b></label>
                            <input type="text" placeholder="Perihal" id="perihal-surel" name="perihal" class="form-control">
                        </div>

                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label><b>Kategori : </b></label>
                            <select class="form-control" name="kategori" id="kategori-surel" required>
                                <option>SURAT MASUK</option>
                                <option>SURAT KELUAR</option>
                                <option>NOTA DINAS MASUK</option>
                                <option>NOTA DINAS KELUAR</option>
                                <option>SPRIN MASUK</option>
                                <option>SPRIN KELUAR</option>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Nomor Surat : </b></label>
                            <input type="text" placeholder="SPRIN/XXX/VIII/2022" id="nomor-surel" name="nomor" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label><b>Surat Dari : </b></label>
                            <input type="text" placeholder="Asal Surat" id="dari-surel" name="dari" class="form-control" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label><b>Penerima Surat : </b></label>
                            <input type="text" class="form-control" id="penerima-surel" placeholder="Penerima" name="penerima" required>
                        </div>
                        <div class="form-group col-md-8">
                            <label><b>Keterangan : </b></label>
                            <div class="input-group mb-2 mr-sm-2">
                                <textarea class="form-control" name="ket" id="ket-surel" rows="4" required></textarea>
                            </div>
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).on('click', '#btn-edit-surel', function() {
        $('.modal-body #id-surel').val($(this).data('id'));
        $('.modal-body #kategori-surel').val($(this).data('kategori'));
        $('.modal-body #nomor-surel').val($(this).data('nomor'));
        $('.modal-body #dari-surel').val($(this).data('dari'));
        $('.modal-body #tujuan-surel').val($(this).data('tujuan'));
        $('.modal-body #perihal-surel').val($(this).data('perihal'));
        $('.modal-body #nama-surel').val($(this).data('nama'));
        $('.modal-body #ket-surel').val($(this).data('ket'));
        $('.modal-body #penerima-surel').val($(this).data('penerima'));
    });
</script>