    <!-- About Start -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-5 pb-4 pb-lg-0">
                    <img class="img-fluid w-100" src="<?= base_url('public/frontend/portal-berita/') ?>img/kasgar_sent.jpg" alt="">
                    <div class="bg-primary text-dark text-center p-4">
                        <h3 class="m-0">Kaskogartap II/Bdg</h3>
                    </div>
                </div>
                <div class="col-lg-7">
                    <h6 class="text-primary text-uppercase font-weight-bold">SEKAPUR SIRIH KOGARTAP II/BDG</h6>
                    
                    <h1 class="mb-4">Tugas dan Fungsi Kogartap II/Bdg</h1>
                    <p class="mb-4" align="justify">Kogartap II/Bandung bertugas memelihara dan menegakkan ketentuan-ketentuan pokok kemiliteran untuk meningkatkan soliditas persatuan dan kesatuan antar satuan di wilayah Garnisun Tetap II/Bandung dalam rangka membantu Pimpinan TNI.</p>
                    <div class="d-flex align-items-center pt-2">
                        <button type="button" class="btn-play" data-toggle="modal"
                            data-src="">
                            <span></span>
                        </button>
                        <h5 class="font-weight-bold m-0 ml-4">Youtube Kogartap II/Bdg</h5>
                    </div>
                </div>
            </div>
        </div>
        <!-- Video Modal -->
        <div class="modal fade" id="videoModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>        
                        <!-- 16:9 aspect ratio -->
                        <div class="embed-responsive embed-responsive-16by9">
                            <iframe class="embed-responsive-item" src="" id="video"  allowscriptaccess="always" allow="autoplay"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->


    <!-- Blog Start -->
    <div class="container py-5">
        <div class="row">
            <div class="col-lg-8">
                <!-- Blog Detail Start -->
                <div class="pb-3">
                    <div class="position-relative">
                        <img class="img-fluid w-100" src="<?= base_url('public/frontend/portal-berita/') ?>img/back.jpg" alt="">
                        <div class="position-absolute bg-primary d-flex flex-column align-items-center justify-content-center rounded-circle"
                            style="width: 60px; height: 60px; bottom: -30px; right: 30px;">
                            <small class="text-white text-uppercase">BDG</small>
                        </div>
                    </div>
                    <div class="bg-secondary mb-3" style="padding: 30px;">
                        <h4 class="font-weight-bold mb-3">Komando Garnisun Tetap II Bandung</h4>
                        <p align="justify">Komando Garnisun Tetap II/Bandung atau (Kogartap II/Bandung) adalah salah satu satuan dibawah Mabes TNI, mempunyai tugas pokok sebagai penegak hukum, tata tertib, dan disiplin prajurit TNI (TNI Angkatan Darat, TNI Angkatan Laut, TNI Angkatan Udara) di wilayah Provinsi Jawa Barat. Mako Kogartap II/Bandung berada di Jl. Nias Bandung, Bandung, Jawa Barat, Indonesia.</p>
                        <h5 class="mb-3">Tugas pokok dan fungsi Kogartap II/Bdg</h5>
                        <p align="justify">Kogartap II/Bandung bertugas memelihara dan menegakkan ketentuan-ketentuan pokok kemiliteran untuk meningkatkan soliditas persatuan dan kesatuan antar satuan di wilayah Garnisun Tetap II/Bandung dalam rangka membantu Pimpinan TNI. Secara kewilayahan, ruang lingkup tugas Kogar Tap II/Bandung, meliputi Subgar 2, yaitu Subgar 0618/BS (Kota Bandung dan Kabupaten Bandung), Subgar 0609/Cimahi (Kota Cimahi).</p>
                        <h4 class="mb-3">Sejarah Kogartap II/Bdg</h4>
                        <img class="img-fluid w-50 float-left mr-4 mb-2" src="<?= base_url('public/frontend/portal-berita/') ?>img/back2.jpg">
                        <p align="justify">Awal mula berdirinya Komando Garnisun Bandung & Cimahi, hal tersebut tidak lepas dari peristiwa 19 Agustus 1966. Pada waktu itu Kota Bandung dilanda kerusuhan dan demonstrasi akibat terjadinya ketegangan-ketegangan politik Orde Lama beserta kaki tangan sisa-sisa G.30.S/PKI yang menentang Orde Baru pimpinan Jenderal Suharto selaku pengemban SUPER SEMAR pada saat itu.
                            
                        Pada waktu itu demonstrasi dan kerusuhan tidak dapat diselesaikan dengan segera, karena tidak adanya kesatuan Komando (belum terbentuknya KOGAP), walaupun kesatuan masing-masing berusaha memadamkan demonstrasi, hasilnya kurang memuaskan karena itulah dianggap perlu dibentuk suatu KOMANDO dengan wilayah Bandung-Cimahi. <br>
                        
                        Tiga hari setelah terjadinya peristiwa 19 Agustus 1966 yaitu pada tanggal 22 Agustus 1966, dibentuklah Komando Satuan SADAGORI berdasarkan Surat Telegram Pangdam VI/Siliwangi Nomor ST/1093-3/1966 yang anggotanya terdiri dari unsur ABRI yang ada di wilayah Bandung-Cimahi. Komandan Satgas Sadagori yang ditunjuk oleh Pangdam VI/Siliwangi pada waktu itu adalah Letkol Inf Himawan Soetanto.<br>
                        
                        Dengan mengambil manfaat atas pengalaman serta peristiwa-peristiwa yang terjadi pada waktu itu, maka dalam perkembanagan selanjutnya terbentuklah cikal bakal berdirinya Komando Garnisun Bandung & Cimahi berdasarkan Surat Keputusan Pangdam VI/Siliwangi No. Kep/181-2/6/1968 tanggal 3 Juni 1968 beserta pelaksanaanya dalam Surat Perintah Pangdam VI/Siliwangi No. Sprin/195-3/6/1968 tanggal 4 Juni 1968 yang diresmikan dalam suatu upacara bertempat di halaman Kodim 0618 dengan Inspektur Upacara Panglima Daerah Militer VI/Siliwangi pada waktu itu Mayor Jenderal TNI HR. Dharsono.</p>
                        <h5 class="mb-3">Subkogartap II/Bdg</h5>
                        <p align="justify">Guna membantu tugas pokok Kogartap II/Bdg dibentuklah, subgar yang memiliki fungsi untuk sebagai perwakilan Kogartap II/Bdg sesuai dengan jangkauan wilayahnya</p>
                        <ul>
                            <li>Subkogartap 0614/Crb</li>
                            <li>Subkogartap 0606/Bgr</li>
                            <li>Subkogartap 0612/Tsm</li>
                            <li>Subkogartap 0623/Clg</li>
                            <li>Subkogartap 0618/Bdg</li>
                            <li>Subkogartap 0609/Cmi</li>
                        </ul>
                        
                    </div>
                </div>
            </div>

            <!-- Sidebar Start -->
            <div class="col-lg-4 mt-5 mt-lg-0">
                <!-- Search Form Start -->
                <div class="mb-5">
                    <div class="bg-secondary" style="padding: 30px;">
                        <div class="input-group">
                            <input type="text" class="form-control border-0 p-4" placeholder="Keyword">
                            <div class="input-group-append">
                                <span class="input-group-text bg-primary border-primary text-white"><i
                                        class="fa fa-search"></i></span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Search Form End -->

                <!-- Category Start -->
                <div class="mb-5">
                    <h3 class="mb-4"><center>Kepala Staff</center></h3>
                    <div class="bg-secondary" style="padding: 30px;">
                        <ul class="list-inline m-0">
                            <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                <a class="text-dark" href="#">Marsma TNI Drs. D.A. Tambunan, S.H., M.H.</a>
                            </li>
                            <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                <a class="text-dark" href="#">Marsma TNI Budiyono</a>
                            </li>
                            <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                <a class="text-dark" href="#">Marsma TNI Wahyudin Karnadinata</a>
                            </li>
                            <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                <a class="text-dark" href="#">Marsma TNI Iman Sudrajat</a>
                            </li>
                            <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                <a class="text-dark" href="#">Marsma TNI Imron Nasution</a>
                            </li>
                            <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                <a class="text-dark" href="#">Marsma TNI Suparmono</a>
                            </li>
                            <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                <a class="text-dark" href="#">Marsma TNI Sun Sudharta</a>
                            </li>
                            <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                <a class="text-dark" href="#">Marsma TNI Taspin Hasan</a>
                            </li>
                            <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                <a class="text-dark" href="#">Marsma TNI Embu Agapitus</a>
                            </li>
                            <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                <a class="text-dark" href="#">Marsma TNI Lintong Siregar</a>
                            </li>
                            <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                <a class="text-dark" href="#">Marsma TNI Budi Sumarsono</a>
                            </li>
                            <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                <a class="text-dark" href="#">Marsma TNI Sentot Adhi Kurnianto, S.H.,M.H.</a>
                            </li>

                        </ul>
                    </div>
                </div>
                <!-- Category End -->
                <!-- Image Start -->
                <div class="mb-5">
                    <img src="<?= base_url('public/frontend/portal-berita/') ?>img/kasgar.jpg" alt="" class="img-fluid">
                </div>
                <!-- Image End -->
                
                <div>
                    
                    <div class="bg-secondary text-center" style="padding: 30px;">
                    <h3 class="mb-4"><center>Quotes</center></h3>
                        <p><i>"Kembangkan sikap untuk selalu menjadi lebih baik. Membuat perbedaan yang kecil dalam tindakan akan menghasilkan perbedaan yang besar dalam hasil yang diperoleh"</i></p>
                        <a href="" class="btn btn-primary py-2 px-3">Marsekal Pertama TNI<br>Sentot Adhi Kurnianto, S.H., M.H.</a>
                    </div>
                </div>
                <!-- Plain Text End -->
            </div>
            <!-- Sidebar End -->
        </div>
    </div>
    <!-- Blog End -->