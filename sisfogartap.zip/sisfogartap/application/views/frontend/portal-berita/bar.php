
    <!-- Topbar Start -->
    <div class="container-fluid bg-dark">
        <div class="row py-2 px-lg-5">
            <div class="col-lg-6 text-center text-lg-left mb-2 mb-lg-0">
                <div class="d-inline-flex align-items-center text-white">
                    <small><i class="fa fa-phone-alt mr-2"></i>420-3011</small>
                    <small class="px-3">|</small>
                    <small><i class="fa fa-envelope mr-2"></i>gartap2@contoh.com</small>
                </div>
            </div>
            <div class="col-lg-6 text-center text-lg-right">
                <div class="d-inline-flex align-items-center">
                    <a class="text-white px-2" href="">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a class="text-white px-2" href="https://www.instagram.com/kogartap_2_bdg_official/">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a class="text-white pl-2" href="">
                        <i class="fab fa-youtube"></i>
                    </a>
                    
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid p-0">
        <nav class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-lg-5">
            <a href="<?= base_url('home') ?>" class="navbar-brand ml-lg-3">
                <img src="<?= base_url('public/backend/') ?>mabes.png" alt="Logo Mabes TNI" width="70px">
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
            
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between px-lg-3" id="navbarCollapse">
                <div class="navbar-nav m-auto py-0">
                    <a href="<?= base_url('home') ?>" class="nav-item nav-link <?php if ($title == 'Home') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?>">Beranda</a>
                    <a href="<?= base_url('profile') ?>" class="nav-item nav-link <?php if ($title == 'Profil Satuan') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?> ">Profil</a>
                    <a href="<?= base_url('struktur') ?>" class="nav-item nav-link <?php if ($title == 'Struktur Organisasi') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?> ">Struktur</a>
                    <a href="<?= base_url('berita-news') ?>" class="nav-item nav-link <?php if ($title == 'Portal Berita') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?> ">Berita</a>
                    <a href="<?= base_url('survey-kepuasan') ?>" class="nav-item nav-link <?php if ($title == 'Survey Kepuasan') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?> ">Survey</a>
                    
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Satker</a>
                        <div class="dropdown-menu rounded-0 m-0">
                            <a href="<?= base_url('protokol') ?>" class="dropdown-item">Protokol</a>
                            <a href="<?= base_url('denpomgar') ?>" class="dropdown-item">Denpom</a>
                            <a href="<?= base_url('satintel') ?>" class="dropdown-item">Satintel</a>
                            <a href="<?= base_url('denma') ?>" class="dropdown-item">Detasemen Markas</a>
                            <a href="<?= base_url('rengar') ?>" class="dropdown-item">Rengar</a>
                            <a href="<?= base_url('penerangan') ?>" class="dropdown-item">Penerangan</a>
                            <a href="<?= base_url('pemakaman') ?>" class="dropdown-item">Pemakaman</a>
                        </div>
                    </div>
                    <a href="<?= base_url('contact') ?>" class="nav-item nav-link  <?php if ($title == 'Kontak') {
                                    echo "active";
                                } else {
                                    echo "";
                                }; ?>">Kontak</a>
                </div>
                <a href="" class="btn btn-primary py-2 px-4 d-none d-lg-block">E - M A K</a>
            </div>
        </nav>
    </div>
    <!-- Navbar End -->
