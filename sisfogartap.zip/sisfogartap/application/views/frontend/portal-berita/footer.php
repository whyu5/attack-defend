<!-- Footer Start -->
<div class="container-fluid bg-dark text-white mt-5 py-5 px-sm-3 px-md-5">
        <div class="row pt-5">
            <div class="col-lg-5 col-md-6">
                <div class="row">
                    <div class="col-md-6 mb-5">
                        <h3 class="text-primary mb-4">Lokasi</h3>
                        <p><i class="fa fa-map-marker-alt mr-2"></i>Jl. Nias No.3. Kota Bandung</p>
                        <p><i class="fa fa-phone-alt mr-2"></i>420-3011</p>
                        <p><i class="fa fa-envelope mr-2"></i>info@example.com</p>
                        <div class="d-flex justify-content-start mt-4">
                            <a class="btn btn-outline-light btn-social mr-2" href="#"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-outline-light btn-social mr-2" href="https://www.instagram.com/kogartap_2_bdg_official/"><i class="fab fa-instagram"></i></a>
                            <a class="btn btn-outline-light btn-social mr-2" href="#"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>
                    <div class="col-md-6 mb-5">
                        <h3 class="text-primary mb-4">Tautan</h3>
                        <div class="d-flex flex-column justify-content-start">
                            <a class="text-white mb-2" href="<?= base_url('profile')?>"><i class="fa fa-angle-right mr-2"></i>Profil</a>
                            <a class="text-white mb-2" href="<?= base_url('struktur')?>"><i class="fa fa-angle-right mr-2"></i>Struktur</a>
                            <a class="text-white mb-2" href="<?= base_url('berita-news')?>"><i class="fa fa-angle-right mr-2"></i>Berita</a>
                            <a class="text-white mb-2" href="<?= base_url('survey-kepuasan')?>"><i class="fa fa-angle-right mr-2"></i>Survey Kepuasan</a>
                            <a class="text-white" href="<?= base_url('contact')?>"><i class="fa fa-angle-right mr-2"></i>Kontak ( UP3M )</a>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-7 col-md-6 mb-5">
                <h3 class="text-primary mb-4">Kogartap II/Bdg</h3>
                <p>Kogartap II/Bandung bertugas memelihara dan menegakkan ketentuan-ketentuan pokok kemiliteran untuk meningkatkan soliditas persatuan dan kesatuan antar satuan di wilayah Garnisun Tetap II/Bandung dalam rangka membantu Pimpinan TNI.</p>
                <div class="w-100">
                    <div class="input-group">
                        <input type="text" class="form-control border-light" style="padding: 30px;" placeholder="Your Email Address">
                        <div class="input-group-append">
                            <button class="btn btn-primary px-4">Follow</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid bg-dark text-white border-top py-4 px-sm-3 px-md-5" style="border-color: #3E3E4E !important;">
        <div class="row">
            <div class="col-lg-6 text-center text-md-left mb-3 mb-md-0">
                <p class="m-0 text-white">&copy; <a href="#">Kogartap II/Bdg</a>. All Rights Reserved CPNS-2022 </a>
                <br>Supported By: <a href="https://tni.mil.id" target="_blank">Tentara Nasional Indonesia</a>
                </p>
            </div>
            <div class="col-lg-6 text-center text-md-right">
                <ul class="nav d-inline-flex">
                    <li class="nav-item">
                        <a class="nav-link text-white py-0" href="https://www.lapor.go.id/">SP4N</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white py-0" href="#">Protokoler</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white py-0" href="#">Polisi Militer</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white py-0" href="#">Satintel</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white py-0" href="#">Pemakaman</a>
                    </li>
                    
                </ul>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url('public/frontend/portal-berita/') ?>lib/easing/easing.min.js"></script>
    <script src="<?= base_url('public/frontend/portal-berita/') ?>lib/waypoints/waypoints.min.js"></script>
    <script src="<?= base_url('public/frontend/portal-berita/') ?>lib/counterup/counterup.min.js"></script>
    <script src="<?= base_url('public/frontend/portal-berita/') ?>lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="<?= base_url('public/frontend/portal-berita/') ?>mail/jqBootstrapValidation.min.js"></script>
    <script src="<?= base_url('public/frontend/portal-berita/') ?>mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="<?= base_url('public/frontend/portal-berita/') ?>js/main.js"></script>

    <script src="<?= base_url('public/backend/'); ?>sweetalert2/package/dist/sweetalert2.all.js"></script>
    <script type="text/javascript">
    const dataflash = $('.flash-data').data('flashdata');
    if (dataflash) {
        Swal.fire({
            title: 'Terima kasih !',
            text: 'Sisfogartap menyatakan ' + dataflash,
            confirmButtonColor: '#e84118',
            icon: 'success'
        });
    };
    </script>
    </body>

    </html>