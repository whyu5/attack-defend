<!-- Blog Start -->
<div class="container-fluid pt-5">
        <div class="container">
            <div class="row">
                <?php 
                foreach ($news as $n) { ?>
                <div class=" col-md-4 mb-5">
                    <div class="position-relative">
                        <img class="img-fluid w-100" src="<?= base_url('public/uploads/homepage/berita/') ?><?= $n->gambar;?>" alt="">
                        <div class="position-absolute bg-primary d-flex flex-column align-items-center justify-content-center rounded-circle"
                            style="width: 60px; height: 60px; bottom: -30px; right: 30px;">
                            <h5 class="font-weight-bold mb-n1"><?= substr($n->waktu,0,2);?></h5>
                            <small class="text-white text-uppercase">
                            <?php 
                            $ub = substr($n->waktu,3,2);
                            if ($ub == '12') { echo 'DES'; } else 
                            if ($ub == '11') { echo 'NOV'; } else
                            if ($ub == '10') { echo 'OKT'; } else
                            if ($ub == '09') { echo 'SEP'; } else
                            if ($ub == '08') { echo 'AGS'; } else
                            if ($ub == '07') { echo 'JUL'; } else
                            if ($ub == '06') { echo 'JUN'; } else
                            if ($ub == '05') { echo 'MEI'; } else
                            if ($ub == '04') { echo 'APR'; } else
                            if ($ub == '03') { echo 'MAR'; } else
                            if ($ub == '02') { echo 'FEB'; } else
                            if ($ub == '01') { echo 'JAN'; }
                            ?>
                                
                            </small>
                        </div>
                    </div>
                    <div class="bg-secondary" style="padding: 30px;">
                        <div class="d-flex mb-3">
                            <div class="d-flex align-items-center">
                                <img class="rounded-circle" style="width: 40px; height: 40px;" src="<?= base_url('public/frontend/portal-berita/') ?>img/user.svg" alt="">
                                <small class="text-muted ml-2" href="">Admin</small>
                            </div>
                            <div class="d-flex align-items-center ml-4">
                                <i class="far fa-bookmark text-primary"></i>
                                <small class="text-muted ml-2" href=""><?= ucwords(strtolower($n->kategori));?></small>
                            </div>
                        </div>
                        <a href="<?= base_url('single-page/') ?><?= $n->id;?>"><h6 class="font-weight-bold mb-3"><?= ucwords(strtolower($n->judul));?></h6></a>
                        <small align="justify"><?= ucfirst(strtolower($n->quotes));?><br><a class="border-bottom border-primary text-decoration-none" href="<?= base_url('single-page/') ?><?= $n->id;?>">SELENGKAPNYA<i class="fa fa-angle-right"></i></a></small>
                        
                    </div>
                </div>
                <?php } ?>


            </div>
        </div>
    </div>
    <!-- Blog End -->