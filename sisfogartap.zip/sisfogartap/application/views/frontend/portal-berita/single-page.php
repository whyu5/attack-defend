<!-- Blog Start -->
<div class="container py-5">
        <div class="row">
            <div class="col-lg-8">
                <!-- Blog Detail Start -->
                <?php 
                foreach ($user as $n) { ?>
                <div class="pb-3">
                    <div class="position-relative">
                        <img class="img-fluid w-100" src="<?= base_url('public/uploads/homepage/berita/') ?><?= $n->gambar;?>" alt="">
                        <div class="position-absolute bg-primary d-flex flex-column align-items-center justify-content-center rounded-circle"
                            style="width: 60px; height: 60px; bottom: -30px; right: 30px;">
                            <h4 class="font-weight-bold mb-n1"><?= substr($n->waktu,0,2);?></h4>
                            <small class="text-white text-uppercase">
                            <?php 
                            $ub = substr($n->waktu,3,2);
                            if ($ub == '12') { echo 'DES'; } else 
                            if ($ub == '11') { echo 'NOV'; } else
                            if ($ub == '10') { echo 'OKT'; } else
                            if ($ub == '09') { echo 'SEP'; } else
                            if ($ub == '08') { echo 'AGS'; } else
                            if ($ub == '07') { echo 'JUL'; } else
                            if ($ub == '06') { echo 'JUN'; } else
                            if ($ub == '05') { echo 'MEI'; } else
                            if ($ub == '04') { echo 'APR'; } else
                            if ($ub == '03') { echo 'MAR'; } else
                            if ($ub == '02') { echo 'FEB'; } else
                            if ($ub == '01') { echo 'JAN'; }
                            ?>
                            </small>
                        </div>
                    </div>
                    <div class="bg-secondary mb-3" style="padding: 30px;">
                        <div class="d-flex mb-3">
                            <div class="d-flex align-items-center">
                                <img class="rounded-circle" style="width: 40px; height: 40px;" src="<?= base_url('public/frontend/portal-berita/') ?>img/user.svg" alt="">
                                <a class="text-muted ml-2" href="">Administrator</a>
                            </div>
                            <div class="d-flex align-items-center ml-4">
                                <i class="far fa-bookmark text-primary"></i>
                                <a class="text-muted ml-2" href=""><?= ucwords(strtolower($n->kategori));?></a>
                            </div>
                        </div>
                        <h4 class="font-weight-bold mb-3"><?= ucwords(strtolower($n->judul));?></h4>
                        <p class="mb-3"><?= $n->isi?></p>
                        <h5 >"<?= ucfirst(strtolower($n->quotes));?>"</h5> <br>
                        <p>Tanggal Tayang : <?= $n->waktu?></p>
                    </div>
                </div>
                <?php }?>
                <!-- Blog Detail End -->
            </div>

            <!-- Sidebar Start -->
            <div class="col-lg-4 mt-5 mt-lg-0">
                <!-- Search Form Start -->
                <div class="mb-5">
                    <div class="bg-secondary" style="padding: 30px;">
                        <div class="input-group">
                            <input type="text" class="form-control border-0 p-4" placeholder="Keyword">
                            <div class="input-group-append">
                                <span class="input-group-text bg-primary border-primary text-white"><i
                                        class="fa fa-search"></i></span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Search Form End -->

                <!-- Recent Post Start -->
                <div class="mb-5">
                    <h3 class="mb-4">Berita Terkini</h3>
                    <?php 
                    foreach ($news as $ff) { ?>
                    <div class="d-flex mb-3">
                        <img class="img-fluid" src="<?= base_url('public/uploads/homepage/berita/') ?><?= $ff->gambar;?>" style="width: 80px; height: 80px; object-fit: cover;" alt="">
                        <a href="<?= base_url('single-page/'. $ff->id)?>" class="d-flex align-items-center bg-secondary text-dark text-decoration-none px-3" style="height: 80px;">
                        <?= ucwords(strtolower($ff->judul));?>
                        </a>
                    </div>
                    <?php }?>
                </div>
                
            </div>
            <!-- Sidebar End -->
        </div>
    </div>
    <!-- Blog End -->