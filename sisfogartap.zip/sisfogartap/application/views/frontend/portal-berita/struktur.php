<!-- Blog Start -->
<div class="container-fluid pt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-10 mb-5">
                    <div class="position-relative">
                        <img class="img-fluid w-100" src="<?= base_url('public/frontend/portal-berita/img/') ?>struktur.PNG" alt="">
                    </div>                    
                </div>

            </div>
        </div>
    </div>
    <!-- Blog End -->