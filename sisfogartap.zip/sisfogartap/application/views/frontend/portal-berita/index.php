

    <!-- Header Start -->
    <div class="jumbotron jumbotron-fluid mb-5">
        <div class="container text-center py-5">
            <h1 class="text-primary mb-1">Zona Integritas</h1>
            <h1 class="text-white display-3 mb-3">Kogartap II/Bdg</h1>
            <p class="text-white mb-5">Satuan dibawah Mabes TNI, mempunyai tugas pokok sebagai penegak hukum, tata tertib, dan disiplin prajurit TNI <br>(TNI Angkatan Darat, TNI Angkatan Laut, TNI Angkatan Udara) di wilayah Provinsi Jawa Barat.</p>
            <a href="<?= base_url('berita-news')?>" class="btn btn-lg btn-primary">BERITA TERKINI</a>
        </div>
        
    </div>
    <!-- Header End -->


    

    


    