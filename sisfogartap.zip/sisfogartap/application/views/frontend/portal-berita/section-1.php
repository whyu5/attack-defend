    <!-- About Start -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-5 pb-4 pb-lg-0">
                    <img class="img-fluid w-100" src="<?= base_url('public/frontend/portal-berita/') ?>img/laksmana.jpg" alt="">
                    <div class="bg-primary text-dark text-center p-4">
                        <h3 class="m-0">Panglima TNI</h3>
                    </div>
                </div>
                <div class="col-lg-7">
                    <h6 class="text-primary text-uppercase font-weight-bold">Perintah Harian</h6>
                    <h1 class="mb-4">Panglima TNI</h1>
                    <p class="mb-4">
                        <ol align="justify">
                            <li>Pengabdian tulus,ikhlas dilandasi keimanan dan ketakwaan kepada Tuhan TME, teguh berpedoman pancasila, UUD 1945. Sapta Marga, Sumpah Prajurit dan 8 Wajib TNI</li>
                            <li>Tingkatkan sumber daya prajurti TNI agar menjadi prajurit profesional, tangguh, bermoral, berdedikasi dan mempunyai loyalitas tinggi serta bermental Sapta Marga</li>
                            <li>Pertajam naluri tempur dan kemampuan dalam melaksanakan tugas operasi gabungan guna memperkokoh soliditas antar satuan TNI, perkuat sinergitas TNI/POLRI serta elemen pemerintah/lembaga lain</li>
                            <li>TNI harus menjadi pengayom dan membantu kesulitan rakyat, guna memberikan rasa aman dari segala bentuk ancaman</li>
                            <li>Wujudkan Reformasi Birokrasi Dilingkungan dan kultur organisasi TNI</li>
                            <li>Tanamkan nilai nilai keprajuritan serta menjunjung tinggi Sapta Marga, Sumpah Prajurit, 8 Wajib TNI dan selalu menjaga netralitas TNI</li>
                            <li>Stop aksi arogansi prajurit TNI, tegas namun tetap humanis dan disegani</li>
                        </ol>
                    </p>
                    <div class="d-flex align-items-center pt-2">
                        <h5 class="font-weight-bold">Laksamana TNI Yudo Margono, S.E., M.M.</h5>
                    </div>
                </div>
            </div>
        </div>
        <!-- Video Modal -->
        <div class="modal fade" id="videoModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>        
                        <!-- 16:9 aspect ratio -->
                        <div class="embed-responsive embed-responsive-16by9">
                            <iframe class="embed-responsive-item" src="" id="video"  allowscriptaccess="always" allow="autoplay"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->


    <!--  Quote Request Start -->
    <div class="container-fluid bg-secondary my-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-7 py-5 py-lg-0">
                    <h6 class="text-primary text-uppercase font-weight-bold">SEKAPUR SIRIH KOGARTAP II/BDG</h6>
                    <h1 class="mb-4">Tugas dan Fungsi Garnisun</h1>
                    <p class="mb-4" align="justify">Kogartap II/Bandung bertugas memelihara dan menegakkan ketentuan-ketentuan pokok kemiliteran untuk meningkatkan soliditas persatuan dan kesatuan antar satuan di wilayah Komando Garnisun Tetap II/Bandung dalam rangka membantu Pimpinan TNI. <br> <br> Selain itu, Komando Garnisun Tetap II/ Bandung memiliki tugas sebagai protokoler kenegaraan dan kemiliteran, fungsi pemakaman dan fungsi polisi militer serta fungsi intelijen</p>
                    <div class="row">
                        <div class="col-sm-4">
                            <h1 class="text-primary">Berani</h1>
                            <h6 class="font-weigh">Melaksanakan tugas</h6>
                        </div>
                        <div class="col-sm-4">
                            <h1 class="text-primary">Benar</h1>
                            <h6 class="font-weight">Menyampaikan amanah</h6>
                        </div>
                        <div class="col-sm-4">
                            <h1 class="text-primary">Jujur</h1>
                            <h6 class="font-weight">Menjalankan perintah</h6>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <!-- <div class="bg-primary py-1 px-1 px-sm-1"> -->
                    <img class="img-fluid w-100" src="<?= base_url('public/frontend/portal-berita/') ?>img/kasgar_sent.jpg" alt="">
                    <div class="bg-primary text-dark text-center p-4">
                        <h3 class="m-0">Kaskogartap II/Bdg</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Quote Request Start -->


    <!-- Services Start -->
    <div class="container-fluid pt-5">
        <div class="container">
            <div class="text-center pb-2">
                <h6 class="text-primary text-uppercase font-weight-bold">Tugas dan Fungsi</h6>
                <h1 class="mb-4">4 Fungsi Garnisun</h1>
            </div>
            <div class="row pb-3">
                <div class="col-lg-3 col-md-6 text-center mb-5">
                    <div class="d-flex align-items-center justify-content-center bg-primary mb-4 p-4">
                        <i class="fa fa-2x fa-user-tie text-dark pr-3"></i>
                        <h6 class="text-white font-weight-medium m-0">Protokoler</h6>
                    </div>
                    <p>Penyelenggaraan fungsi protokoler adalah upaya pemeliharaan dan pembinaan peraturan yang berhubungan dengan upacara militer maupun kenegaraan.</p>
                    <a class="border-bottom text-decoration-none" href="">Read More</a>
                </div>
                <div class="col-lg-3 col-md-6 text-center mb-5">
                    <div class="d-flex align-items-center justify-content-center bg-primary mb-4 p-4">
                        <i class="fa fa-2x fa-hospital text-dark pr-3"></i>
                        <h6 class="text-white font-weight-medium m-0">Pemakaman</h6>
                    </div>
                    <p>Penyelenggaraan fungsi pemakaman adalah upaya untuk melaksanakan, mengkoordinasikan dan mengatur segala kebutuhan dan tindakan terkait dengan pemakaman prajurit.</p>
                    <a class="border-bottom text-decoration-none" href="">Read More</a>
                </div>
                <div class="col-lg-3 col-md-6 text-center mb-5">
                    <div class="d-flex align-items-center justify-content-center bg-primary mb-4 p-4">
                        <i class="fa fa-2x fa-user-shield text-dark pr-3"></i>
                        <h6 class="text-white font-weight-medium m-0">Polisi Militer</h6>
                    </div>
                    <p>Penyelenggaraan fungsi polisi militer adalah upaya untuk melaksanakan, menegakkan segala bentuk disiplin peraturan-peraturan yang ada di Lingkungan TNI.</p>
                    <a class="border-bottom text-decoration-none" href="">Read More</a>
                </div>
                <div class="col-lg-3 col-md-6 text-center mb-5">
                    <div class="d-flex align-items-center justify-content-center bg-primary mb-4 p-4">
                        <i class="fa fa-2x fa-user-secret text-dark pr-3"></i>
                        <h6 class="text-white font-weight-medium m-0">Intelijen</h6>
                    </div>
                    <p>Penyelenggaraan fungsi intelijen adalah upaya untuk menyelidiki, mengkoordinasi serta mengawasi semua kegiatan dilingkup satuan maupun luar satuan sesuai dengan wilayahnya.</p>
                    <a class="border-bottom text-decoration-none" href="">Read More</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Services End -->
