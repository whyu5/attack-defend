
    <!-- Team Start -->
    <div class="container-fluid pt-5">
        <div class="container">
            <div class="text-center pb-2">
                <h6 class="text-primary text-uppercase font-weight-bold">PEJABAT KOGARTAP II/BDG</h6>
                <h1 class="mb-4">Unsur Pimpinan</h1>
            </div>
            <div class="row">
                <?php
                $no = 1;
                foreach ($pimpinan as $pmp) {
                ?>
                <div class="col-lg-4 col-md-6">
                    <div class="team card position-relative overflow-hidden border-0 mb-5">
                        <img class="card-img-top" src="<?= base_url('public/uploads/homepage/pimpinan/') ?><?= $pmp->gambar; ?>" alt="">
                        <div class="card-body text-center p-0">
                            <div class="team-text d-flex flex-column justify-content-center bg-secondary">
                                <h5 class="font-weight-bold"><?= $pmp->nama ?></h5>
                                <span><?= strtoupper($pmp->jabatan) ?></span>
                            </div>
                            <div class="team-social d-flex align-items-center justify-content-center bg-primary">
                                <a class="btn btn-outline-dark btn-social mr-2" href="<?= $pmp->ig; ?>"><i class="fab fa-instagram"></i></a>
                                <a class="btn btn-outline-dark btn-social mr-2" href="<?= $pmp->fb; ?>"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-outline-dark btn-social mr-2" href="<?= $pmp->yt; ?>"><i class="fab fa-youtube"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?>

            </div>
        </div>
    </div>
    <!-- Team End -->


    <!-- Testimonial Start -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="text-center pb-2">
                <h6 class="text-primary text-uppercase font-weight-bold">INDEKS KEPUASAN MASYARAKAT</h6>
                <h1 class="mb-4">Terhadap Kogartap II/Bdg</h1>
            </div>
            <div class="owl-carousel testimonial-carousel">
                <div class="position-relative bg-secondary p-4">
                    <i class="fa fa-3x fa-quote-right text-primary position-absolute" style="top: -6px; right: 0;"></i>
                    <div class="d-flex align-items-center mb-3">
                        <img class="img-fluid rounded-circle" src="<?= base_url('public/frontend/portal-berita/') ?>img/user.svg" style="width: 60px; height: 60px;" alt="">
                        <div class="ml-3">
                            <h6 class="font-weight-semi-bold m-0">Muhammad Badaruddin</h6>
                            <small>- Penerima Bantuan Watzah</small>
                        </div>
                    </div>
                    <p class="m-0">Pelayanan profesional, tidak meminta imbalan, namun kita merasakan kemanusiaan yang sangat menonjol</p>
                </div>
                <div class="position-relative bg-secondary p-4">
                    <i class="fa fa-3x fa-quote-right text-primary position-absolute" style="top: -6px; right: 0;"></i>
                    <div class="d-flex align-items-center mb-3">
                        <img class="img-fluid rounded-circle" src="<?= base_url('public/frontend/portal-berita/') ?>img/user.svg" style="width: 60px; height: 60px;" alt="">
                        <div class="ml-3">
                            <h6 class="font-weight-semi-bold m-0">Hendra Wijaya</h6>
                            <small>- Penerima Bantuan Watzah</small>
                        </div>
                    </div>
                    <p class="m-0">Pelayanan yang diberikan sangat baik, kita berikan masukan-masukan tentang pemakaman keluarga kami yang meninggal</p>
                </div>
                <div class="position-relative bg-secondary p-4">
                    <i class="fa fa-3x fa-quote-right text-primary position-absolute" style="top: -6px; right: 0;"></i>
                    <div class="d-flex align-items-center mb-3">
                        <img class="img-fluid rounded-circle" src="<?= base_url('public/frontend/portal-berita/') ?>img/user.svg" style="width: 60px; height: 60px;" alt="">
                        <div class="ml-3">
                            <h6 class="font-weight-semi-bold m-0">Dody Daryanto</h6>
                            <small>- Penerima Bantuan Watzah</small>
                        </div>
                    </div>
                    <p class="m-0">Pelayanan yang diberikan sangat baik, bravo TNI indonesia, semoga jaya selalu, dan terus mengabdi kepada negara Indonesia</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Testimonial End -->


    <!-- Blog Start -->
    <div class="container-fluid pt-5">
        <div class="container">
            <div class="text-center pb-2">
                <h6 class="text-primary text-uppercase font-weight-bold">Terbaru</h6>
                <h1 class="mb-4">Berita Terkini</h1>
            </div>
            <div class="row">
                <?php 
                foreach ($news as $n) { ?>
                <div class="col-md-6 mb-5">
                    <div class="position-relative">
                        <img class="img-fluid w-100" src="<?= base_url('public/uploads/homepage/berita/') ?><?= $n->gambar;?>" alt="">
                        <div class="position-absolute bg-primary d-flex flex-column align-items-center justify-content-center rounded-circle"
                            style="width: 60px; height: 60px; bottom: -30px; right: 30px;">
                            <h4 class="font-weight-bold mb-n1"><?= substr($n->waktu,0,2);?></h4>
                            <small class="text-white text-uppercase">
                            <?php 
                            $ub = substr($n->waktu,3,2);
                            if ($ub == '12') { echo 'DES'; } else 
                            if ($ub == '11') { echo 'NOV'; } else
                            if ($ub == '10') { echo 'OKT'; } else
                            if ($ub == '09') { echo 'SEP'; } else
                            if ($ub == '08') { echo 'AGS'; } else
                            if ($ub == '07') { echo 'JUL'; } else
                            if ($ub == '06') { echo 'JUN'; } else
                            if ($ub == '05') { echo 'MEI'; } else
                            if ($ub == '04') { echo 'APR'; } else
                            if ($ub == '03') { echo 'MAR'; } else
                            if ($ub == '02') { echo 'FEB'; } else
                            if ($ub == '01') { echo 'JAN'; }
                            ?>
                                
                            </small>
                        </div>
                    </div>
                    <div class="bg-secondary" style="padding: 30px;">
                        <div class="d-flex mb-3">
                            <div class="d-flex align-items-center">
                                <img class="img-fluid" style="width: 40px; height: 40px;" src="<?= base_url('public/frontend/portal-berita/') ?>img/user.svg" alt="">
                                <a class="text-muted ml-2" href="">Administrator</a>
                            </div>
                            <div class="d-flex align-items-center ml-4">
                                <i class="far fa-bookmark text-primary"></i>
                                <a class="text-muted ml-2" href=""><?= ucwords(strtolower($n->kategori));?></a>
                            </div>
                        </div>
                        <a href="<?= base_url('single-page/') ?><?= $n->id;?>"><h4 class="font-weight-bold mb-3"><?= ucwords(strtolower($n->judul));?></h4></a>
                        <p align="justify"><?= ucfirst(strtolower($n->quotes));?></p>
                        <a class="border-bottom border-primary text-uppercase text-decoration-none" href="<?= base_url('single-page/') ?><?= $n->id;?>">Selengkapnya <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
                <?php } ?>


            </div>
        </div>
    </div>
    <!-- Blog End -->