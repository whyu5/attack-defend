    <!-- Contact Start -->
    <div class="container-fluid py-7">
        
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <center><h6 class="text-primary text-uppercase font-weight-bold">Survey kepuasan masyarakat</h6>
                    <h1 class="mb-4">Beri kami saran !</h1></center>
                    <div class="contact-form bg-secondary" style="padding: 30px;">
                    <div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>
                        <form method="post" action="<?= base_url('survey-masuk'); ?>">
                            <div class="control-group">
                                <input type="text" class="form-control border-0 p-4" placeholder="Nama lengkap" name="nama"
                                    required/>
                                <p class="help-block text-danger"></p>
                            </div>
                            <div class="control-group">
                                <input type="email" class="form-control border-0 p-4" placeholder="Alamat email" name="email"
                                    required/>
                                <p class="help-block text-danger"></p>
                            </div>
                            <div class="control-group">
                                <input type="number" name="telp" class="form-control border-0 p-4" placeholder="e.g. 080000000000"/>
                                <p class="help-block text-danger"></p>
                            </div>
                            <div class="control-group">
                                <input type="text" class="form-control border-0 p-4" placeholder="Nama kegiatan yang dilaksanakan" name="kegiatan"
                                    required/>
                                <p class="help-block text-danger"></p>
                            </div>
                            <div class="control-group">
                                <textarea class="form-control border-0 py-3 px-4" rows="3"  placeholder="Alamat anda !"
                                    required name="alamat"></textarea>
                                <p class="help-block text-danger"></p>
                            </div>
                            <div class="control-group">
                                <select name="satker" class="form-control ">
                                    <option value="">PROTOKOLER</option>
                                    <option value="">PEMAKAMAN</option>
                                </select>
                                <p class="help-block text-danger"></p>
                            </div>
                            
                            <div class="control-group">
                                <ul class="list-inline m-0">
                                    <?php
                                    $no = 1;
                                    foreach ($pertanyaan as $per) {
                                    ?>
                                        <li class="mb-1 py-2 px-3 bg-light justify-content-between align-items-center">
                                            <a class="text-dark"><?= strtoupper($per->pertanyaan)?>
                                            <div class="form-check" aria-disabled="true">
                                                <input class="form-check-input" type="radio" id="exampleRadios1" name="<?= $per->kode ?>" required value="3">
                                                <label class="form-check-label" for="exampleRadios1">Setuju</label>
                                            </div>

                                            <div class="form-check" aria-disabled="true">
                                                <input class="form-check-input" type="radio" id="exampleRadios1" name="<?= $per->kode ?>" required value="2">
                                                <label class="form-check-label" for="exampleRadios1">Biasa Saja</label>
                                            </div>

                                            <div class="form-check" aria-disabled="true">
                                                <input class="form-check-input" type="radio" id="exampleRadios1" name="<?= $per->kode ?>" required value="1">
                                                <label class="form-check-label" for="exampleRadios1">Tidak Setuju</label>
                                            </div>
                                            </a>
                                            
                                        </li>
                                    <?php } ?>
                                </ul>
                            </div>
                            <br>
                            <div>
                                <button class="btn btn-primary py-3 px-4" type="submit" id="sendMessageButton">Kirim jawaban</button>
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Contact End -->