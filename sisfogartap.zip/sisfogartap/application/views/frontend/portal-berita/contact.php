<!-- Contact Start -->
<div class="container-fluid py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 pb-4 pb-lg-0">
                <div class="bg-primary text-dark text-center p-4">
                    <h4 class="m-0"><i class="fa fa-map-marker-alt text-white mr-2"></i>Jl. Nias no 3, Bandung</h4>
                </div>

                <iframe style="width: 100%; height: 470px;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3960.83833733566!2d107.60820871477286!3d-6.909925395007176!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e68e630d9426fe1%3A0xdc45a9f6c26125e7!2sKogartap%20II%20(Garnisun)%20Bandung!5e0!3m2!1sid!2sid!4v1671937707119!5m2!1sid!2sid" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </div>
            <div class="col-lg-7">
                <h6 class="text-primary text-uppercase font-weight-bold">Unit pelayanan pengaduan polisi militer (UP3M)</h6>
                <h1 class="mb-4">Beri kami saran !</h1>
                <div class="contact-form bg-secondary" style="padding: 30px;">
                    <div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>
                    <form method="post" enctype="multipart/form-data" action="<?= base_url('pesan-masuk'); ?>">
                        <div class="control-group">
                            <input type="text" class="form-control border-0 p-4" placeholder="Nama lengkap" name="nama" required />
                            <p class="help-block text-danger"></p>
                        </div>
                        <div class="control-group">
                            <input type="email" class="form-control border-0 p-4" placeholder="Alamat email" name="email" required />
                            <p class="help-block text-danger"></p>
                        </div>
                        <div class="control-group">
                            <input type="text" name="judul" class="form-control border-0 p-4" placeholder="Subject/judul pesan" />
                            <p class="help-block text-danger"></p>
                        </div>
                        <div class="control-group">
                            <textarea class="form-control border-0 py-3 px-4" rows="5" placeholder="Tulis pesan anda disini !" required name="pesan"></textarea>
                            <p class="help-block text-danger"></p>
                        </div>
                        <div class="control-group">
                            <input type="file" name="deskripsi" class="form-control border-0" />
                            <p class="help-block text-danger">&emsp; upload detil kejadian dalam bentuk pdf</p>
                        </div>
                        <div>
                            <button class="btn btn-primary py-3 px-4" type="submit" id="sendMessageButton">Kirim pesan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Contact End -->