<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>
<div class="flash-data2" data-flashdata2="<?= $this->session->flashdata('pesan') ?>"></div>
<?php
$no = 1;
foreach ($user as $u) {
?>
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><b><?= $title ?></b></h1>
    <p class="mb-4"><span class="badge badge-primary"><?php echo $u->nama ?></span> Anda dapat menambah atau menghapus
        Dosir anda secara mandiri disini!</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <button type="button" data-toggle="modal" data-target="#M_Add_Dosir" id="btn-update-dosir"
                class="btn btn-outline-primary" data-id="<?= $u->id; ?>" data-nrp="<?= $u->nrp; ?>"
                data-nama="<?= $u->nama; ?>">
                <i class="fas fa-fw fa-upload"></i>
            </button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th class="table-plus datatable-nosort" width="20">NO.</th>
                            <th>AKSI</th>
                            <th>CAPTION</th>
                            <th width="50">FILE</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $no = 1;
                            foreach ($dosir as $d) {
                            ?>
                        <tr>
                            <td><?php echo $no++ ?></td>
                            <td width="100">
                                <?php
                                    if ($d->caption == 'KARTU KELUARGA'
                                    OR $d->caption == 'KARTU TANDA PENDUDUK'
                                    OR $d->caption == 'KEP PENGANGKATAN PERTAMA'
                                    OR $d->caption == 'ASABRI'
                                    ) {
                                    ?>
                                <button type="button" data-toggle="modal" data-target="#M_Update_Dosir"
                                    id="btn-update-dosir" class="btn btn-success" data-id="<?= $u->id; ?>"
                                    data-nrp="<?= $u->nrp; ?>" data-caption="<?= $d->caption; ?>"
                                    data-idnya="<?= $d->id; ?>" data-old_pdf="<?= $d->pdf; ?>"
                                    data-nama="<?= $u->nama; ?>">
                                    <i class="fas fa-fw fa-upload"></i>
                                </button>
                                <?php } else { ?>
                                <a href="<?= base_url('dosir-mdelete/') ?><?= $d->id ?>/<?= $d->pdf ?>"
                                    class="btn btn-danger btn-hapus">
                                    <i class="fas fa-fw fa-trash"></i>
                                </a>
                                <?php } ?>

                                <?php
                                        if ($d->pdf !== '') { ?>
                                <a href="<?= base_url('preview-m/') ?><?= $d->id ?>" class="btn btn-primary">
                                    <i class="fas fa-fw fa-eye"></i>
                                </a>
                                <?php } else { ?>
                                <a href="#" class="btn btn-danger">
                                    <i class="fas fa-fw fa-eye-slash"></i>
                                </a>
                                <?php } ?>
                            </td>
                            <td><?php echo $d->caption ?></td>
                            <td>
                                <?php if ($d->pdf == '') {
                                            echo '<a href="#" class="btn btn-danger btn-circle"> <i class="fas fa-times"></i>';
                                        } else {
                                            echo '<a href="#" class="btn btn-success btn-circle"> <i class="fas fa-check"></i>';
                                        }
                                        ?></td>
                        </tr>

                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<?php } ?>

<div class="modal fade" id="M_Update_Dosir" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Update Dosir</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" enctype="multipart/form-data" method="post"
                    action="<?= base_url('upload-mdosir'); ?>">
                    <input type="hidden" name="nrp" id="nrp-dosir">
                    <input type="hidden" name="id" id="id-dosir">
                    <input type="hidden" name="idnya" id="idnya-dosir">
                    <input type="hidden" name="old_pdf" id="old_pdf-dosir">

                    <label>Caption : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Caption" name="caption" id="caption-dosir" class="form-control"
                            readonly>
                    </div>

                    <label>File PDF (Max 1Mb) : </label>
                    <div class="form-group">
                        <input type="file" name="pdf" class="form-control" required>
                        <small>Untuk memperkecil file pdf dapat dilakukan <a
                                href="https://www.ilovepdf.com/id/mengompres-pdf" class="badge badge-danger">di Link ini
                                !!</a></small>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="M_Add_Dosir" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Update Dosir</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white;">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" enctype="multipart/form-data" method="post"
                    action="<?= base_url('dosir-mupload'); ?>">
                    <input type="hidden" name="nrp" id="nrp-dosir">
                    <input type="hidden" name="id" id="id-dosir">

                    <label>Nama Anggota : </label>
                    <div class="form-group">
                        <input type="text" placeholder="Nama Anggota" name="nama" id="nama-dosir" class="form-control"
                            readonly>
                    </div>
                    <label>Judul File Dosir : </label>
                    <div class="form-group">
                        <input type="text" placeholder="e.g : 'Surat Kelahiran'" name="caption" class="form-control"
                            required>
                    </div>

                    <label>File PDF (Max 1Mb) : </label>
                    <div class="form-group">
                        <input type="file" name="pdf" class="form-control" required>
                        <small>Untuk memperkecil file pdf dapat dilakukan <a
                                href="https://www.ilovepdf.com/id/mengompres-pdf" class="badge badge-danger">di Link ini
                                !!</a></small>
                    </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-fw fa-times"></i>
                </button>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-fw fa-check"></i>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
$(document).on('click', '#btn-update-dosir', function() {
    $('.modal-body #id-dosir').val($(this).data('id'));
    $('.modal-body #nama-dosir').val($(this).data('nama'));
    $('.modal-body #nrp-dosir').val($(this).data('nrp'));
    $('.modal-body #caption-dosir').val($(this).data('caption'));
    $('.modal-body #idnya-dosir').val($(this).data('idnya'));
    $('.modal-body #old_pdf-dosir').val($(this).data('old_pdf'));
});
</script>