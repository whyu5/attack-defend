<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><b>Dashboard</b></h1>
        <?php date_default_timezone_set('Asia/Jakarta'); ?>
        <h5 style="font-weight: bold;" id="jam"></h5>
    </div>
    <?php $nrp = $this->session->userdata('nrp');
    $user = $this->db->get_where('pokok', ['nrp' => $nrp])->row_array();
    $nrp = $user['nrp'];
    $nama = $user['nama'];
    $jabatan = $user['jabatan'];
    $id = $user['id'];
    ?>
    <div class="row">
        <div class="col-6 col-xl-6 col-md-4 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="h5 mb-0 font-weight-bold text-gray-800">SISFOGARTAP II/BDG</div>
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            <marquee><?= $nama?> <?= $nrp?>, <?= $jabatan?></marquee>
                            </div>
                            
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-users fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        $nrp = $this->session->userdata('nrp');
        $quer = $this->db->query("SELECT * from dosir where nrp = '$nrp'");
        $hasil2 = $quer->num_rows();
        ?>
        <!-- Earnings (Annual) Card Example -->
        <div class="col-6 col-xl-3 col-md-4 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Dosir (Elektronik)</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hasil2 ?> dosir</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-print fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h5 class="m-0 font-weight-bold text-primary">Untuk diperhatikan</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                Segera lengkapi dosir anda!
            </div>
        </div>
    </div>


    <script type="text/javascript">
    window.onload = function() {
        jam();
    }

    function jam() {
        var e = document.getElementById('jam'),
            d = new Date();
        Y = d.getFullYear();
        m = d.getMonth();
        t = d.getDate();
        h = d.getHours();
        m = set(d.getMinutes());
        s = set(d.getSeconds());

        e.innerHTML = h + ':' + m + ':' + s + ' WIB';

        setTimeout('jam()', 1000);
    }

    function set(e) {
        e = e < 10 ? '0' + e : e;
        return e;
    }
    </script>
</div>